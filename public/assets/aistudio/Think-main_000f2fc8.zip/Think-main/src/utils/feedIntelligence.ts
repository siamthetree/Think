import type { FeedItem } from '../types';

export interface StoryCluster {
  id: string;
  primary: FeedItem;
  perspectives: FeedItem[]; // Additional coverage from other sources/articles
  topicKeywords: string[];
}

export interface DailyBriefingEdition {
  editionTitle: 'Morning Briefing' | 'Afternoon Briefing' | 'Evening Briefing' | 'Night Briefing';
  subtitle: string;
  stories: FeedItem[];
  totalReadMinutes: number;
}

export interface ReadingHabitState {
  dailyGoal: number;
  todayDate: string; // YYYY-MM-DD
  todayReadIds: string[];
  todayMinutes: number;
  streakDays: number;
  lastCompletedDate: string | null;
}

export interface ReadingProgressItem {
  articleId: string;
  title: string;
  feedTitle: string;
  progressPercent: number; // 1..94
  scrollTop: number;
  updatedAt: number;
}

/**
 * Stop words AND generic newspaper/category words that must NEVER trigger a story topic match on their own.
 * Prevents broad category words ("bangladesh", "dhaka", "government", "minister", "economy", "police", etc.)
 * from grouping unrelated articles together.
 */
const STOP_WORDS = new Set([
  // Function & common stop words
  'the', 'and', 'for', 'that', 'with', 'from', 'this', 'have', 'will', 'your',
  'about', 'into', 'after', 'over', 'under', 'between', 'what', 'when', 'where',
  'which', 'their', 'there', 'been', 'were', 'they', 'more', 'some', 'than',
  'news', 'report', 'reports', 'reported', 'says', 'said', 'amid', 'new', 'how',
  'why', 'who', 'its', 'are', 'was', 'has', 'had', 'not', 'but', 'you', 'all',
  'can', 'her', 'his', 'our', 'out', 'day', 'days', 'get', 'make', 'made',
  'just', 'like', 'know', 'take', 'takes', 'taken', 'year', 'years', 'month',
  'months', 'week', 'weeks', 'today', 'yesterday', 'tomorrow', 'time', 'first',
  'last', 'two', 'three', 'four', 'five', 'one', 'many', 'much', 'most', 'other',
  'others', 'also', 'only', 'even', 'back', 'down', 'still', 'well', 'way',
  'may', 'might', 'must', 'should', 'would', 'could', 'need', 'needs', 'want',
  'wants', 'call', 'calls', 'called', 'urge', 'urges', 'urged', 'seek', 'seeks',
  'sought', 'set', 'sets', 'hold', 'holds', 'held', 'begin', 'begins', 'began',
  'start', 'starts', 'started', 'end', 'ends', 'ended', 'high', 'low', 'major',
  'big', 'small', 'good', 'bad', 'best', 'worst', 'top', 'amidst', 'during',
  'before', 'since', 'while', 'against', 'through', 'without', 'within', 'across',
  'around', 'among', 'upon', 'towards', 'toward', 'despite', 'via', 'per',
  // Broad geographic & generic newspaper category terms (should not match unrelated stories by category)
  'bangladesh', 'bangladeshi', 'dhaka', 'country', 'national', 'nation', 'state',
  'world', 'global', 'international', 'local', 'city', 'district', 'districts',
  'division', 'capital', 'region', 'regional', 'area', 'areas', 'center', 'centre',
  'government', 'govt', 'ministry', 'minister', 'adviser', 'advisor', 'official',
  'officials', 'authority', 'authorities', 'committee', 'commission', 'department',
  'board', 'council', 'agency', 'office', 'officer', 'officers', 'chief', 'head',
  'leader', 'leaders', 'member', 'members', 'party', 'people', 'public', 'citizen',
  'citizens', 'group', 'groups', 'team', 'teams', 'company', 'companies', 'firm',
  'business', 'market', 'markets', 'sector', 'industry', 'economy', 'economic',
  'financial', 'finance', 'trade', 'bank', 'banks', 'price', 'prices', 'rate',
  'rates', 'growth', 'policy', 'plan', 'plans', 'project', 'projects', 'program',
  'system', 'service', 'services', 'issue', 'issues', 'problem', 'problems',
  'action', 'actions', 'step', 'steps', 'move', 'moves', 'decision', 'meeting',
  'talks', 'event', 'events', 'case', 'cases', 'court', 'law', 'legal', 'order',
  'rule', 'rules', 'police', 'force', 'forces', 'security', 'attack', 'killed',
  'dead', 'death', 'deaths', 'injured', 'hospital', 'health', 'medical', 'doctor',
  'doctors', 'school', 'schools', 'college', 'university', 'student', 'students',
  'teacher', 'teachers', 'education', 'work', 'workers', 'worker', 'job', 'jobs',
  'life', 'living', 'home', 'house', 'road', 'roads', 'street', 'water', 'power',
  'energy', 'food', 'money', 'fund', 'funds', 'taka', 'crore', 'lakh', 'million',
  'billion', 'percent', 'number', 'total', 'level', 'part', 'side', 'point',
  'daily', 'star', 'prothom', 'alo', 'tribune', 'standard', 'express', 'bbc',
  'guardian', 'jugantor', 'bdnews24', 'travel', 'traveler', 'travelers',
  // Bengali stop words & broad category words
  'এবং', 'থেকে', 'করে', 'জন্য', 'হয়েছে', 'বলে', 'সাথে', 'নিয়ে', 'মধ্যে', 'কিন্তু',
  'আরও', 'একটি', 'হবে', 'হয়', 'বা', 'না', 'ও', 'এই', 'তার', 'করা', 'পর', 'দুই',
  'বাংলাদেশ', 'বাংলাদেশের', 'বাংলাদেশে', 'ঢাকা', 'ঢাকার', 'ঢাকায়', 'সরকার',
  'সরকারি', 'দেশের', 'দেশে', 'দেশ', 'জাতীয়', 'আন্তর্জাতিক', 'বিশ্ব', 'খবর',
  'সংবাদ', 'তথ্য', 'জানিয়েছে', 'জানান', 'বলেন', 'বলেছেন', 'হিসেবে', 'কাছে',
  'কাজ', 'সময়', 'দিন', 'বছর', 'মাস', 'সপ্তাহ', 'আজ', 'কাল', 'গতকাল', 'মানুষ',
  'জনগণ', 'পুলিশ', 'আদালত', 'মামলা', 'টাকা', 'কোটি', 'লাখ', 'শতাংশ', 'প্রধান',
  'মন্ত্রী', 'উপদেষ্টা', 'মন্ত্রণালয়', 'বিভাগ', 'জেলা', 'উপজেলা', 'শহর', 'এলাকা',
]);

/**
 * Light stemmer so inflected forms ("inflations"/"inflation", "exports"/"export", "tightened"/"tighten")
 * match the same underlying story topic token.
 */
function normalizeTopicToken(word: string): string {
  let w = word.trim().toLowerCase();
  if (w.length <= 4) return w;
  if (/^[a-z]+$/.test(w)) {
    if (w.endsWith('ies') && w.length > 5) return w.slice(0, -3) + 'y';
    if (w.endsWith('ing') && w.length > 6) return w.slice(0, -3);
    if (w.endsWith('ed') && w.length > 5) return w.slice(0, -2);
    if (w.endsWith('es') && w.length > 5) return w.slice(0, -2);
    if (w.endsWith('s') && !w.endsWith('ss') && w.length > 4) return w.slice(0, -1);
  }
  return w;
}

/**
 * Extracts normalized significant topic tokens (English & Bengali words >= 3 chars,
 * filtering out stop words and generic category words).
 */
export function extractSignificantTokens(text: string): string[] {
  if (!text) return [];
  const rawWords = text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .map((w) => w.trim())
    .filter((w) => w.length >= 3 && !STOP_WORDS.has(w) && !/^\d+$/.test(w));

  const result: string[] = [];
  const seenStems = new Set<string>();
  for (const word of rawWords) {
    const stem = normalizeTopicToken(word);
    if (STOP_WORDS.has(stem) || stem.length < 3) continue;
    if (!seenStems.has(stem)) {
      seenStems.add(stem);
      result.push(word);
    }
  }

  return result;
}

/**
 * Extracts normalized 2-word topic phrases (bigrams) from a headline to capture specific subjects
 * like "monetary policy", "metro rail", "padma bridge", "remittance inflow", "amiakhum trek", etc.
 */
function extractTopicBigrams(text: string): string[] {
  const tokens = extractSignificantTokens(text).map(normalizeTopicToken);
  const bigrams: string[] = [];
  for (let i = 0; i < tokens.length - 1; i++) {
    bigrams.push(`${tokens[i]}_${tokens[i + 1]}`);
  }
  return bigrams;
}

/**
 * Computes topic and story similarity between two articles based strictly on their headline
 * and lead story subject — never on feed category or tags.
 */
export function computeStorySimilarity(a: FeedItem, b: FeedItem): {
  score: number;
  sharedKeywords: string[];
  headlineOverlapCount: number;
} {
  const titleTokensA = extractSignificantTokens(a.title);
  const titleTokensB = extractSignificantTokens(b.title);
  const fullTokensA = extractSignificantTokens(`${a.title} ${a.summary?.slice(0, 140) || ''}`);
  const fullTokensB = extractSignificantTokens(`${b.title} ${b.summary?.slice(0, 140) || ''}`);

  if (fullTokensA.length === 0 || fullTokensB.length === 0) {
    return { score: 0, sharedKeywords: [], headlineOverlapCount: 0 };
  }

  const titleStemsB = new Set(titleTokensB.map(normalizeTopicToken));
  const fullStemsB = new Set(fullTokensB.map(normalizeTopicToken));

  // Shared tokens where at least one appears in the headline
  const headlineShared = titleTokensA.filter((t) => titleStemsB.has(normalizeTopicToken(t)));
  const allShared = fullTokensA.filter((t) => fullStemsB.has(normalizeTopicToken(t)));

  if (allShared.length === 0) {
    return { score: 0, sharedKeywords: [], headlineOverlapCount: 0 };
  }

  // Check 2-word phrase (bigram) overlap in headlines/summaries
  const bigramsA = extractTopicBigrams(`${a.title} ${a.summary?.slice(0, 100) || ''}`);
  const bigramsB = new Set(extractTopicBigrams(`${b.title} ${b.summary?.slice(0, 100) || ''}`));
  const sharedBigrams = bigramsA.filter((bg) => bigramsB.has(bg));

  const minTitleLen = Math.max(1, Math.min(titleTokensA.length || 1, titleTokensB.length || 1));
  const minFullLen = Math.max(1, Math.min(fullTokensA.length, fullTokensB.length));

  const titleOverlapRatio = headlineShared.length / minTitleLen;
  const fullOverlapRatio = allShared.length / minFullLen;
  const bigramBonus = sharedBigrams.length * 0.25;

  const combinedScore = Number(
    (titleOverlapRatio * 0.65 + fullOverlapRatio * 0.35 + bigramBonus).toFixed(3)
  );

  // Order shared keywords with headline matches first
  const orderedKeywords = Array.from(
    new Set([...headlineShared, ...allShared])
  ).slice(0, 4);

  return {
    score: combinedScore,
    sharedKeywords: orderedKeywords,
    headlineOverlapCount: headlineShared.length,
  };
}

/**
 * Groups related articles into Developing Story Clusters while keeping chronological feed order.
 * Requires specific story/topic overlap (at least 1 shared headline topic keyword + >=2 total topic keywords or >=0.38 score).
 */
export function clusterStoriesByTopic(articles: FeedItem[]): StoryCluster[] {
  const assigned = new Set<string>();
  const clusters: StoryCluster[] = [];
  const MAX_TIME_GAP_MS = 48 * 60 * 60 * 1000;

  for (let i = 0; i < articles.length; i++) {
    const primary = articles[i];
    if (assigned.has(primary.id)) continue;
    assigned.add(primary.id);

    const perspectives: FeedItem[] = [];
    const keywordSet = new Set<string>();

    for (let j = i + 1; j < articles.length; j++) {
      const candidate = articles[j];
      if (assigned.has(candidate.id)) continue;
      if (Math.abs(primary.timestamp - candidate.timestamp) > MAX_TIME_GAP_MS) continue;

      const { score, sharedKeywords, headlineOverlapCount } = computeStorySimilarity(
        primary,
        candidate
      );
      if (
        headlineOverlapCount >= 1 &&
        (sharedKeywords.length >= 2 || score >= 0.38)
      ) {
        perspectives.push(candidate);
        assigned.add(candidate.id);
        sharedKeywords.forEach((k) => keywordSet.add(k));
        if (perspectives.length >= 5) break;
      }
    }

    clusters.push({
      id: `cluster_${primary.id}`,
      primary,
      perspectives,
      topicKeywords: Array.from(keywordSet).slice(0, 4),
    });
  }

  return clusters;
}

/**
 * Builds a 5-story time-of-day Smart Edition Briefing with publisher diversity.
 */
export function buildDailyBriefing(
  articles: FeedItem[],
  nowMs: number = Date.now()
): DailyBriefingEdition {
  const hour = new Date(nowMs).getHours();
  let editionTitle: DailyBriefingEdition['editionTitle'] = 'Morning Briefing';
  let subtitle = 'Five essential stories to start your day with clarity';

  if (hour >= 12 && hour < 17) {
    editionTitle = 'Afternoon Briefing';
    subtitle = 'Midday developments and essential perspectives across sources';
  } else if (hour >= 17 && hour < 22) {
    editionTitle = 'Evening Briefing';
    subtitle = 'Today’s five defining stories, distilled for calm evening reading';
  } else if (hour >= 22 || hour < 5) {
    editionTitle = 'Night Briefing';
    subtitle = 'Late-hour wrap of the day’s most significant reporting';
  }

  // Prefer unread stories first, then newest, diversifying by publisher (feedId)
  const sorted = [...articles].sort((a, b) => {
    if (a.isRead !== b.isRead) return a.isRead ? 1 : -1;
    return b.timestamp - a.timestamp;
  });

  const selected: FeedItem[] = [];
  const usedFeeds = new Set<string>();

  for (const item of sorted) {
    if (selected.length >= 5) break;
    if (!usedFeeds.has(item.feedId)) {
      selected.push(item);
      usedFeeds.add(item.feedId);
    }
  }

  // Fill remaining slots up to 5 if fewer than 5 unique feeds exist
  if (selected.length < 5) {
    const selectedIds = new Set(selected.map((s) => s.id));
    for (const item of sorted) {
      if (selected.length >= 5) break;
      if (!selectedIds.has(item.id)) {
        selected.push(item);
        selectedIds.add(item.id);
      }
    }
  }

  // If the first briefing slide is identical to the first card in the feed below, rotate so slide 1 highlights another publisher first
  const orderedStories =
    selected.length >= 2 && articles.length > 0 && selected[0].id === articles[0].id
      ? [...selected.slice(1), selected[0]]
      : selected;

  const totalReadMinutes = orderedStories.reduce(
    (sum, item) => sum + Math.max(1, item.readTimeMin || 3),
    0
  );

  return {
    editionTitle,
    subtitle,
    stories: orderedStories,
    totalReadMinutes,
  };
}

/**
 * Deterministically extracts 3 crisp TL;DR bullet points for instant zero-latency Quick Peek.
 */
export function generateQuickTldrBullets(article: FeedItem): string[] {
  const rawSource = [article.contentClean || '', article.summary || '']
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim();

  if (!rawSource || rawSource.length < 40) {
    return [
      article.title,
      `Published by ${article.feedTitle} · Estimated ${article.readTimeMin || 3} min read.`,
      'Open in Distraction-Free Reader to extract the complete article text.',
    ];
  }

  // Split on sentence boundaries (English '.', '!', '?' and Bengali dari '।')
  const sentences = rawSource
    .split(/(?<=[.!?।])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 28 && s !== article.title);

  const uniqueBullets: string[] = [];
  for (const sentence of sentences) {
    if (uniqueBullets.length >= 3) break;
    const clipped =
      sentence.length > 145 ? `${sentence.slice(0, 140).trim()}…` : sentence;
    if (!uniqueBullets.some((b) => b.slice(0, 30) === clipped.slice(0, 30))) {
      uniqueBullets.push(clipped);
    }
  }

  while (uniqueBullets.length < 3) {
    if (uniqueBullets.length === 0) {
      uniqueBullets.push(article.summary?.slice(0, 140) || article.title);
    } else if (uniqueBullets.length === 1) {
      uniqueBullets.push(
        `Source perspective from ${article.feedTitle}${article.author ? ` (${article.author})` : ''}.`
      );
    } else {
      uniqueBullets.push(
        `Full distraction-free text available (${article.readTimeMin || 3} min read).`
      );
    }
  }

  return uniqueBullets.slice(0, 3);
}

/**
 * Formats a timestamp (ms) into local YYYY-MM-DD string
 */
export function toDateKey(nowMs: number = Date.now()): string {
  const d = new Date(nowMs);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Checks if dateA (YYYY-MM-DD) is the calendar day immediately before dateB (YYYY-MM-DD)
 */
export function isYesterdayOf(dateA: string | null, dateB: string): boolean {
  if (!dateA) return false;
  const [yA, mA, dA] = dateA.split('-').map(Number);
  const [yB, mB, dB] = dateB.split('-').map(Number);
  if (!yA || !yB) return false;
  const utcA = Date.UTC(yA, mA - 1, dA);
  const utcB = Date.UTC(yB, mB - 1, dB);
  const diffDays = Math.round((utcB - utcA) / (24 * 60 * 60 * 1000));
  return diffDays === 1;
}

/**
 * Normalizes stored ReadingHabitState to the current calendar date so stale days roll over cleanly
 */
export function normalizeReadingHabitState(
  state: ReadingHabitState,
  todayKey: string = toDateKey()
): ReadingHabitState {
  if (state.todayDate === todayKey) {
    return state;
  }

  // If the user neither completed yesterday nor read today, check if streak is still alive from yesterday
  const streakStillValid =
    state.lastCompletedDate === todayKey ||
    isYesterdayOf(state.lastCompletedDate, todayKey);

  return {
    dailyGoal: state.dailyGoal || 3,
    todayDate: todayKey,
    todayReadIds: [],
    todayMinutes: 0,
    streakDays: streakStillValid ? state.streakDays : 0,
    lastCompletedDate: state.lastCompletedDate,
  };
}

/**
 * Records a completed story read into the user's daily reading habit state.
 */
export function recordArticleReadInHabit(
  prevState: ReadingHabitState,
  articleId: string,
  readTimeMin: number,
  todayKey: string = toDateKey()
): { nextState: ReadingHabitState; justHitDailyGoal: boolean } {
  const current = normalizeReadingHabitState(prevState, todayKey);

  if (current.todayReadIds.includes(articleId)) {
    return { nextState: current, justHitDailyGoal: false };
  }

  const nextReadIds = [...current.todayReadIds, articleId];
  const nextMinutes = current.todayMinutes + Math.max(1, Math.min(15, readTimeMin || 3));
  const wasBelowGoal = current.todayReadIds.length < current.dailyGoal;
  const nowMeetsGoal = nextReadIds.length >= current.dailyGoal;
  const justHitDailyGoal = wasBelowGoal && nowMeetsGoal;

  let nextStreak = current.streakDays;
  let nextLastCompleted = current.lastCompletedDate;

  if (justHitDailyGoal && current.lastCompletedDate !== todayKey) {
    if (isYesterdayOf(current.lastCompletedDate, todayKey)) {
      nextStreak = current.streakDays + 1;
    } else {
      nextStreak = Math.max(1, current.streakDays || 1);
    }
    nextLastCompleted = todayKey;
  } else if (nextStreak === 0 && nextReadIds.length > 0) {
    nextStreak = 1;
  }

  return {
    nextState: {
      ...current,
      todayReadIds: nextReadIds,
      todayMinutes: nextMinutes,
      streakDays: nextStreak,
      lastCompletedDate: nextLastCompleted,
    },
    justHitDailyGoal,
  };
}

/**
 * Filters incoming articles to find genuinely new ones not yet present in currentArticles
 */
export function findNewIncomingArticles(
  currentArticles: FeedItem[],
  incomingArticles: FeedItem[]
): FeedItem[] {
  const existingIds = new Set(currentArticles.map((a) => a.id));
  const existingLinks = new Set(currentArticles.map((a) => a.link));

  return incomingArticles.filter(
    (item) => !existingIds.has(item.id) && (!item.link || !existingLinks.has(item.link))
  );
}

/**
 * Searches all articles across all added sources for coverage of the SAME news topic and story.
 * Matches strictly on specific story entities, headline tokens, and topic phrases (never on broad category or tags).
 */
export function findPerspectivesAcrossSources(
  targetArticle: FeedItem,
  allArticles: FeedItem[]
): Array<{ article: FeedItem; score: number; sharedKeywords: string[] }> {
  const targetTokens = extractSignificantTokens(
    `${targetArticle.title} ${targetArticle.summary?.slice(0, 160) || ''}`
  );
  if (targetTokens.length === 0) return [];

  const matches: Array<{ article: FeedItem; score: number; sharedKeywords: string[] }> = [];
  const seenIds = new Set<string>([targetArticle.id]);
  const seenLinks = new Set<string>(targetArticle.link ? [targetArticle.link] : []);

  for (const candidate of allArticles) {
    if (seenIds.has(candidate.id)) continue;
    if (candidate.link && seenLinks.has(candidate.link)) continue;

    const { score, sharedKeywords, headlineOverlapCount } = computeStorySimilarity(
      targetArticle,
      candidate
    );

    // Require genuine topic/story match:
    // Must share at least 2 specific topic keywords (with at least 1 in the headline) OR a high phrase/topic similarity score (>= 0.36)
    const isSameTopicAndStory =
      (headlineOverlapCount >= 1 && sharedKeywords.length >= 2) ||
      (headlineOverlapCount >= 2 && score >= 0.28) ||
      score >= 0.42;

    if (isSameTopicAndStory) {
      seenIds.add(candidate.id);
      if (candidate.link) seenLinks.add(candidate.link);
      const crossSourceBonus = candidate.feedId !== targetArticle.feedId ? 0.1 : 0;
      matches.push({
        article: candidate,
        score: Number((score + crossSourceBonus).toFixed(3)),
        sharedKeywords,
      });
    }
  }

  return matches.sort((a, b) => {
    if (b.sharedKeywords.length !== a.sharedKeywords.length) {
      return b.sharedKeywords.length - a.sharedKeywords.length;
    }
    if (b.score !== a.score) return b.score - a.score;
    return b.article.timestamp - a.article.timestamp;
  });
}
