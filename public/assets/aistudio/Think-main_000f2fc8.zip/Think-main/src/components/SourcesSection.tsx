import React, { useState, useMemo, useRef } from 'react';
import {
  Search,
  Plus,
  RefreshCw,
  Trash2,
  Check,
  Folder,
  FolderPlus,
  FolderInput,
  ChevronRight,
  ChevronDown,
  X,
  Compass,
  Send,
  Globe,
  Sparkles,
  Upload,
  Download,
  ArrowUpRight,
} from 'lucide-react';
import type { Feed, FeedItem } from '../types';
import { SourceAvatar } from './SourceAvatar';
import { formatRelativeTime } from '../utils/feedParser';
import {
  triggerHapticSelection,
  triggerHapticPull,
  triggerHapticDisarm,
  triggerHapticComplete,
  triggerHapticError,
} from '../utils/haptics';
import {
  computeSwipeActionState,
  computeReleaseVelocity,
  shouldCommitSwipeAction,
  type SwipeActionState,
  type GestureAxisLock,
  type VelocitySample,
} from '../utils/touchGestures';

interface SourcesSectionProps {
  feeds: Feed[];
  articles: FeedItem[];
  folders: string[];
  selectedFeedId: string | null;
  selectedFolder: string | null;
  isRefreshing: boolean;
  isOffline: boolean;
  onSelectSource: (feed: Feed) => void;
  onSelectFolder: (folderName: string) => void;
  onCreateFolder: (folderName: string) => void;
  onMoveFeedToFolder: (feedId: string, folderName: string) => void;
  onRefreshFeed: (feed: Feed) => Promise<void>;
  onRefreshAll: () => Promise<void>;
  onDeleteFeed: (feedId: string) => void;
  onAddFeed: (feed: Omit<Feed, 'id'>) => void;
  onOpenFeedModal: () => void;
  onLoadDirectUrl: (url: string, folderName?: string, customTitle?: string) => void;
  isLoadingDirectUrl: boolean;
  onOpenIosModal: () => void;
  onPublishTravelBlog?: (params: {
    author: string;
    groupName: string;
    groupContact?: string;
    location: string;
    title: string;
    content: string;
    coverImage?: string;
  }) => Promise<void>;
}

const INITIAL_ROW_SWIPE: SwipeActionState = {
  offsetX: 0,
  direction: 'none',
  progress: 0,
  armed: false,
  axisLock: 'undecided',
};

/**
 * Optional 1-tap quick-add directory so users starting with an empty app can either
 * type any custom URL in the omnibar OR tap "+" to add a newspaper in one second.
 */
const QUICK_STARTER_CATALOG = [
  {
    title: 'The Daily Star',
    url: 'https://www.thedailystar.net/rss.xml',
    siteUrl: 'https://www.thedailystar.net',
    subtitle: 'thedailystar.net · English Daily',
    category: 'Bangladesh',
    tags: ['tag_bd'],
  },
  {
    title: 'Prothom Alo (English)',
    url: 'https://en.prothomalo.com/feed',
    siteUrl: 'https://en.prothomalo.com',
    subtitle: 'en.prothomalo.com · National & Views',
    category: 'Bangladesh',
    tags: ['tag_bd'],
  },
  {
    title: 'প্রথম আলো (Prothom Alo)',
    url: 'https://www.prothomalo.com/feed',
    siteUrl: 'https://www.prothomalo.com',
    subtitle: 'prothomalo.com · বাংলা দৈনিক',
    category: 'Bangladesh (বাংলা)',
    tags: ['tag_bd'],
  },
  {
    title: 'The Business Standard',
    url: 'https://www.tbsnews.net/top-news/rss.xml',
    siteUrl: 'https://www.tbsnews.net',
    subtitle: 'tbsnews.net · Economy & Policy',
    category: 'Finance',
    tags: ['tag_bd', 'tag_markets'],
  },
  {
    title: 'bdnews24.com',
    url: 'https://bdnews24.com',
    siteUrl: 'https://bdnews24.com',
    subtitle: 'bdnews24.com · Direct Portal Reader',
    category: 'Bangladesh',
    tags: ['tag_bd', 'tag_breaking'],
  },
  {
    title: 'Dhaka Tribune',
    url: 'https://www.dhakatribune.com/feed/',
    siteUrl: 'https://www.dhakatribune.com',
    subtitle: 'dhakatribune.com · National & Op-Ed',
    category: 'Bangladesh',
    tags: ['tag_bd'],
  },
  {
    title: 'The Financial Express BD',
    url: 'https://thefinancialexpress.com.bd',
    siteUrl: 'https://thefinancialexpress.com.bd',
    subtitle: 'thefinancialexpress.com.bd · Markets',
    category: 'Finance',
    tags: ['tag_bd', 'tag_markets'],
  },
  {
    title: 'BBC World News',
    url: 'https://feeds.bbci.co.uk/news/world/rss.xml',
    siteUrl: 'https://www.bbc.com/news',
    subtitle: 'bbc.com/news · Global Dispatches',
    category: 'World',
    tags: ['tag_world'],
  },
  {
    title: 'The Guardian World',
    url: 'https://www.theguardian.com/world/rss',
    siteUrl: 'https://www.theguardian.com',
    subtitle: 'theguardian.com · International',
    category: 'World',
    tags: ['tag_world'],
  },
  {
    title: 'BD Travel Dispatches',
    url: '/api/blogs',
    siteUrl: 'https://chinta.app/travel',
    subtitle: 'Community Expeditions & Trail Notes',
    category: 'Travel',
    tags: ['tag_travel', 'tag_bd'],
  },
];

function cleanDomainLabel(rawUrl: string): string {
  if (!rawUrl || rawUrl === '/api/blogs') return 'chinta.app/travel';
  try {
    const parsed = new URL(rawUrl.startsWith('http') ? rawUrl : `https://${rawUrl}`);
    return parsed.hostname.replace(/^www\./i, '');
  } catch {
    return rawUrl;
  }
}

export const SourcesSection: React.FC<SourcesSectionProps> = ({
  feeds,
  articles,
  folders,
  selectedFeedId,
  selectedFolder,
  isRefreshing,
  isOffline,
  onSelectSource,
  onSelectFolder,
  onCreateFolder,
  onMoveFeedToFolder,
  onRefreshFeed,
  onRefreshAll,
  onDeleteFeed,
  onAddFeed,
  onOpenFeedModal,
  onLoadDirectUrl,
  isLoadingDirectUrl,
  onPublishTravelBlog,
}) => {
  const [urlInput, setUrlInput] = useState('');
  const [filterQuery, setFilterQuery] = useState('');
  const [showFilterSearch, setShowFilterSearch] = useState(false);
  const [showQuickCatalog, setShowQuickCatalog] = useState(false);
  const [isNewFolderOpen, setIsNewFolderOpen] = useState(false);
  const [isBlogComposerOpen, setIsBlogComposerOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [collapsedFolders, setCollapsedFolders] = useState<Record<string, boolean>>({});
  const [refreshingFeedId, setRefreshingFeedId] = useState<string | null>(null);

  // Travel Blog Composer State
  const [blogTitle, setBlogTitle] = useState('');
  const [blogAuthor, setBlogAuthor] = useState('');
  const [blogGroupName, setBlogGroupName] = useState('');
  const [blogLocation, setBlogLocation] = useState('');
  const [blogContact, setBlogContact] = useState('');
  const [blogContent, setBlogContent] = useState('');
  const [isPublishingBlog, setIsPublishingBlog] = useState(false);

  // Source currently being moved between folders
  const [movingFeed, setMovingFeed] = useState<Feed | null>(null);
  const [moveNewFolderName, setMoveNewFolderName] = useState('');
  const [isCreatingFolderInMove, setIsCreatingFolderInMove] = useState(false);

  // Swipe action state for individual source rows
  const [swipingFeedId, setSwipingFeedId] = useState<string | null>(null);
  const [rowSwipeState, setRowSwipeState] = useState<SwipeActionState>(INITIAL_ROW_SWIPE);
  const rowTouchStartRef = useRef<{
    feedId: string;
    pointerId: number;
    x: number;
    y: number;
    axisLock: GestureAxisLock;
    armed: boolean;
    samples: VelocitySample[];
  } | null>(null);
  const didRowSwipeRef = useRef(false);

  // All named folders
  const allFolders = useMemo(() => {
    const set = new Set<string>();
    for (const folder of folders) {
      if (folder && folder.trim()) set.add(folder.trim());
    }
    for (const f of feeds) {
      if (f.category && f.category.trim()) {
        set.add(f.category.trim());
      }
    }
    return Array.from(set);
  }, [folders, feeds]);

  // Filtered feeds
  const filteredFeeds = useMemo(() => {
    const q = filterQuery.trim().toLowerCase();
    if (!q) return feeds;
    return feeds.filter(
      (f) =>
        f.title.toLowerCase().includes(q) ||
        f.url.toLowerCase().includes(q) ||
        (f.category && f.category.toLowerCase().includes(q))
    );
  }, [feeds, filterQuery]);

  // Unread counts and latest timestamp per feed
  const feedStats = useMemo(() => {
    const unread: Record<string, number> = {};
    const total: Record<string, number> = {};
    const latestTs: Record<string, number> = {};
    for (const a of articles) {
      total[a.feedId] = (total[a.feedId] || 0) + 1;
      if (!a.isRead) {
        unread[a.feedId] = (unread[a.feedId] || 0) + 1;
      }
      if (!latestTs[a.feedId] || a.timestamp > latestTs[a.feedId]) {
        latestTs[a.feedId] = a.timestamp;
      }
    }
    return { unread, total, latestTs };
  }, [articles]);

  // Uncategorized sources
  const uncategorizedFeeds = useMemo(() => {
    return filteredFeeds.filter((f) => !f.category || !f.category.trim());
  }, [filteredFeeds]);

  // Group categorized feeds by folder
  const groupedByFolder = useMemo(() => {
    const map = new Map<string, Feed[]>();
    for (const folder of allFolders) {
      map.set(folder, []);
    }
    for (const feed of filteredFeeds) {
      const folder = feed.category?.trim();
      if (!folder) continue;
      if (!map.has(folder)) {
        map.set(folder, []);
      }
      map.get(folder)!.push(feed);
    }
    return Array.from(map.entries()).filter(
      ([, list]) => list.length > 0 || (!filterQuery.trim() && folders.length > 0)
    );
  }, [allFolders, filteredFeeds, filterQuery, folders]);

  const handleOmnibarSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const raw = urlInput.trim();
    if (!raw || isLoadingDirectUrl) return;
    triggerHapticSelection();
    onLoadDirectUrl(raw);
    setUrlInput('');
  };

  const handleQuickAddStarter = (starter: (typeof QUICK_STARTER_CATALOG)[0]) => {
    triggerHapticComplete();
    onAddFeed({
      title: starter.title,
      url: starter.url,
      siteUrl: starter.siteUrl,
      category: starter.category,
      defaultTags: starter.tags,
      unreadCount: 0,
    });
  };

  const handleSingleRefresh = async (e: React.MouseEvent | null, feed: Feed) => {
    e?.stopPropagation();
    triggerHapticSelection();
    setRefreshingFeedId(feed.id);
    try {
      await onRefreshFeed(feed);
      triggerHapticComplete();
    } catch {
      triggerHapticError();
    } finally {
      setRefreshingFeedId(null);
    }
  };

  const handleCreateFolderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = newFolderName.trim();
    if (!trimmed) return;
    triggerHapticComplete();
    onCreateFolder(trimmed);
    setNewFolderName('');
    setIsNewFolderOpen(false);
  };

  const handlePublishBlogSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onPublishTravelBlog) return;
    if (!blogTitle.trim() || !blogAuthor.trim() || !blogContent.trim()) return;

    triggerHapticSelection();
    setIsPublishingBlog(true);
    try {
      await onPublishTravelBlog({
        title: blogTitle.trim(),
        author: blogAuthor.trim(),
        groupName: blogGroupName.trim() || 'Bangladeshi Travel Group',
        groupContact: blogContact.trim() || undefined,
        location: blogLocation.trim() || 'Bangladesh',
        content: blogContent.trim(),
      });
      setBlogTitle('');
      setBlogAuthor('');
      setBlogGroupName('');
      setBlogLocation('');
      setBlogContact('');
      setBlogContent('');
      setIsBlogComposerOpen(false);
      triggerHapticComplete();
    } finally {
      setIsPublishingBlog(false);
    }
  };

  const renderSourceRow = (feed: Feed) => {
    const isSelected = selectedFeedId === feed.id;
    const unread = feedStats.unread[feed.id] || 0;
    const totalCount = feedStats.total[feed.id] || 0;
    const latestTs = feedStats.latestTs[feed.id];
    const isThisRefreshing = refreshingFeedId === feed.id;
    const activeSwipe = swipingFeedId === feed.id ? rowSwipeState : null;

    return (
      <div key={feed.id} className="relative overflow-hidden">
        {/* Swipe Action Tray (Right = Sync, Left = Organize Folder) */}
        {activeSwipe && activeSwipe.offsetX !== 0 && (
          <div
            aria-hidden="true"
            className={`absolute inset-0 flex items-center justify-between px-4 pointer-events-none select-none ${
              activeSwipe.direction === 'right'
                ? activeSwipe.armed
                  ? 'bg-emerald-500/25'
                  : 'bg-stone-200/60 dark:bg-white/[0.06]'
                : activeSwipe.armed
                  ? 'bg-[#FF6719]/25'
                  : 'bg-stone-200/60 dark:bg-white/[0.06]'
            }`}
          >
            <div
              className={`flex items-center gap-1.5 text-xs font-semibold ${
                activeSwipe.direction === 'right' ? 'opacity-100' : 'opacity-0'
              } ${activeSwipe.armed ? 'text-emerald-500' : 'text-stone-500'}`}
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Sync Now</span>
            </div>
            <div
              className={`flex items-center gap-1.5 text-xs font-semibold ml-auto ${
                activeSwipe.direction === 'left' ? 'opacity-100' : 'opacity-0'
              } ${activeSwipe.armed ? 'text-[#FF6719]' : 'text-stone-500'}`}
            >
              <span>Folder</span>
              <FolderInput className="w-3.5 h-3.5" />
            </div>
          </div>
        )}

        <div
          onClick={() => {
            if (didRowSwipeRef.current) {
              didRowSwipeRef.current = false;
              return;
            }
            triggerHapticSelection();
            onSelectSource(feed);
          }}
          onPointerDown={(e) => {
            if (e.button !== 0 && e.pointerType === 'mouse') return;
            didRowSwipeRef.current = false;
            const now = performance.now();
            rowTouchStartRef.current = {
              feedId: feed.id,
              pointerId: e.pointerId,
              x: e.clientX,
              y: e.clientY,
              axisLock: 'undecided',
              armed: false,
              samples: [{ x: e.clientX, y: e.clientY, t: now }],
            };
          }}
          onPointerMove={(e) => {
            const session = rowTouchStartRef.current;
            if (!session || session.feedId !== feed.id || session.pointerId !== e.pointerId) return;
            if (e.pointerType !== 'touch' && e.buttons !== 1) return;

            const dx = e.clientX - session.x;
            const dy = e.clientY - session.y;
            const now = performance.now();
            session.samples.push({ x: e.clientX, y: e.clientY, t: now });
            if (session.samples.length > 8) session.samples.shift();

            const next = computeSwipeActionState(
              dx,
              dy,
              64,
              112,
              session.axisLock,
              session.armed
            );
            session.axisLock = next.axisLock;

            if (next.axisLock === 'horizontal') {
              didRowSwipeRef.current = true;
              try {
                if (!e.currentTarget.hasPointerCapture(e.pointerId)) {
                  e.currentTarget.setPointerCapture(e.pointerId);
                }
              } catch {}
              setSwipingFeedId(feed.id);
              setRowSwipeState(next);
            }

            if (next.armed && !session.armed) {
              session.armed = true;
              triggerHapticPull();
            } else if (!next.armed && session.armed) {
              session.armed = false;
              triggerHapticDisarm();
            }
          }}
          onPointerUp={(e) => {
            const session = rowTouchStartRef.current;
            rowTouchStartRef.current = null;
            if (session) {
              try {
                if (e.currentTarget.hasPointerCapture(session.pointerId)) {
                  e.currentTarget.releasePointerCapture(session.pointerId);
                }
              } catch {}
              if (swipingFeedId === feed.id && session.axisLock === 'horizontal') {
                session.samples.push({ x: e.clientX, y: e.clientY, t: performance.now() });
                const { vx } = computeReleaseVelocity(session.samples);
                if (shouldCommitSwipeAction({ state: rowSwipeState, velocityX: vx })) {
                  triggerHapticComplete();
                  if (rowSwipeState.direction === 'right') {
                    handleSingleRefresh(null, feed);
                  } else if (rowSwipeState.direction === 'left') {
                    setMovingFeed(feed);
                  }
                }
              }
            }
            setSwipingFeedId(null);
            setRowSwipeState(INITIAL_ROW_SWIPE);
          }}
          onPointerCancel={(e) => {
            const session = rowTouchStartRef.current;
            rowTouchStartRef.current = null;
            if (session) {
              try {
                if (e.currentTarget.hasPointerCapture(session.pointerId)) {
                  e.currentTarget.releasePointerCapture(session.pointerId);
                }
              } catch {}
            }
            setSwipingFeedId(null);
            setRowSwipeState(INITIAL_ROW_SWIPE);
          }}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              onSelectSource(feed);
            }
          }}
          style={{
            touchAction: 'pan-y',
            transform:
              activeSwipe && activeSwipe.offsetX !== 0
                ? `translate3d(${activeSwipe.offsetX}px, 0, 0)`
                : undefined,
            transition:
              activeSwipe && activeSwipe.offsetX !== 0
                ? 'none'
                : 'transform 220ms cubic-bezier(0.22, 1, 0.36, 1)',
          }}
          className={`px-4 py-3 flex items-center justify-between gap-3 cursor-pointer select-none transition-colors ${
            isSelected
              ? 'bg-[#FF6719]/10 dark:bg-[#FF6719]/15'
              : 'hover:bg-stone-100/70 dark:hover:bg-white/[0.03] active:bg-stone-200/50 dark:active:bg-white/[0.06]'
          }`}
        >
          <div className="flex items-center gap-3 min-w-0 flex-1">
            <SourceAvatar name={feed.title} url={feed.url} size="md" />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <span className="font-serif font-semibold text-[15px] text-stone-900 dark:text-stone-100 truncate">
                  {feed.title}
                </span>
                {isSelected && (
                  <span className="w-1.5 h-1.5 rounded-full bg-[#FF6719] shrink-0" />
                )}
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-stone-400 dark:text-stone-500 truncate">
                <span className="truncate">{cleanDomainLabel(feed.siteUrl || feed.url)}</span>
                {totalCount > 0 && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{totalCount} stories</span>
                  </>
                )}
                {latestTs && formatRelativeTime(latestTs) && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span>{formatRelativeTime(latestTs)}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Minimalist iOS Trailing Controls */}
          <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
            {unread > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[11px] font-mono font-bold tabular-nums bg-[#FF6719]/15 text-[#FF6719] mr-0.5">
                {unread}
              </span>
            )}

            <button
              type="button"
              onClick={(e) => handleSingleRefresh(e, feed)}
              disabled={isThisRefreshing || isOffline}
              aria-label={`Sync ${feed.title}`}
              title="Sync source"
              className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-stone-800 dark:hover:text-white hover:bg-stone-200/50 dark:hover:bg-white/10 transition-colors"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${isThisRefreshing ? 'animate-spin text-[#FF6719]' : ''}`}
              />
            </button>

            <button
              type="button"
              onClick={() => {
                triggerHapticSelection();
                setMovingFeed(feed);
                setIsCreatingFolderInMove(false);
                setMoveNewFolderName('');
              }}
              aria-label={`Organize ${feed.title}`}
              title="Move to folder"
              className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-[#FF6719] hover:bg-stone-200/50 dark:hover:bg-white/10 transition-colors"
            >
              <FolderInput className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => {
                triggerHapticSelection();
                onDeleteFeed(feed.id);
              }}
              aria-label={`Remove ${feed.title}`}
              title="Remove source"
              className="w-8 h-8 rounded-full flex items-center justify-center text-stone-400 hover:text-red-500 hover:bg-red-500/10 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 relative flex flex-col h-full overflow-hidden bg-stone-50 dark:bg-[#090A0C]">
      {/* Progressive Top Blur Mask */}
      <div
        aria-hidden="true"
        className="top-progressive-blur absolute top-0 left-0 right-0 h-28 z-10 pointer-events-none"
      />

      {/* Minimalist iOS Header + Always-Ready Smart Add Bar */}
      <header className="shrink-0 px-4 pt-[max(env(safe-area-inset-top,0px),0.75rem)] pb-2.5 z-20 space-y-2.5">
        <div className="flex items-center justify-between gap-2 pt-1">
          <div className="flex items-baseline gap-2 pl-0.5">
            <h1 className="font-serif text-2xl font-bold tracking-tight text-stone-900 dark:text-white">
              Sources
            </h1>
            {feeds.length > 0 && (
              <span className="text-xs font-mono tabular-nums text-stone-400 dark:text-stone-500">
                {feeds.length}
              </span>
            )}
          </div>

          {/* Right Pill: Filter, Folder, Travel Dispatch, Sync All */}
          <div className="liquid-glass-pill h-10 px-2 rounded-full flex items-center gap-0.5">
            {feeds.length > 2 && (
              <button
                type="button"
                onClick={() => {
                  triggerHapticSelection();
                  setShowFilterSearch((v) => !v);
                }}
                aria-label="Filter your sources"
                title="Filter sources"
                className={`w-8 h-8 flex items-center justify-center rounded-full transition-colors active:scale-90 ${
                  showFilterSearch
                    ? 'text-[#FF6719]'
                    : 'text-stone-700 dark:text-stone-200 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                <Search className="w-4 h-4 stroke-[2]" />
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                triggerHapticSelection();
                setIsNewFolderOpen((v) => !v);
                setIsBlogComposerOpen(false);
              }}
              aria-label="Create folder"
              title="New Folder"
              className={`w-8 h-8 flex items-center justify-center rounded-full transition-colors active:scale-90 ${
                isNewFolderOpen
                  ? 'text-[#FF6719]'
                  : 'text-stone-700 dark:text-stone-200 hover:text-stone-900 dark:hover:text-white'
              }`}
            >
              <FolderPlus className="w-4 h-4 stroke-[2]" />
            </button>

            {onPublishTravelBlog && (
              <button
                type="button"
                onClick={() => {
                  triggerHapticSelection();
                  setIsBlogComposerOpen((v) => !v);
                  setIsNewFolderOpen(false);
                }}
                aria-label="Share travel dispatch"
                title="Write Travel Dispatch"
                className={`w-8 h-8 flex items-center justify-center rounded-full transition-colors active:scale-90 ${
                  isBlogComposerOpen
                    ? 'text-emerald-500'
                    : 'text-stone-700 dark:text-stone-200 hover:text-stone-900 dark:hover:text-white'
                }`}
              >
                <Compass className="w-4 h-4 stroke-[2]" />
              </button>
            )}

            <button
              type="button"
              onClick={() => {
                triggerHapticSelection();
                onRefreshAll();
              }}
              disabled={isRefreshing || isOffline || feeds.length === 0}
              aria-label="Sync all sources"
              title="Sync all sources"
              className="w-8 h-8 flex items-center justify-center rounded-full text-stone-700 dark:text-stone-200 hover:text-stone-900 dark:hover:text-white disabled:opacity-35 transition-transform active:scale-90"
            >
              <RefreshCw
                className={`w-4 h-4 stroke-[2] ${isRefreshing ? 'animate-spin text-[#FF6719]' : ''}`}
              />
            </button>
          </div>
        </div>

        {/* Always-Visible 1-Step Smart Add Source Omnibar */}
        <form
          onSubmit={handleOmnibarSubmit}
          className="liquid-glass-pill rounded-2xl p-1.5 pl-3.5 flex items-center gap-2 border border-stone-200/80 dark:border-white/15 shadow-sm"
        >
          <Globe className="w-4 h-4 text-[#FF6719] shrink-0" />
          <input
            type="text"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            disabled={isLoadingDirectUrl}
            placeholder="Add website or RSS link (e.g. thedailystar.net)..."
            aria-label="Add website or RSS URL"
            className="flex-1 bg-transparent text-xs text-stone-900 dark:text-white placeholder-stone-400 dark:placeholder-stone-400 focus:outline-none min-w-0"
          />
          {urlInput && !isLoadingDirectUrl && (
            <button
              type="button"
              onClick={() => setUrlInput('')}
              aria-label="Clear URL input"
              className="p-1 text-stone-400 hover:text-stone-600 dark:hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
          <button
            type="submit"
            disabled={!urlInput.trim() || isLoadingDirectUrl}
            className="px-3.5 py-2 rounded-xl bg-[#FF6719] hover:bg-[#e8560b] disabled:opacity-40 text-white text-xs font-semibold flex items-center gap-1.5 shrink-0 transition-all active:scale-95 shadow-xs"
          >
            {isLoadingDirectUrl ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Adding…</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
                <span>Add</span>
              </>
            )}
          </button>
        </form>

        {/* Optional Filter Bar when user has multiple sources */}
        {showFilterSearch && (
          <div className="liquid-glass-pill rounded-full px-3.5 py-1.5 flex items-center gap-2 animate-in fade-in duration-150">
            <Search className="w-3.5 h-3.5 text-stone-400 shrink-0" />
            <input
              type="search"
              autoFocus
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder="Filter your subscribed sources..."
              className="w-full bg-transparent text-xs text-stone-900 dark:text-white placeholder-stone-400 focus:outline-none"
            />
            {filterQuery && (
              <button
                type="button"
                onClick={() => setFilterQuery('')}
                className="text-stone-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}
      </header>

      {/* Main Scrollable Content */}
      <div className="flex-1 overflow-y-auto px-4 py-2 pb-28 space-y-4 no-scrollbar">
        {/* New Folder Inline Sheet */}
        {isNewFolderOpen && (
          <form
            onSubmit={handleCreateFolderSubmit}
            className="p-3.5 rounded-2xl liquid-glass border border-[#FF6719]/30 space-y-2.5 animate-in fade-in duration-150"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-stone-900 dark:text-stone-100">
                New Folder
              </span>
              <button
                type="button"
                onClick={() => setIsNewFolderOpen(false)}
                className="text-[11px] text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
              >
                Cancel
              </button>
            </div>
            <div className="flex items-center gap-2">
              <input
                type="text"
                required
                autoFocus
                value={newFolderName}
                onChange={(e) => setNewFolderName(e.target.value)}
                placeholder="Folder name (e.g. Bangladesh, Finance, Tech)..."
                className="flex-1 px-3 py-2 rounded-xl text-xs bg-white/80 dark:bg-black/40 border border-stone-200/80 dark:border-white/[0.08] text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none focus:ring-1 focus:ring-[#FF6719]"
              />
              <button
                type="submit"
                disabled={!newFolderName.trim()}
                className="px-4 py-2 bg-[#FF6719] text-white rounded-xl text-xs font-semibold disabled:opacity-40"
              >
                Create
              </button>
            </div>
          </form>
        )}

        {/* Travel Dispatch Composer Sheet */}
        {isBlogComposerOpen && onPublishTravelBlog && (
          <form
            onSubmit={handlePublishBlogSubmit}
            className="p-3.5 rounded-2xl liquid-glass border border-emerald-500/35 space-y-2.5 animate-in fade-in duration-150"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-emerald-500" />
                <span className="text-xs font-semibold text-stone-900 dark:text-stone-100">
                  Publish Travel Dispatch
                </span>
              </div>
              <button
                type="button"
                onClick={() => setIsBlogComposerOpen(false)}
                className="text-[11px] text-stone-400 hover:text-stone-600 dark:hover:text-stone-200"
              >
                Cancel
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                required
                value={blogAuthor}
                onChange={(e) => setBlogAuthor(e.target.value)}
                placeholder="Your Name *"
                className="px-3 py-2 rounded-xl text-xs bg-white/80 dark:bg-black/40 border border-stone-200/80 dark:border-white/[0.08] text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none"
              />
              <input
                type="text"
                value={blogGroupName}
                onChange={(e) => setBlogGroupName(e.target.value)}
                placeholder="Travel Group"
                className="px-3 py-2 rounded-xl text-xs bg-white/80 dark:bg-black/40 border border-stone-200/80 dark:border-white/[0.08] text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={blogLocation}
                onChange={(e) => setBlogLocation(e.target.value)}
                placeholder="Location (e.g. Bandarban)"
                className="px-3 py-2 rounded-xl text-xs bg-white/80 dark:bg-black/40 border border-stone-200/80 dark:border-white/[0.08] text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none"
              />
              <input
                type="text"
                value={blogContact}
                onChange={(e) => setBlogContact(e.target.value)}
                placeholder="Group Link / Contact"
                className="px-3 py-2 rounded-xl text-xs bg-white/80 dark:bg-black/40 border border-stone-200/80 dark:border-white/[0.08] text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none"
              />
            </div>

            <input
              type="text"
              required
              value={blogTitle}
              onChange={(e) => setBlogTitle(e.target.value)}
              placeholder="Headline *"
              className="w-full px-3 py-2 rounded-xl text-xs bg-white/80 dark:bg-black/40 border border-stone-200/80 dark:border-white/[0.08] text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none"
            />

            <textarea
              required
              rows={3}
              value={blogContent}
              onChange={(e) => setBlogContent(e.target.value)}
              placeholder="Share your trail notes or expedition story (min 20 chars)..."
              className="w-full px-3 py-2 rounded-xl text-xs bg-white/80 dark:bg-black/40 border border-stone-200/80 dark:border-white/[0.08] text-stone-900 dark:text-stone-100 placeholder-stone-400 focus:outline-none resize-none"
            />

            <button
              type="submit"
              disabled={isPublishingBlog || !blogTitle.trim() || !blogAuthor.trim() || blogContent.trim().length < 20}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold disabled:opacity-40 flex items-center justify-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isPublishingBlog ? 'Publishing…' : 'Publish Dispatch'}</span>
            </button>
          </form>
        )}

        {/* EMPTY STATE: When user has 0 sources added yet */}
        {feeds.length === 0 && (
          <div className="p-5 rounded-3xl liquid-glass border border-stone-200/70 dark:border-white/[0.08] text-center space-y-2">
            <div className="w-10 h-10 rounded-2xl bg-[#FF6719]/15 text-[#FF6719] flex items-center justify-center mx-auto">
              <Globe className="w-5 h-5" />
            </div>
            <h2 className="font-serif text-base font-bold text-stone-900 dark:text-stone-100">
              Build Your Personal Newsfeed
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400 max-w-xs mx-auto leading-relaxed">
              Your reader starts completely clean. Paste any website or RSS link above, or tap any source below to add it instantly.
            </p>
          </div>
        )}

        {/* SUBSCRIBED SOURCES LIST (Grouped cleanly like iOS Settings / Reeder) */}
        {uncategorizedFeeds.length > 0 && (
          <div className="space-y-1.5">
            <div className="px-1 flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-stone-400 dark:text-stone-500">
              <span>Subscribed Sources</span>
              <span>Swipe right to sync · left for folder</span>
            </div>
            <section className="rounded-2xl liquid-glass overflow-hidden divide-y divide-stone-200/50 dark:divide-white/[0.06]">
              {uncategorizedFeeds.map((feed) => renderSourceRow(feed))}
            </section>
          </div>
        )}

        {/* FOLDER GROUPS */}
        {groupedByFolder.map(([folderName, folderFeeds]) => {
          const isCollapsed = Boolean(collapsedFolders[folderName]);
          const isFolderSelected = selectedFolder === folderName && !selectedFeedId;
          const folderUnread = folderFeeds.reduce(
            (sum, f) => sum + (feedStats.unread[f.id] || 0),
            0
          );

          return (
            <section
              key={folderName}
              className={`rounded-2xl liquid-glass overflow-hidden transition-all ${
                isFolderSelected ? 'ring-1.5 ring-[#FF6719]' : ''
              }`}
            >
              <div
                onClick={() => {
                  triggerHapticSelection();
                  onSelectFolder(folderName);
                }}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    onSelectFolder(folderName);
                  }
                }}
                className="px-4 py-2.5 flex items-center justify-between gap-2 cursor-pointer select-none bg-stone-100/60 dark:bg-white/[0.02] border-b border-stone-200/50 dark:border-white/[0.06]"
              >
                <div className="flex items-center gap-2 min-w-0 flex-1">
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      triggerHapticSelection();
                      setCollapsedFolders((prev) => ({
                        ...prev,
                        [folderName]: !prev[folderName],
                      }));
                    }}
                    aria-label={isCollapsed ? `Expand ${folderName}` : `Collapse ${folderName}`}
                    className="p-1 -ml-1 rounded-lg text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
                  >
                    {isCollapsed ? (
                      <ChevronRight className="w-3.5 h-3.5" />
                    ) : (
                      <ChevronDown className="w-3.5 h-3.5" />
                    )}
                  </button>
                  <Folder className="w-4 h-4 text-[#FF6719] shrink-0" />
                  <span className="font-serif font-semibold text-sm text-stone-900 dark:text-stone-100 truncate">
                    {folderName}
                  </span>
                  <span className="text-[11px] font-mono text-stone-400">
                    ({folderFeeds.length})
                  </span>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  {folderUnread > 0 && (
                    <span className="text-[11px] font-mono text-[#FF6719] font-semibold">
                      {folderUnread} new
                    </span>
                  )}
                  <span className="text-[11px] font-semibold text-stone-500 dark:text-stone-300 flex items-center gap-0.5">
                    <span>Open</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </span>
                </div>
              </div>

              {!isCollapsed && (
                <div className="divide-y divide-stone-200/50 dark:divide-white/[0.06]">
                  {folderFeeds.map((feed) => renderSourceRow(feed))}
                  {folderFeeds.length === 0 && (
                    <div className="px-4 py-3 text-xs text-stone-400">
                      Empty folder — tap the folder icon on any source to move it here.
                    </div>
                  )}
                </div>
              )}
            </section>
          );
        })}

        {/* 1-TAP QUICK ADD DIRECTORY (Always available when empty, or toggleable when populated) */}
        <div className="space-y-2 pt-1">
          <div className="px-1 flex items-center justify-between">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-stone-400 dark:text-stone-500 flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-[#FF6719]" />
              <span>Quick-Add Newspapers & Portals</span>
            </span>
            {feeds.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  triggerHapticSelection();
                  setShowQuickCatalog((v) => !v);
                }}
                className="text-[11px] font-semibold text-[#FF6719]"
              >
                {showQuickCatalog ? 'Hide' : 'Show Directory'}
              </button>
            )}
          </div>

          {(feeds.length === 0 || showQuickCatalog) && (
            <div className="rounded-2xl liquid-glass overflow-hidden divide-y divide-stone-200/50 dark:divide-white/[0.06]">
              {QUICK_STARTER_CATALOG.map((item) => {
                const isAdded = feeds.some(
                  (f) => f.url === item.url || (f.siteUrl && f.siteUrl === item.siteUrl)
                );
                return (
                  <div
                    key={item.url}
                    className="px-4 py-2.5 flex items-center justify-between gap-3"
                  >
                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      <SourceAvatar name={item.title} url={item.siteUrl} size="sm" />
                      <div className="min-w-0 flex-1">
                        <span className="font-serif font-semibold text-sm text-stone-900 dark:text-stone-100 block truncate">
                          {item.title}
                        </span>
                        <span className="text-[11px] text-stone-400 dark:text-stone-500 block truncate">
                          {item.subtitle}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      disabled={isAdded}
                      onClick={() => handleQuickAddStarter(item)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1 shrink-0 transition-all active:scale-95 ${
                        isAdded
                          ? 'bg-emerald-500/15 text-emerald-500 cursor-default'
                          : 'bg-stone-900 dark:bg-white text-white dark:text-stone-900 hover:opacity-90'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3.5 h-3.5" />
                          <span>Added</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" />
                          <span>Add</span>
                        </>
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer: OPML Import / Export */}
        <div className="pt-2 pb-4 flex items-center justify-center gap-4 text-xs text-stone-400">
          <button
            type="button"
            onClick={() => {
              triggerHapticSelection();
              onOpenFeedModal();
            }}
            className="flex items-center gap-1.5 hover:text-stone-700 dark:hover:text-stone-200 transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import / Export OPML</span>
            <Download className="w-3.5 h-3.5 ml-0.5" />
          </button>
        </div>
      </div>

      {/* Move Source to Folder Modal */}
      {movingFeed && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setMovingFeed(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xs liquid-glass rounded-3xl p-4 shadow-2xl border border-white/30 dark:border-white/15 text-stone-900 dark:text-stone-100 space-y-3 animate-in zoom-in-95 duration-150"
          >
            <div className="flex items-center justify-between pb-2.5 border-b border-stone-200/60 dark:border-white/10">
              <div className="min-w-0 pr-2">
                <span className="text-[11px] uppercase tracking-wider font-semibold text-stone-400 block">
                  Organize Source
                </span>
                <span className="font-serif font-semibold text-sm truncate block">
                  {movingFeed.title}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setMovingFeed(null)}
                className="p-1 rounded-full text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 max-h-60 overflow-y-auto no-scrollbar">
              <button
                type="button"
                onClick={() => {
                  triggerHapticComplete();
                  onMoveFeedToFolder(movingFeed.id, '');
                  setMovingFeed(null);
                }}
                className={`w-full px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                  !movingFeed.category?.trim()
                    ? 'bg-[#FF6719]/15 text-[#FF6719] font-semibold'
                    : 'hover:bg-stone-200/60 dark:hover:bg-white/[0.06] text-stone-600 dark:text-stone-300'
                }`}
              >
                <span>No Folder (Main List)</span>
                {!movingFeed.category?.trim() && <Check className="w-3.5 h-3.5 text-[#FF6719]" />}
              </button>

              {allFolders.map((folder) => {
                const isCurrent = (movingFeed.category?.trim() || '') === folder;
                return (
                  <button
                    key={folder}
                    type="button"
                    onClick={() => {
                      triggerHapticComplete();
                      onMoveFeedToFolder(movingFeed.id, folder);
                      setMovingFeed(null);
                    }}
                    className={`w-full px-3 py-2 rounded-xl text-xs flex items-center justify-between transition-colors ${
                      isCurrent
                        ? 'bg-[#FF6719]/15 text-[#FF6719] font-semibold'
                        : 'hover:bg-stone-200/60 dark:hover:bg-white/[0.06] text-stone-800 dark:text-stone-200'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Folder className="w-3.5 h-3.5 text-[#FF6719] shrink-0" />
                      <span className="truncate">{folder}</span>
                    </div>
                    {isCurrent && <Check className="w-3.5 h-3.5 text-[#FF6719] shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="pt-2 border-t border-stone-200/60 dark:border-white/10">
              {isCreatingFolderInMove ? (
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    if (!moveNewFolderName.trim()) return;
                    triggerHapticComplete();
                    onMoveFeedToFolder(movingFeed.id, moveNewFolderName.trim());
                    setMovingFeed(null);
                  }}
                  className="flex items-center gap-1.5"
                >
                  <input
                    type="text"
                    autoFocus
                    value={moveNewFolderName}
                    onChange={(e) => setMoveNewFolderName(e.target.value)}
                    placeholder="New folder name..."
                    className="flex-1 px-2.5 py-1.5 rounded-xl text-xs bg-white/80 dark:bg-black/40 border border-[#FF6719]/50 text-stone-900 dark:text-stone-100 focus:outline-none"
                  />
                  <button
                    type="submit"
                    disabled={!moveNewFolderName.trim()}
                    className="px-3 py-1.5 bg-[#FF6719] text-white rounded-xl text-xs font-semibold disabled:opacity-40"
                  >
                    Move
                  </button>
                </form>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsCreatingFolderInMove(true)}
                  className="w-full py-1.5 text-xs font-semibold text-[#FF6719] flex items-center justify-center gap-1.5 hover:opacity-80"
                >
                  <FolderPlus className="w-3.5 h-3.5" />
                  <span>+ Move to New Folder</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
