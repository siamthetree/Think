import React, { useMemo, useState, useRef } from 'react';
import { X, Layers, BookOpen, RefreshCw, Clock, CheckCircle2 } from 'lucide-react';
import type { FeedItem } from '../types';
import { findPerspectivesAcrossSources, extractSignificantTokens } from '../utils/feedIntelligence';
import { formatRelativeTime } from '../utils/feedParser';
import { SourceAvatar } from './SourceAvatar';
import { triggerHapticSelection } from '../utils/haptics';
import { computeSheetDragState } from '../utils/touchGestures';

interface PerspectivesModalProps {
  targetArticle: FeedItem | null;
  allArticles: FeedItem[];
  totalSourcesCount: number;
  isSearchingSources: boolean;
  isLoadingArticleId?: string | null;
  onClose: () => void;
  onSelectArticle: (article: FeedItem) => void;
  onRefreshAllSources: () => void;
}

export const PerspectivesModal: React.FC<PerspectivesModalProps> = ({
  targetArticle,
  allArticles,
  totalSourcesCount,
  isSearchingSources,
  isLoadingArticleId = null,
  onClose,
  onSelectArticle,
  onRefreshAllSources,
}) => {
  const [dragOffsetY, setDragOffsetY] = useState(0);
  const dragStartRef = useRef<{ y: number; time: number } | null>(null);

  const matches = useMemo(() => {
    if (!targetArticle) return [];
    return findPerspectivesAcrossSources(targetArticle, allArticles);
  }, [targetArticle, allArticles]);

  const topicTokens = useMemo(() => {
    if (!targetArticle) return [];
    return extractSignificantTokens(targetArticle.title).slice(0, 6);
  }, [targetArticle]);

  if (!targetArticle) return null;

  const handlePointerDown = (e: React.PointerEvent) => {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    dragStartRef.current = { y: e.clientY, time: Date.now() };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragStartRef.current) return;
    if (e.pointerType !== 'touch' && e.buttons !== 1) return;
    const dy = e.clientY - dragStartRef.current.y;
    const state = computeSheetDragState(dy, 0, 84);
    setDragOffsetY(state.offsetY);
  };

  const handlePointerUpOrCancel = (e: React.PointerEvent) => {
    if (!dragStartRef.current) return;
    const dy = e.clientY - dragStartRef.current.y;
    const dt = Math.max(1, Date.now() - dragStartRef.current.time);
    const velocityY = dy / dt;
    dragStartRef.current = null;

    const state = computeSheetDragState(dy, velocityY, 84);
    setDragOffsetY(0);
    if (state.shouldDismiss) {
      triggerHapticSelection();
      onClose();
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Same Topic & Story Perspectives"
      onClick={onClose}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 pb-8 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150"
    >
      <div
        onClick={(e) => e.stopPropagation()}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUpOrCancel}
        onPointerCancel={handlePointerUpOrCancel}
        style={{
          touchAction: 'none',
          transform: dragOffsetY !== 0 ? `translate3d(0, ${dragOffsetY}px, 0)` : undefined,
          transition:
            dragOffsetY !== 0 ? 'none' : 'transform 220ms cubic-bezier(0.22, 1, 0.36, 1)',
        }}
        className="w-full max-w-md max-h-[82vh] flex flex-col rounded-3xl reader-liquid-card p-5 text-stone-100 shadow-2xl border border-white/20 animate-in zoom-in-95 duration-150 select-none"
      >
        {/* Drag Handle */}
        <div className="w-10 h-1 bg-white/25 rounded-full mx-auto mb-3 shrink-0 cursor-grab active:cursor-grabbing" />

        {/* Header */}
        <div className="flex items-center justify-between gap-2 pb-3 mb-3 border-b border-white/10 shrink-0">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#FF6719] shrink-0" />
              <span className="text-xs font-semibold text-stone-100 truncate">
                Same Topic & Story ({matches.length + 1} {matches.length === 0 ? 'Report' : 'Reports'})
              </span>
            </div>
            <span className="text-[10.5px] text-stone-400 block mt-0.5 truncate">
              Matched by story subject across {totalSourcesCount} added sources
            </span>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() => {
                triggerHapticSelection();
                onRefreshAllSources();
              }}
              disabled={isSearchingSources}
              aria-label="Re-scan all sources"
              title="Scan all sources for fresh coverage of this story"
              className="min-w-[34px] min-h-[34px] rounded-full flex items-center justify-center text-stone-300 hover:text-white hover:bg-white/10 transition-colors disabled:opacity-40"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSearchingSources ? 'animate-spin text-[#FF6719]' : ''}`} />
            </button>
            <button
              type="button"
              onClick={() => {
                triggerHapticSelection();
                onClose();
              }}
              aria-label="Close perspectives modal"
              className="min-w-[34px] min-h-[34px] rounded-full flex items-center justify-center text-stone-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Searching Status Banner */}
        {isSearchingSources && (
          <div className="mb-3 px-3.5 py-2 rounded-2xl bg-[#FF6719]/15 border border-[#FF6719]/35 text-xs text-stone-100 flex items-center gap-2.5 shrink-0">
            <div className="w-3.5 h-3.5 border-2 border-[#FF6719] border-t-transparent rounded-full animate-spin shrink-0" />
            <span>Searching all {totalSourcesCount} sources for this specific topic & story…</span>
          </div>
        )}

        {/* Specific Story Topic Keywords (never generic category tags) */}
        {topicTokens.length > 0 && (
          <div className="flex flex-wrap items-center gap-1.5 mb-3 shrink-0">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-stone-400 mr-1">
              Story Topic:
            </span>
            {topicTokens.map((token) => (
              <span
                key={token}
                className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-white/10 text-stone-200 border border-white/10"
              >
                {token}
              </span>
            ))}
          </div>
        )}

        {/* Scrollable List of Primary Story + Matching Perspectives Across All Sources */}
        <div
          className="flex-1 overflow-y-auto space-y-2.5 pr-0.5 no-scrollbar"
          style={{ touchAction: 'pan-y' }}
        >
          {/* Origin Story Card */}
          <div
            onClick={() => {
              triggerHapticSelection();
              onSelectArticle(targetArticle);
            }}
            className="p-3.5 rounded-2xl bg-white/[0.08] hover:bg-white/[0.12] border border-[#FF6719]/45 cursor-pointer transition-colors"
          >
            <div className="flex items-center justify-between gap-2 text-[11px] text-stone-300 mb-1">
              <div className="flex items-center gap-1.5 min-w-0">
                <SourceAvatar name={targetArticle.feedTitle} url={targetArticle.feedUrl} size="sm" />
                <span className="font-semibold text-white truncate">{targetArticle.feedTitle}</span>
                <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold uppercase bg-[#FF6719] text-white">
                  Selected Story
                </span>
              </div>
              <span className="whitespace-nowrap text-stone-400">
                {formatRelativeTime(targetArticle.timestamp)}
              </span>
            </div>

            <h3 className="font-serif text-sm font-bold text-white leading-snug mb-1.5">
              {targetArticle.title}
            </h3>

            <div className="flex items-center justify-between text-[11px] text-stone-400">
              <span className="flex items-center gap-1 tabular-nums">
                <Clock className="w-3 h-3" />
                {targetArticle.readTimeMin || 3}m read
              </span>
              <span className="text-[#FF6719] font-semibold flex items-center gap-1">
                <BookOpen className="w-3 h-3" />
                {isLoadingArticleId === targetArticle.id ? 'Loading full story…' : 'Open Full Reader →'}
              </span>
            </div>
          </div>

          {/* Matching Coverage on the Same Topic & Story from Other Sources */}
          {matches.length > 0 ? (
            matches.map(({ article: matchArt, sharedKeywords }) => {
              const isOpeningThis = isLoadingArticleId === matchArt.id;
              return (
                <div
                  key={matchArt.id}
                  onClick={() => {
                    triggerHapticSelection();
                    onSelectArticle(matchArt);
                  }}
                  className="p-3.5 rounded-2xl bg-black/35 hover:bg-white/[0.08] border border-white/10 cursor-pointer transition-colors"
                >
                  <div className="flex items-center justify-between gap-2 text-[11px] text-stone-400 mb-1">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <SourceAvatar name={matchArt.feedTitle} url={matchArt.feedUrl} size="sm" />
                      <span className="font-semibold text-stone-200 truncate">
                        {matchArt.feedTitle}
                      </span>
                    </div>
                    <span className="whitespace-nowrap">{formatRelativeTime(matchArt.timestamp)}</span>
                  </div>

                  <h4 className="font-serif text-sm font-bold text-stone-100 leading-snug mb-1">
                    {matchArt.title}
                  </h4>

                  {matchArt.summary && (
                    <p className="text-xs text-stone-400 line-clamp-2 leading-relaxed mb-2">
                      {matchArt.summary}
                    </p>
                  )}

                  <div className="flex items-center justify-between text-[11px] text-stone-400 pt-1 border-t border-white/5">
                    <span className="truncate max-w-[185px] font-mono text-[10px] text-emerald-400/90">
                      {sharedKeywords.length > 0
                        ? `Topic match: ${sharedKeywords.join(' · ')}`
                        : `${matchArt.readTimeMin || 3}m read`}
                    </span>
                    <span className="text-[#FF6719] font-semibold shrink-0">
                      {isOpeningThis ? 'Loading full story…' : 'Read Full Story →'}
                    </span>
                  </div>
                </div>
              );
            })
          ) : (
            !isSearchingSources && (
              <div className="p-5 rounded-2xl bg-black/30 border border-white/10 text-center space-y-2">
                <CheckCircle2 className="w-5 h-5 text-stone-400 mx-auto" />
                <p className="font-serif text-sm font-semibold text-stone-200">
                  No Other Coverage on This Exact Story Yet
                </p>
                <p className="text-xs text-stone-400 leading-relaxed">
                  Scanned all {totalSourcesCount} added sources by story topic (ignoring general categories). Only {targetArticle.feedTitle} has published on this specific event so far.
                </p>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};
