import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import fsPromises from 'fs/promises';
import * as cheerio from 'cheerio';
import type { Element } from 'domhandler';
import { GoogleGenAI } from '@google/genai';
import {
  parseXmlFeed,
  parseHtmlPortalToFeed,
  stripHtml,
  resolveUrl,
  calculateReadTime,
} from './src/utils/feedParser';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Allow CORS for native iOS Capacitor IPA builds (capacitor://localhost) and web clients
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(204);
    return;
  }
  next();
});

// Curated Bangladeshi & International newspaper portals and Travel Community Blogs
const CURATED_FEEDS = [
  {
    id: 'travel_blogs_bd',
    title: 'Bangladeshi Travel Groups & Dispatches',
    url: '/api/blogs',
    siteUrl: 'https://chinta.app/travel',
    description: 'Community blogs, trail guides, and expedition stories written by Bangladeshi travelers & groups.',
    category: 'Travel & Expeditions',
    defaultTags: ['tag_travel', 'tag_bd'],
  },
  {
    id: 'daily_star',
    title: 'The Daily Star',
    url: 'https://www.thedailystar.net/rss.xml',
    siteUrl: 'https://www.thedailystar.net',
    description: 'Leading English-language daily newspaper in Bangladesh.',
    category: 'Bangladesh',
    defaultTags: ['tag_bd', 'tag_world'],
  },
  {
    id: 'prothom_alo_en',
    title: 'Prothom Alo (English)',
    url: 'https://en.prothomalo.com/feed',
    siteUrl: 'https://en.prothomalo.com',
    description: 'National news, politics, economy, and views from Prothom Alo English.',
    category: 'Bangladesh',
    defaultTags: ['tag_bd', 'tag_investigative'],
  },
  {
    id: 'prothom_alo_bn',
    title: 'প্রথম আলো (Prothom Alo Bangla)',
    url: 'https://www.prothomalo.com/feed',
    siteUrl: 'https://www.prothomalo.com',
    description: 'বাংলাদেশের শীর্ষস্থানীয় বাংলা দৈনিক পত্রিকা।',
    category: 'Bangladesh (বাংলা)',
    defaultTags: ['tag_bd'],
  },
  {
    id: 'bdnews24',
    title: 'bdnews24.com',
    url: 'https://bdnews24.com',
    siteUrl: 'https://bdnews24.com',
    description: 'Bangladesh’s first bilingual online newspaper (Direct Portal Reader).',
    category: 'Bangladesh',
    defaultTags: ['tag_bd', 'tag_breaking'],
  },
  {
    id: 'fe_bd',
    title: 'The Financial Express (BD)',
    url: 'https://thefinancialexpress.com.bd',
    siteUrl: 'https://thefinancialexpress.com.bd',
    description: 'Financial, economic, trade, and market news from Dhaka (Direct Portal Reader).',
    category: 'Bangladesh Finance',
    defaultTags: ['tag_bd', 'tag_markets'],
  },
  {
    id: 'tbs_news',
    title: 'The Business Standard (TBS)',
    url: 'https://www.tbsnews.net',
    siteUrl: 'https://www.tbsnews.net',
    description: 'Business, economy, policy, and analysis from Bangladesh.',
    category: 'Bangladesh Finance',
    defaultTags: ['tag_bd', 'tag_markets'],
  },
  {
    id: 'dhaka_tribune',
    title: 'Dhaka Tribune',
    url: 'https://www.dhakatribune.com',
    siteUrl: 'https://www.dhakatribune.com',
    description: 'National and international coverage from Dhaka.',
    category: 'Bangladesh',
    defaultTags: ['tag_bd', 'tag_world'],
  },
  {
    id: 'new_age_bd',
    title: 'New Age Bangladesh',
    url: 'https://www.newagebd.net',
    siteUrl: 'https://www.newagebd.net',
    description: 'Outspoken daily English newspaper published from Dhaka.',
    category: 'Bangladesh',
    defaultTags: ['tag_bd', 'tag_opinion'],
  },
  {
    id: 'bbc_world',
    title: 'BBC News',
    url: 'https://feeds.bbci.co.uk/news/world/rss.xml',
    siteUrl: 'https://bbc.com/news',
    description: 'International news, analysis and features from the BBC.',
    category: 'World',
    defaultTags: ['tag_world', 'tag_breaking'],
  },
  {
    id: 'guardian_world',
    title: 'The Guardian',
    url: 'https://www.theguardian.com/world/rss',
    siteUrl: 'https://theguardian.com',
    description: 'Independent international journalism and long-form analysis.',
    category: 'World',
    defaultTags: ['tag_world', 'tag_opinion'],
  },
];

// Helper to fetch with realistic browser User-Agent
async function fetchWithUserAgent(
  targetUrl: string,
  timeoutMs = 8500
): Promise<{ text: string; contentType: string; finalUrl: string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const res = await fetch(targetUrl, {
      signal: controller.signal,
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        Accept:
          'text/html,application/xhtml+xml,application/rss+xml,application/atom+xml,application/xml;q=0.9,text/xml;q=0.8,*/*;q=0.7',
        'Accept-Language': 'en-US,en;q=0.9,bn;q=0.8',
      },
    });

    if (!res.ok) {
      throw new Error(`HTTP error ${res.status}: ${res.statusText}`);
    }

    const contentType = res.headers.get('content-type') || '';
    const text = await res.text();
    return { text, contentType, finalUrl: res.url || targetUrl };
  } finally {
    clearTimeout(timer);
  }
}

function isXmlFeedContent(text: string): boolean {
  const sample = text.slice(0, 1500);
  return sample.includes('<rss') || sample.includes('<feed') || sample.includes('<rdf:RDF');
}

/**
 * Resolves any URL — whether an XML RSS feed, a newspaper homepage with a hidden RSS link,
 * OR a Bangladeshi news portal that has NO RSS feed at all (via direct HTML scraping or domain index).
 */
async function loadPortalOrRssFeed(
  rawUrl: string,
  feedInfo: { id: string; title: string; defaultTags: string[] }
): Promise<{
  feedTitle: string;
  items: any[];
  resolvedUrl: string;
  sourceMode: 'rss' | 'direct_html' | 'domain_index';
}> {
  let url = rawUrl.trim();
  if (!/^https?:\/\//i.test(url)) {
    url = 'https://' + url;
  }

  let fetchedHtml = '';
  let fetchedUrl = url;

  // Step 1: Try fetching the given URL directly
  try {
    const { text, contentType, finalUrl } = await fetchWithUserAgent(url);
    fetchedUrl = finalUrl;

    if (isXmlFeedContent(text)) {
      const parsed = parseXmlFeed(text, { ...feedInfo, url: fetchedUrl });
      if (parsed.items.length > 0) {
        return { ...parsed, resolvedUrl: fetchedUrl, sourceMode: 'rss' };
      }
    }

    // If HTML, save it for direct HTML portal scraping if no RSS link exists
    if (contentType.includes('html') || text.includes('<html') || text.includes('<!DOCTYPE')) {
      fetchedHtml = text;
      const $ = cheerio.load(text);
      const rssLink = $('link[type="application/rss+xml"], link[type="application/atom+xml"]')
        .first()
        .attr('href');
      if (rssLink) {
        try {
          const resolvedLink = new URL(rssLink, fetchedUrl).href;
          const { text: feedText } = await fetchWithUserAgent(resolvedLink, 5500);
          if (isXmlFeedContent(feedText)) {
            const parsed = parseXmlFeed(feedText, { ...feedInfo, url: resolvedLink });
            if (parsed.items.length > 0) {
              return { ...parsed, resolvedUrl: resolvedLink, sourceMode: 'rss' };
            }
          }
        } catch {}
      }
    }
  } catch {
    // Will continue to candidate paths and domain fallback
  }

  // Step 2: Check common RSS endpoints (/rss.xml, /feed) only if user gave a root domain
  let parsedTarget: URL | null = null;
  try {
    parsedTarget = new URL(url);
  } catch {}

  if (parsedTarget && (parsedTarget.pathname === '/' || parsedTarget.pathname === '')) {
    const cleanBase = url.replace(/\/+$/, '');
    const candidatePaths = [`${cleanBase}/rss.xml`, `${cleanBase}/feed`];

    for (const candidate of candidatePaths) {
      try {
        const { text } = await fetchWithUserAgent(candidate, 4500);
        if (isXmlFeedContent(text)) {
          const parsed = parseXmlFeed(text, { ...feedInfo, url: candidate });
          if (parsed.items.length > 0) {
            return { ...parsed, resolvedUrl: candidate, sourceMode: 'rss' };
          }
        }
      } catch {}
    }
  }

  // Step 3: Direct HTML Portal Scraping! (For portals without RSS URL like bdnews24.com, thefinancialexpress.com.bd, etc.)
  if (fetchedHtml) {
    const htmlParsed = parseHtmlPortalToFeed(fetchedHtml, {
      ...feedInfo,
      url: fetchedUrl,
    });
    if (htmlParsed.items.length > 0) {
      return {
        ...htmlParsed,
        resolvedUrl: url,
        sourceMode: 'direct_html',
      };
    }
  }

  // Step 4: Fallback for Cloudflare-protected Bangladeshi portals (e.g., tbsnews.net, dhakatribune.com, jugantor.com)
  if (parsedTarget) {
    const hostname = parsedTarget.hostname.replace(/^www\./, '');
    const isBanglaDomain = /jugantor|kalerkantho|samakal|ittefaq|banglatribune|manabzamin|bonikbarta/i.test(hostname);
    const queryUrl = isBanglaDomain
      ? `https://news.google.com/rss/search?q=${encodeURIComponent(`site:${hostname}`)}&hl=bn&gl=BD&ceid=BD:bn`
      : `https://news.google.com/rss/search?q=${encodeURIComponent(`site:${hostname}`)}&hl=en-BD&gl=BD&ceid=BD:en`;

    try {
      const { text } = await fetchWithUserAgent(queryUrl, 6500);
      if (isXmlFeedContent(text)) {
        const parsed = parseXmlFeed(text, {
          ...feedInfo,
          title: feedInfo.title !== 'Newspaper Feed' ? feedInfo.title : hostname,
          url,
        });
        // Clean up Google News suffix in title & set feedTitle cleanly
        const cleanFeedTitle =
          feedInfo.title && feedInfo.title !== 'Newspaper Feed' && feedInfo.title !== 'RSS Feed'
            ? feedInfo.title
            : hostname;
        const cleanedItems = parsed.items.map((item) => ({
          ...item,
          feedTitle: cleanFeedTitle,
          title: item.title.replace(/\s+-\s+[^-]+$/, '').trim() || item.title,
          contentClean: '', // Trigger full extraction when opened
        }));

        if (cleanedItems.length > 0) {
          return {
            feedTitle: cleanFeedTitle,
            items: cleanedItems,
            resolvedUrl: url,
            sourceMode: 'domain_index',
          };
        }
      }
    } catch {}
  }

  throw new Error(`Could not load articles from "${rawUrl}". Please check the URL and try again.`);
}

// 1. Fetch and parse RSS or Direct HTML Portal
app.get('/api/rss', async (req: Request, res: Response) => {
  const feedUrl = req.query.url as string;
  const feedId = (req.query.feedId as string) || (req.query.id as string) || `feed_${Date.now()}`;
  const feedTitle = (req.query.title as string) || 'Newspaper Feed';
  const defaultTags = req.query.tags ? (req.query.tags as string).split(',').filter(Boolean) : [];

  if (!feedUrl) {
    return res.status(400).json({ error: 'Missing url query parameter' });
  }

  // Handle Community Travel Blogs Feed directly from database
  if (feedUrl === '/api/blogs' || feedUrl.includes('api/blogs') || feedId === 'travel_blogs_bd') {
    try {
      const blogs = await readBlogsFromDisk();
      const items = blogs.map((b) => ({
        id: b.id,
        feedId: 'travel_blogs_bd',
        feedTitle: b.groupName ? `${b.groupName} (${b.author})` : `Traveler: ${b.author}`,
        feedUrl: '/api/blogs',
        title: b.title,
        link: `/blog/${b.id}`,
        pubDate: b.publishedAt,
        timestamp: b.timestamp,
        author: `${b.author} · ${b.groupName || 'Bangladeshi Travel Group'}`,
        summary: b.summary || b.content.slice(0, 180) + '...',
        contentHtml: `
          <div class="travel-group-badge mb-4 p-3.5 rounded-xl bg-emerald-950/40 border border-emerald-800/60 text-emerald-200">
            <p class="text-xs uppercase font-bold tracking-wider text-emerald-400 mb-1">Bangladeshi Travel Group Dispatch</p>
            <p class="text-sm font-semibold text-stone-100">${b.groupName || 'Travel Group'} · Writer: ${b.author}</p>
            ${b.location ? `<p class="text-xs text-stone-300 mt-1">📍 Destination: ${b.location}</p>` : ''}
            ${b.groupContact ? `<p class="text-xs text-emerald-300 mt-1.5 font-sans">Connect with Group: <span class="underline">${b.groupContact}</span></p>` : ''}
          </div>
          ${b.content.split(/\n\n+/).map((p: string) => `<p>${p.trim()}</p>`).join('\n')}
        `,
        contentClean: b.content,
        imageUrl: b.coverImage,
        tags: ['tag_travel', 'tag_bd'],
        isRead: false,
        isBookmarked: false,
        isOfflineCached: true,
        readTimeMin: b.readTimeMin || calculateReadTime(b.content),
      }));

      return res.json({
        success: true,
        feedTitle: 'Bangladeshi Travel Groups & Dispatches',
        items,
        resolvedUrl: '/api/blogs',
        sourceMode: 'travel_community_database',
      });
    } catch (err: any) {
      return res.status(500).json({ success: false, error: err.message });
    }
  }

  try {
    const result = await loadPortalOrRssFeed(feedUrl, {
      id: feedId,
      title: feedTitle,
      defaultTags,
    });

    res.json({
      success: true,
      feedTitle: result.feedTitle,
      items: result.items,
      resolvedUrl: result.resolvedUrl,
      sourceMode: result.sourceMode,
    });
  } catch (err: any) {
    console.error(`Error loading source ${feedUrl}:`, err.message);
    res.status(500).json({
      success: false,
      error: `Failed to load source: ${err.message}`,
    });
  }
});

// In-memory extraction cache to provide instant reader rendering
const EXTRACTED_ARTICLE_CACHE = new Map<string, any>();

// 2. Direct URL Reader & Clean Distraction-Free Article Extractor
app.get('/api/extract', async (req: Request, res: Response) => {
  let articleUrl = (req.query.url as string) || '';
  if (!articleUrl) {
    return res.status(400).json({ error: 'Missing url query parameter' });
  }
  if (!/^https?:\/\//i.test(articleUrl.trim())) {
    articleUrl = 'https://' + articleUrl.trim();
  }

  // Check cache first for instant retrieval
  if (EXTRACTED_ARTICLE_CACHE.has(articleUrl)) {
    return res.json(EXTRACTED_ARTICLE_CACHE.get(articleUrl));
  }

  try {
    const { text: html, finalUrl } = await fetchWithUserAgent(articleUrl, 6500);
    const $ = cheerio.load(html);

    // 1. Extract structured JSON-LD metadata & articleBody BEFORE removing <script> tags
    let jsonLdBody = '';
    let jsonLdHeadline = '';
    let jsonLdAuthor = '';
    let jsonLdImage = '';
    let jsonLdDate = '';

    $('script[type="application/ld+json"]').each((_, el) => {
      try {
        const rawJson = $(el).html();
        if (!rawJson) return;
        const parsed = JSON.parse(rawJson);
        const nodes = Array.isArray(parsed)
          ? parsed
          : parsed['@graph'] && Array.isArray(parsed['@graph'])
          ? parsed['@graph']
          : [parsed];

        for (const node of nodes) {
          if (!node || typeof node !== 'object') continue;
          if (typeof node.articleBody === 'string' && node.articleBody.length > jsonLdBody.length) {
            jsonLdBody = node.articleBody;
          }
          if (typeof node.headline === 'string' && !jsonLdHeadline) {
            jsonLdHeadline = node.headline;
          }
          if (node.datePublished && !jsonLdDate) {
            jsonLdDate = String(node.datePublished);
          }
          if (node.author && !jsonLdAuthor) {
            const a = Array.isArray(node.author) ? node.author[0] : node.author;
            if (typeof a === 'string') jsonLdAuthor = a;
            else if (a?.name) jsonLdAuthor = a.name;
          }
          if (node.image && !jsonLdImage) {
            const img = Array.isArray(node.image) ? node.image[0] : node.image;
            if (typeof img === 'string') jsonLdImage = img;
            else if (img?.url) jsonLdImage = img.url;
          }
        }
      } catch {}
    });

    // Site Name
    const siteName =
      $('meta[property="og:site_name"]').attr('content') ||
      new URL(finalUrl).hostname.replace(/^www\./, '');

    // Title
    const title =
      jsonLdHeadline ||
      $('meta[property="og:title"]').attr('content') ||
      $('meta[name="twitter:title"]').attr('content') ||
      $('h1').first().text().trim() ||
      $('title').text().trim() ||
      'Article';

    // Author
    const author =
      jsonLdAuthor ||
      $('meta[name="author"]').attr('content') ||
      $('meta[property="article:author"]').attr('content') ||
      $('[rel="author"]').first().text().trim() ||
      $('.byline, .author, .contributor-name, [class*="byline"], [class*="author-name"]')
        .first()
        .text()
        .trim();

    // Published Date
    const pubDate =
      jsonLdDate ||
      $('meta[property="article:published_time"]').attr('content') ||
      $('time[datetime]').first().attr('datetime') ||
      new Date().toISOString();

    // Lead / Hero Image
    const rawLeadImage =
      jsonLdImage ||
      $('meta[property="og:image"]').attr('content') ||
      $('meta[name="twitter:image"]').attr('content');
    const leadImage = rawLeadImage ? resolveUrl(rawLeadImage, finalUrl) : undefined;

    // Description / Summary
    const metaDescription =
      $('meta[property="og:description"]').attr('content') ||
      $('meta[name="description"]').attr('content') ||
      '';

    // Remove noise, scripts, ads, sidebars, related links, popups, and clutter
    $(
      'script, style, noscript, iframe, svg, nav, footer, header, aside, form, button, ' +
      '.advertisement, .ads, .ad-slot, .ad-container, [id*="google_ads"], [class*="google-ads"], ' +
      '.cookie-banner, .subscribe-banner, .subscription-wall, .paywall, .social-share, .share-buttons, ' +
      '.newsletter-signup, .related-news, .most-viewed, .trending-news, .read-more, .comments, ' +
      '.print-only, .embedded-widget, .outbrain, .taboola, [class*="sponsored"], [id*="sponsored"]'
    ).remove();

    // Choose the richest article-like container rather than the first matching
    // wrapper, which is often only a headline/teaser on modern news sites.
    const articleSelectors =
      'article, [itemprop="articleBody"], .story-element, .story-content, .article-body, .story-body, ' +
      '.entry-content, .post-content, .node-content, .details-content, .news-details, .content-details, ' +
      '.main-content, main, [role="main"]';
    let $article: cheerio.Cheerio<Element> = $('body').first();
    let bestScore = 0;
    $(articleSelectors).each((_, candidate) => {
      if (candidate.type !== 'tag') return;
      const $candidate = $(candidate);
      const paragraphText = $candidate
        .find('p, h2, h3, blockquote')
        .map((__, element) => $(element).text().replace(/\s+/g, ' ').trim())
        .get()
        .filter((text) => text.length >= 20);
      const textLength = paragraphText.reduce((total, text) => total + text.length, 0);
      const score = textLength + paragraphText.length * 120;
      if (score > bestScore) {
        bestScore = score;
        $article = $candidate;
      }
    });

    const contentBlocks: {
      type: 'p' | 'h2' | 'h3' | 'blockquote' | 'img';
      text?: string;
      src?: string;
      caption?: string;
    }[] = [];
    const seenParagraphs = new Set<string>();

    $article.find('p, h2, h3, blockquote, figure').each((_, el) => {
      const tagName = el.tagName.toLowerCase();

      if (tagName === 'figure') {
        const img = $(el).find('img').first();
        const rawSrc =
          img.attr('src') ||
          img.attr('data-src') ||
          img.attr('data-original') ||
          img.attr('data-lazy-src') ||
          img.attr('srcset')?.split(/\s+/)[0];
        const caption = $(el).find('figcaption').text().trim();
        if (
          rawSrc &&
          !rawSrc.endsWith('.gif') &&
          !rawSrc.includes('tracker') &&
          !rawSrc.includes('badge') &&
          !rawSrc.includes('avatar') &&
          !rawSrc.includes('icon')
        ) {
          const resolvedSrc = resolveUrl(rawSrc, finalUrl);
          if (resolvedSrc !== leadImage) {
            contentBlocks.push({ type: 'img', src: resolvedSrc, caption: caption || undefined });
          }
        }
        return;
      }

      const text = $(el).text().replace(/\s+/g, ' ').trim();
      if (!text || (text.length < 20 && tagName === 'p')) return;

      // Filter out boilerplate sentences, social prompts, and paywall banners
      if (
        /^(cookie|subscribe to|sign up for|advertisement|all rights reserved|follow us on|read more:|also read:|click here|download app|share this article)/i.test(
          text
        )
      ) {
        return;
      }

      if (seenParagraphs.has(text)) return;
      seenParagraphs.add(text);

      if (tagName === 'h2' || tagName === 'h3') {
        contentBlocks.push({ type: tagName, text });
      } else if (tagName === 'blockquote') {
        contentBlocks.push({ type: 'blockquote', text });
      } else {
        contentBlocks.push({ type: 'p', text });
      }
    });

    // If DOM extraction returned sparse text but JSON-LD articleBody is available, hydrate full paragraphs!
    const domParagraphCount = contentBlocks.filter((b) => b.type === 'p').length;
    const domTextLength = contentBlocks
      .map((block) => block.text || '')
      .join(' ')
      .length;
    if (
      jsonLdBody &&
      (domParagraphCount < 3 ||
        jsonLdBody.length > 600 ||
        jsonLdBody.length > Math.max(800, domTextLength * 1.35))
    ) {
      const paragraphs = jsonLdBody
        .split(/\n{2,}|\r\n{2,}/)
        .map((p) => stripHtml(p).trim())
        .filter((p) => p.length > 25);

      if (paragraphs.length >= 2 || jsonLdBody.trim().length > Math.max(800, domTextLength * 1.35)) {
        contentBlocks.length = 0;
        for (const p of paragraphs.length > 0 ? paragraphs : [stripHtml(jsonLdBody).trim()]) {
          contentBlocks.push({ type: 'p', text: p });
        }
      }
    }

    // Ensure at least metaDescription if page had minimal text
    if (contentBlocks.length === 0 && metaDescription) {
      contentBlocks.push({ type: 'p', text: stripHtml(metaDescription) });
    }

    const fullText = contentBlocks
      .map((b) => b.text || '')
      .filter(Boolean)
      .join(' ');
    const readTimeMin = calculateReadTime(fullText || metaDescription);

    const responsePayload = {
      success: true,
      title: stripHtml(title),
      siteName: stripHtml(siteName),
      author: author ? stripHtml(author) : undefined,
      pubDate,
      leadImage,
      summary: stripHtml(metaDescription || fullText).slice(0, 240),
      readTimeMin,
      blocks: contentBlocks,
      url: finalUrl,
    };

    // Cache the result for instant future opens
    EXTRACTED_ARTICLE_CACHE.set(articleUrl, responsePayload);
    if (finalUrl !== articleUrl) {
      EXTRACTED_ARTICLE_CACHE.set(finalUrl, responsePayload);
    }

    res.json(responsePayload);
  } catch (err: any) {
    res.json({
      success: false,
      error: `Article extraction unavailable: ${err.message}`,
    });
  }
});

// 3. AI Newspaper Article Summarizer (Powered by Gemini 3.8 Flash with Fallback)
app.post('/api/summarize', async (req: Request, res: Response) => {
  try {
    const { title, text, language } = req.body;
    if (!text || typeof text !== 'string' || text.trim().length < 50) {
      res.status(400).json({ success: false, error: 'Article text too short to summarize' });
      return;
    }

    const cleanBody = stripHtml(text).slice(0, 15000);
    const articleTitle = stripHtml(title || 'Newspaper Article');

    // Check if GEMINI_API_KEY is available
    if (process.env.GEMINI_API_KEY) {
      try {
        const ai = new GoogleGenAI({
          apiKey: process.env.GEMINI_API_KEY,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });

        const prompt = `You are a world-class senior news editor and analyst.
Read this newspaper article carefully and produce a high-precision, executive editorial summary.

Headline: ${articleTitle}

Article Text:
${cleanBody}

Provide your response in JSON format with exactly:
- "executiveSummary": A concise, authoritative 2-3 sentence overview capturing the core news development, significance, and primary parties involved.
- "keyTakeaways": An array of 3 to 5 concise bullet points highlighting crucial facts, numbers, dates, policy impacts, or statements.
- "context": A 1-sentence note on why this news matters to readers or its broader national/international impact.
Keep language professional, objective, and neutral (in ${language || 'the original article language'}).`;

        let response;
        try {
          response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
              responseMimeType: 'application/json',
            },
          });
        } catch {
          response = await ai.models.generateContent({
            model: 'gemini-3.8-flash',
            contents: prompt,
            config: {
              responseMimeType: 'application/json',
            },
          });
        }

        const jsonText = response.text || '{}';
        const parsed = JSON.parse(jsonText);
        res.json({
          success: true,
          provider: 'gemini',
          executiveSummary: parsed.executiveSummary || '',
          keyTakeaways: Array.isArray(parsed.keyTakeaways) ? parsed.keyTakeaways : [],
          context: parsed.context || '',
        });
        return;
      } catch (geminiErr: any) {
        console.warn('Gemini summarize call failed, using extractive editor fallback:', geminiErr.message);
      }
    }

    // High-precision extractive summarizer fallback (works offline or without API key)
    const sentences = cleanBody
      .replace(/([.?!])\s*(?=[A-Z0-9\u0980-\u09FF])/g, '$1|')
      .split('|')
      .map((s) => s.trim())
      .filter((s) => s.length > 35 && s.length < 240);

    const executive = sentences.slice(0, 2).join(' ');
    const takeaways = sentences.slice(2, 6);

    res.json({
      success: true,
      provider: 'extractive-editorial',
      executiveSummary: executive || cleanBody.slice(0, 260),
      keyTakeaways: takeaways.length > 0 ? takeaways : [cleanBody.slice(0, 180)],
      context: `Reported by news desk with ${calculateReadTime(cleanBody)} min detailed coverage.`,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- Travel Blogs Database (Persistent Storage in data/blogs.json) ---
const BLOGS_FILE_PATH = path.resolve(__dirname, 'data', 'blogs.json');

async function readBlogsFromDisk(): Promise<any[]> {
  try {
    if (fs.existsSync(BLOGS_FILE_PATH)) {
      const content = await fsPromises.readFile(BLOGS_FILE_PATH, 'utf-8');
      const parsed = JSON.parse(content);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (err: any) {
    console.error('Failed to read blogs.json database:', err.message);
  }
  return [];
}

async function writeBlogsToDisk(blogs: any[]): Promise<void> {
  try {
    const dir = path.dirname(BLOGS_FILE_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    await fsPromises.writeFile(BLOGS_FILE_PATH, JSON.stringify(blogs, null, 2), 'utf-8');
  } catch (err: any) {
    console.error('Failed to write to blogs.json database:', err.message);
  }
}

// 4. Get all published travel group blogs
app.get('/api/blogs', async (_req: Request, res: Response) => {
  try {
    const blogs = await readBlogsFromDisk();
    res.json({
      success: true,
      blogs: blogs.sort((a, b) => b.timestamp - a.timestamp),
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. Publish new blog to database
app.post('/api/blogs', async (req: Request, res: Response) => {
  try {
    const { title, author, groupName, groupContact, location, content, coverImage } = req.body;
    if (!title || !author || !content) {
      res.status(400).json({ success: false, error: 'Title, Author Name, and Content are required.' });
      return;
    }

    const blogs = await readBlogsFromDisk();
    const newBlog = {
      id: 'tb_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      title: title.trim(),
      author: author.trim(),
      groupName: (groupName || 'Bangladeshi Travel Group').trim(),
      groupContact: (groupContact || '').trim(),
      location: (location || 'Bangladesh').trim(),
      summary: content.trim().replace(/\s+/g, ' ').slice(0, 190) + '...',
      content: content.trim(),
      coverImage: coverImage && typeof coverImage === 'string' && coverImage.trim().startsWith('http') ? coverImage.trim() : undefined,
      publishedAt: new Date().toISOString(),
      timestamp: Date.now(),
      readTimeMin: calculateReadTime(content),
      likesCount: 0,
    };

    blogs.unshift(newBlog);
    await writeBlogsToDisk(blogs);

    console.log(`[Blog Database] Published new travel blog "${newBlog.title}" by ${newBlog.author} (${newBlog.groupName})`);

    res.status(201).json({
      success: true,
      blog: newBlog,
    });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 6. Get curated directory of newspaper feeds & travel groups
app.get('/api/curated', (_req: Request, res: Response) => {
  res.json({
    success: true,
    feeds: CURATED_FEEDS,
  });
});

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'PaperPress iPhone RSS Reader' });
});

// Production static or dev vite middleware
async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
