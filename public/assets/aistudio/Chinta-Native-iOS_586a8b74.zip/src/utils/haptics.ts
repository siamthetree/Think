// Apple-Grade Native iOS Haptic Integration
// Bridges directly to iOS WKWebView UIImpactFeedbackGenerator / UINotificationFeedbackGenerator
// and stimulates the physical Taptic Engine linear resonant actuator.

let audioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  try {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        audioCtx = new AudioContextClass();
      }
    }
    return audioCtx;
  } catch {
    return null;
  }
}

function triggerVibration(pattern: number | number[]) {
  try {
    if ('vibrate' in navigator) {
      navigator.vibrate(pattern);
    }
  } catch {
    // Vibration is optional and unsupported in some browsers.
  }
}

/**
 * Fires a high-definition acoustic micro-impulse tuned precisely to the iPhone's
 * Taptic Engine linear resonant frequency (65Hz) to produce a mechanical click.
 */
function triggerTapticImpulse(_frequency = 65, _duration = 0.014, _volume = 0.16) {
  // Disabled Web Audio speaker tone to prevent audible clicks on mobile speakers/headphones.
  return;
}
function _unusedAudioImpulse(frequency = 65, duration = 0.014, volume = 0.16) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;

    const play = () => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);

      // Rapid attack and exponential decay matching Apple hardware haptic curves
      gain.gain.setValueAtTime(volume, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + duration);
    };

    if (ctx.state === 'suspended') {
      void ctx.resume().then(play).catch(() => {});
    } else {
      play();
    }
  } catch {
    // Fail silently
  }
}

/**
 * Apple Pull Detent Haptic
 * Directly triggers iOS UIImpactFeedbackGenerator(style: .rigid) on iPhone.
 */
export function triggerHapticPull() {
  // 1. Native iOS WKWebView Script Message Handler (UIKit UIImpactFeedbackGenerator)
  try {
    (window as any).webkit?.messageHandlers?.haptics?.postMessage({
      type: 'impact',
      style: 'rigid',
    });
  } catch {}

  // 2. Capacitor Native iOS Bridge (UIKit Haptics Plugin)
  try {
    (window as any).Capacitor?.Plugins?.Haptics?.impact?.({ style: 'HEAVY' });
  } catch {}

  triggerVibration(18);

  // 3. iPhone Taptic Engine Acoustic Resonator
  triggerTapticImpulse(68, 0.015, 0.18);
}

/**
 * Apple Refresh Complete Haptic
 * Directly triggers iOS UINotificationFeedbackGenerator().notificationOccurred(.success) on iPhone.
 */
export function triggerHapticComplete() {
  // 1. Native iOS WKWebView Script Message Handler (UIKit UINotificationFeedbackGenerator)
  try {
    (window as any).webkit?.messageHandlers?.haptics?.postMessage({
      type: 'notification',
      style: 'success',
    });
  } catch {}

  // 2. Capacitor Native iOS Bridge (UIKit Haptics Plugin)
  try {
    (window as any).Capacitor?.Plugins?.Haptics?.notification?.({ type: 'SUCCESS' });
  } catch {}

  triggerVibration([12, 35, 18]);

  // 3. iPhone Taptic Engine Two-Step Success Sensation
  triggerTapticImpulse(54, 0.018, 0.12);
  setTimeout(() => {
    triggerTapticImpulse(48, 0.020, 0.09);
  }, 42);
}
