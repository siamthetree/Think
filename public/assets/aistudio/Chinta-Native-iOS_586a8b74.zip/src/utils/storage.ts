import type { Tag, Feed, FeedItem, ReaderPreferences } from '../types';

export const DEFAULT_TAGS: Tag[] = [
  { id: 'tag_bd', name: 'Bangladesh', color: '#059669' },
  { id: 'tag_world', name: 'World Affairs', color: '#2563EB' },
  { id: 'tag_investigative', name: 'Investigative', color: '#7C3AED' },
  { id: 'tag_markets', name: 'Economy & Finance', color: '#0D9488' },
  { id: 'tag_opinion', name: 'Opinion & Editorial', color: '#B45309' },
  { id: 'tag_tech', name: 'Technology', color: '#4338CA' },
  { id: 'tag_culture', name: 'Culture & Literature', color: '#BE185D' },
  { id: 'tag_breaking', name: 'Breaking News', color: '#DC2626' },
];

export const INITIAL_FEEDS: Feed[] = [
  {
    id: 'daily_star',
    title: 'The Daily Star',
    url: 'https://www.thedailystar.net/rss.xml',
    siteUrl: 'https://www.thedailystar.net',
    description: 'Leading English-language daily newspaper in Bangladesh.',
    category: 'Bangladesh',
    defaultTags: ['tag_bd', 'tag_investigative'],
    unreadCount: 2,
  },
  {
    id: 'prothom_alo_en',
    title: 'Prothom Alo (English)',
    url: 'https://en.prothomalo.com',
    siteUrl: 'https://en.prothomalo.com',
    description: 'National news, politics, economy, and views from Dhaka.',
    category: 'Bangladesh',
    defaultTags: ['tag_bd', 'tag_world'],
    unreadCount: 2,
  },
  {
    id: 'prothom_alo_bn',
    title: 'প্রথম আলো (Prothom Alo Bangla)',
    url: 'https://www.prothomalo.com',
    siteUrl: 'https://www.prothomalo.com',
    description: 'বাংলাদেশের শীর্ষস্থানীয় বাংলা দৈনিক পত্রিকা (Direct & Feed Reader)।',
    category: 'Bangladesh (বাংলা)',
    defaultTags: ['tag_bd'],
    unreadCount: 1,
  },
  {
    id: 'bdnews24',
    title: 'bdnews24.com',
    url: 'https://bdnews24.com',
    siteUrl: 'https://bdnews24.com',
    description: 'Direct Portal Reader — Loads stories directly from bdnews24.com without needing RSS.',
    category: 'Bangladesh (Direct URL)',
    defaultTags: ['tag_bd', 'tag_breaking'],
    unreadCount: 2,
  },
  {
    id: 'fe_bd',
    title: 'The Financial Express (BD)',
    url: 'https://thefinancialexpress.com.bd',
    siteUrl: 'https://thefinancialexpress.com.bd',
    description: 'Direct Portal Reader — Trade, banking, and economic news from Bangladesh.',
    category: 'Bangladesh Finance',
    defaultTags: ['tag_bd', 'tag_markets'],
    unreadCount: 1,
  },
  {
    id: 'tbs_news',
    title: 'The Business Standard (TBS)',
    url: 'https://www.tbsnews.net',
    siteUrl: 'https://www.tbsnews.net',
    description: 'Direct Portal Reader — Business, economy, and policy journalism in Bangladesh.',
    category: 'Bangladesh Finance',
    defaultTags: ['tag_bd', 'tag_markets'],
    unreadCount: 1,
  },
  {
    id: 'dhaka_tribune',
    title: 'Dhaka Tribune',
    url: 'https://www.dhakatribune.com',
    siteUrl: 'https://www.dhakatribune.com',
    description: 'Direct Portal Reader — National politics, foreign affairs, and Dhaka dispatches.',
    category: 'Bangladesh',
    defaultTags: ['tag_bd', 'tag_opinion'],
    unreadCount: 1,
  },
  {
    id: 'bbc_world',
    title: 'BBC News',
    url: 'https://feeds.bbci.co.uk/news/world/rss.xml',
    siteUrl: 'https://bbc.com/news',
    description: 'Global news, correspondents, and impartial reporting.',
    category: 'World',
    defaultTags: ['tag_world', 'tag_breaking'],
    unreadCount: 1,
  },
];

export const INITIAL_ARTICLES: FeedItem[] = [
  {
    id: 'art_ds_1',
    feedId: 'daily_star',
    feedTitle: 'The Daily Star',
    feedUrl: 'https://www.thedailystar.net/rss.xml',
    title: 'Why Bangladesh Must Pivot to Renewable Energy Now: An Analytical Report',
    link: 'https://www.thedailystar.net/slow-reads/big-picture/news/why-bangladesh-must-pivot-renewable-energy-now-4184106',
    pubDate: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
    timestamp: Date.now() - 25 * 60 * 1000,
    author: 'Khairul Jahin',
    summary:
      'With foreign exchange pressures and volatile fossil fuel imports, transitioning to distributed solar and wind grids is no longer merely an ecological target—it is an economic imperative.',
    contentHtml: `
      <p>Over the past decade, Bangladesh’s power sector achieved historic milestones in expanding electrification to remote riverine islands and rural hamlets. However, the heavy reliance on imported liquefied natural gas (LNG) and coal has exposed the national grid to international commodity price shocks and dollar reserve strain.</p>
      <h2>The Economics of Grid Modernization</h2>
      <p>Energy analysts at the Institute for Energy Economics point out that solar photovoltaic generation costs have fallen by more than 75 percent over the last decade. Rooftop solar installations on garment export factories and industrial rooftops across Gazipur, Narayanganj, and Chattogram represent over 4,000 megawatts of untapped generation capacity.</p>
      <blockquote>"Transitioning to domestic renewable energy is the most effective hedge against sovereign balance-of-payments volatility. Every gigawatt of solar we deploy replaces costly foreign currency outflows."</blockquote>
      <p>By streamlining grid-tied net metering policies and modernizing transmission substations, Bangladesh can bolster its manufacturing resilience while meeting long-term decarbonization commitments.</p>
    `,
    contentClean:
      'Over the past decade, Bangladesh’s power sector achieved historic milestones in expanding electrification to remote riverine islands and rural hamlets. Energy analysts at the Institute for Energy Economics point out that solar photovoltaic generation costs have fallen by more than 75 percent over the last decade.',
    imageUrl:
      'https://www.thedailystar.net/sites/default/files/styles/big_1/public/2026-05/Energy%20Crisis%20in%20Bangladesh.jpg?h=c06fab7e',
    tags: ['tag_bd', 'tag_investigative'],
    isRead: false,
    isBookmarked: true,
    isOfflineCached: true,
    cachedAt: Date.now(),
    readTimeMin: 4,
  },
  {
    id: 'art_ds_2',
    feedId: 'daily_star',
    feedTitle: 'The Daily Star',
    feedUrl: 'https://www.thedailystar.net/rss.xml',
    title: 'The Forgotten Art of Bengali Advertising and Print Typography',
    link: 'https://www.thedailystar.net/slow-reads/focus/news/the-forgotten-art-bengali-advertising-4177626',
    pubDate: new Date(Date.now() - 90 * 60 * 1000).toISOString(),
    timestamp: Date.now() - 90 * 60 * 1000,
    author: 'Miftahul Islam',
    summary:
      'Before digital billboards dominated Dhaka streets, hand-lettered Bengali print advertisements combined literary wit with woodblock artistry.',
    contentHtml: `
      <p>Leafing through yellowed bound volumes of mid-century Bengali periodicals reveals a visual language of extraordinary charm. Hand-drawn Bengali letterforms curved around intricate line illustrations, where copywriters crafted rhyming couplets and witty dialogues to introduce everything from fountain pens and tea blends to classic cinema releases.</p>
      <h2>When Copywriting Met Literature</h2>
      <p>Many of Bengal’s celebrated poets and illustrators worked anonymously in commercial studios, bringing fine-art sensibility to everyday newspaper columns. Preserving these archival print specimens offers a window into the social history and evolving middle-class aspirations of the region.</p>
    `,
    contentClean:
      'Leafing through yellowed bound volumes of mid-century Bengali periodicals reveals a visual language of extraordinary charm. Hand-drawn Bengali letterforms curved around intricate line illustrations.',
    imageUrl:
      'https://www.thedailystar.net/sites/default/files/styles/big_1/public/2026-05/feature_2.png?h=d5e74d0c',
    tags: ['tag_bd', 'tag_culture'],
    isRead: false,
    isBookmarked: false,
    isOfflineCached: true,
    cachedAt: Date.now(),
    readTimeMin: 3,
  },
  {
    id: 'art_pa_en_1',
    feedId: 'prothom_alo_en',
    feedTitle: 'Prothom Alo (English)',
    feedUrl: 'https://en.prothomalo.com',
    title: 'Foreign Relations Should Be Pursued in Our Own National Interests, on Our Own Terms',
    link: 'https://en.prothomalo.com/opinion/op-ed/v5h1pfba1v',
    pubDate: new Date(Date.now() - 55 * 60 * 1000).toISOString(),
    timestamp: Date.now() - 55 * 60 * 1000,
    author: 'Prothom Alo Editorial Desk',
    summary:
      'Strategic autonomy, balanced regional trade connectivity, and multilateral diplomacy remain essential pillars for Bangladesh in an increasingly multipolar Indo-Pacific.',
    contentHtml: `
      <p>As regional trade corridors and maritime supply chains undergo rapid transformation across South and Southeast Asia, diplomats and policy scholars in Dhaka emphasize the primacy of balanced, interest-driven foreign policy.</p>
      <h2>Economic Diplomacy and Market Access</h2>
      <p>With Bangladesh preparing for post-LDC graduation tariff frameworks, diversifying export destinations and negotiating bilateral economic partnership agreements will define the next decade of industrial growth.</p>
    `,
    contentClean:
      'As regional trade corridors and maritime supply chains undergo rapid transformation across South and Southeast Asia, diplomats and policy scholars in Dhaka emphasize the primacy of balanced foreign policy.',
    tags: ['tag_bd', 'tag_opinion'],
    isRead: false,
    isBookmarked: true,
    isOfflineCached: true,
    cachedAt: Date.now(),
    readTimeMin: 4,
  },
  {
    id: 'art_pa_bn_1',
    feedId: 'prothom_alo_bn',
    feedTitle: 'প্রথম আলো (Prothom Alo Bangla)',
    feedUrl: 'https://www.prothomalo.com',
    title: 'রাজধানীর বাইরে অর্থনৈতিক বিকেন্দ্রীকরণ ও নাগরিক সুবিধার নতুন রূপরেখা',
    link: 'https://www.prothomalo.com/bangladesh/0yr0fn5eo6',
    pubDate: new Date(Date.now() - 75 * 60 * 1000).toISOString(),
    timestamp: Date.now() - 75 * 60 * 1000,
    author: 'প্রথম আলো প্রতিবেদক',
    summary:
      'ঢাকাকেন্দ্রিক চাপ কমাতে বিভাগীয় ও জেলা শহরগুলোতে মানসম্মত শিক্ষা, স্বাস্থ্যসেবা এবং শিল্পায়নের বিকেন্দ্রীকরণের ওপর গুরুত্বারোপ করেছেন নগর পরিকল্পনাবিদরা।',
    contentHtml: `
      <p>দেশের সামগ্রিক অর্থনৈতিক প্রবৃদ্ধি এবং নাগরিক জীবনমান উন্নয়নের জন্য ঢাকাকেন্দ্রিক অতি-কেন্দ্রীকরণ থেকে বেরিয়ে আসার তাগিদ দিয়েছেন বিশেষজ্ঞরা। আঞ্চলিক যোগাযোগ অবকাঠামো উন্নত হওয়ার ফলে এখন বিভাগীয় ও জেলা শহরগুলোতে নতুন কর্মসংস্থান তৈরির সুযোগ সৃষ্টি হয়েছে।</p>
      <h2>সুষম নগরায়ণ ও আঞ্চলিক অর্থনীতি</h2>
      <p>পরিকল্পিত শিল্পাঞ্চল, আধুনিক হাসপাতাল এবং উচ্চশিক্ষা প্রতিষ্ঠানগুলো সারাদেশে সুষমভাবে ছড়িয়ে দেওয়া গেলে রাজধানীতে অতিরিক্ত জনসংখ্যার চাপ স্বাভাবিকভাবেই কমে আসবে।</p>
    `,
    contentClean:
      'দেশের সামগ্রিক অর্থনৈতিক প্রবৃদ্ধি এবং নাগরিক জীবনমান উন্নয়নের জন্য ঢাকাকেন্দ্রিক অতি-কেন্দ্রীকরণ থেকে বেরিয়ে আসার তাগিদ দিয়েছেন বিশেষজ্ঞরা। আঞ্চলিক যোগাযোগ অবকাঠামো উন্নত হওয়ার ফলে এখন বিভাগীয় ও জেলা শহরগুলোতে নতুন কর্মসংস্থান তৈরির সুযোগ সৃষ্টি হয়েছে।',
    tags: ['tag_bd', 'tag_opinion'],
    isRead: false,
    isBookmarked: false,
    isOfflineCached: true,
    cachedAt: Date.now(),
    readTimeMin: 3,
  },
  {
    id: 'art_bdnews_1',
    feedId: 'bdnews24',
    feedTitle: 'bdnews24.com',
    feedUrl: 'https://bdnews24.com',
    title: 'Dhaka Expands Bilateral Trade and Energy Cooperation Framework',
    link: 'https://bdnews24.com/bangladesh/708mysm1cv',
    pubDate: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
    timestamp: Date.now() - 40 * 60 * 1000,
    author: 'bdnews24.com Senior Correspondent',
    summary:
      'Loaded directly from bdnews24.com HTML portal — High-level delegation talks focus on manufacturing investment, defense technology, and youth scholarship exchanges.',
    contentHtml: `
      <p>High-level bilateral discussions concluded today with agreements to accelerate joint ventures in renewable energy, textile machinery modernization, and healthcare infrastructure across Bangladesh.</p>
      <h2>Direct Portal Extraction</h2>
      <p>Even when a Bangladeshi news portal does not publish a traditional XML RSS feed, Chinta extracts headlines and full article text directly from the portal URL into a clean, distraction-free reading layout.</p>
    `,
    contentClean: '',
    tags: ['tag_bd', 'tag_breaking'],
    isRead: false,
    isBookmarked: false,
    isOfflineCached: true,
    cachedAt: Date.now(),
    readTimeMin: 3,
  },
  {
    id: 'art_fe_1',
    feedId: 'fe_bd',
    feedTitle: 'The Financial Express (BD)',
    feedUrl: 'https://thefinancialexpress.com.bd',
    title: "Bangladesh's Banking Sector: Structural Ailments and Policy Remedies",
    link: 'https://thefinancialexpress.com.bd/33rd-anniversary-issue-i/bangladeshs-banking-sector-ailments-and-remedies',
    pubDate: new Date(Date.now() - 110 * 60 * 1000).toISOString(),
    timestamp: Date.now() - 110 * 60 * 1000,
    author: 'FE Economic Analysis Desk',
    summary:
      'Restoring discipline in non-performing loan recovery, strengthening central bank autonomy, and digitizing credit risk assessment are top priorities for monetary stability.',
    contentHtml: `
      <p>A resilient financial sector is the lifeblood of industrial capital formation. Economists reviewing Bangladesh’s banking landscape emphasize that corporate governance reforms, independent audit standards, and strict recovery mechanisms for defaulted loans are essential to lower borrowing costs for small and medium enterprises.</p>
      <h2>Monetary Policy and Remittance Channels</h2>
      <p>Formalizing remittance inflows through competitive exchange rates and instant digital settlement channels has already begun bolstering commercial bank liquidity and foreign currency reserves.</p>
    `,
    contentClean: '',
    tags: ['tag_bd', 'tag_markets'],
    isRead: false,
    isBookmarked: true,
    isOfflineCached: true,
    cachedAt: Date.now(),
    readTimeMin: 5,
  },
  {
    id: 'art_tbs_1',
    feedId: 'tbs_news',
    feedTitle: 'The Business Standard (TBS)',
    feedUrl: 'https://www.tbsnews.net',
    title: 'Chattogram Port Automation Cuts Container Turnaround Time by 22 Percent',
    link: 'https://www.tbsnews.net',
    pubDate: new Date(Date.now() - 150 * 60 * 1000).toISOString(),
    timestamp: Date.now() - 150 * 60 * 1000,
    author: 'TBS Staff Correspondent',
    summary:
      'Digital customs clearance and automated bay terminal scheduling have accelerated apparel and industrial raw material shipments at Bangladesh’s premier seaport.',
    contentHtml: `
      <p>Maritime trade through Chattogram Port—which handles over 90 percent of Bangladesh’s international seaborne cargo—has recorded a decisive leap in operational efficiency following the deployment of automated gate scanners and electronic customs manifests.</p>
      <h2>Boosting Export Competitiveness</h2>
      <p>Apparel exporters note that shaving forty-eight hours off port dwell time directly improves lead-time reliability for European and North American retail buyers.</p>
    `,
    contentClean:
      'Maritime trade through Chattogram Port—which handles over 90 percent of Bangladesh’s international seaborne cargo—has recorded a decisive leap in operational efficiency.',
    tags: ['tag_bd', 'tag_markets'],
    isRead: false,
    isBookmarked: false,
    isOfflineCached: true,
    cachedAt: Date.now(),
    readTimeMin: 3,
  },
  {
    id: 'art_dt_1',
    feedId: 'dhaka_tribune',
    feedTitle: 'Dhaka Tribune',
    feedUrl: 'https://www.dhakatribune.com',
    title: 'Urban Wetlands Restoration Project Launched Across Greater Dhaka Watershed',
    link: 'https://www.dhakatribune.com',
    pubDate: new Date(Date.now() - 200 * 60 * 1000).toISOString(),
    timestamp: Date.now() - 200 * 60 * 1000,
    author: 'Dhaka Tribune Report',
    summary:
      'Reclaiming natural canals and retention basins around the Turag and Balu rivers aims to mitigate monsoon waterlogging and restore urban biodiversity.',
    contentHtml: `
      <p>Hydrologists and municipal authorities have initiated a comprehensive dredging and ecological restoration program targeting interconnected canals across eastern and northern Dhaka.</p>
      <h2>Natural Sponge Infrastructure</h2>
      <p>Preserving natural floodplains and wetland retention zones provides sustainable stormwater drainage while cooling dense urban neighborhoods during peak summer months.</p>
    `,
    contentClean:
      'Hydrologists and municipal authorities have initiated a comprehensive dredging and ecological restoration program targeting interconnected canals across eastern and northern Dhaka.',
    tags: ['tag_bd', 'tag_world'],
    isRead: false,
    isBookmarked: false,
    isOfflineCached: true,
    cachedAt: Date.now(),
    readTimeMin: 3,
  },
  {
    id: 'art_bbc_1',
    feedId: 'bbc_world',
    feedTitle: 'BBC News',
    feedUrl: 'https://feeds.bbci.co.uk/news/world/rss.xml',
    title: 'Deep-Ocean Acoustic Census Uncovers Intricate Whale Communication Dialects',
    link: 'https://bbc.com/news/science-environment-deep-ocean-census',
    pubDate: new Date(Date.now() - 240 * 60 * 1000).toISOString(),
    timestamp: Date.now() - 240 * 60 * 1000,
    author: 'Dr. Alistair MacIntyre',
    summary:
      'Marine biologists utilizing hydrophone arrays deployed across the Southern Ocean have identified regional syntactic patterns in humpback and blue whale pods.',
    contentHtml: `
      <p>For decades, researchers listening to the deep abyss heard what seemed like solitary calls reverberating through the polar brine. Today, a landmark multi-year acoustic census coordinated by international marine institutes reveals a far more complex reality: distinct acoustic dialects that evolve, travel, and are actively taught between neighboring cetacean pods.</p>
    `,
    contentClean:
      'For decades, researchers listening to the deep abyss heard what seemed like solitary calls reverberating through the polar brine. Today, a landmark multi-year acoustic census reveals distinct acoustic dialects.',
    tags: ['tag_world'],
    isRead: false,
    isBookmarked: false,
    isOfflineCached: true,
    cachedAt: Date.now(),
    readTimeMin: 4,
  },
];

const STORAGE_KEYS = {
  FEEDS: 'paperpress_feeds_v2',
  ARTICLES: 'paperpress_articles_v2',
  TAGS: 'paperpress_tags_v2',
  PREFS: 'paperpress_reader_prefs_v2',
};

export const DEFAULT_READER_PREFERENCES: ReaderPreferences = {
  font: 'serif',
  fontSize: 18,
  theme: 'slate',
  lineHeight: 'relaxed',
  distractionFree: false,
};

export function loadFeedsFromStorage(): Feed[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FEEDS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load feeds from localStorage', e);
  }
  return INITIAL_FEEDS;
}

export function saveFeedsToStorage(feeds: Feed[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.FEEDS, JSON.stringify(feeds));
  } catch (e) {
    console.error('Failed to save feeds to localStorage', e);
  }
}

export function loadArticlesFromStorage(): FeedItem[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ARTICLES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load articles from localStorage', e);
  }
  return INITIAL_ARTICLES;
}

export function saveArticlesToStorage(articles: FeedItem[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(articles));
  } catch (e) {
    console.error('Failed to save articles to localStorage', e);
  }
}

export function loadTagsFromStorage(): Tag[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.TAGS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to load tags from localStorage', e);
  }
  return DEFAULT_TAGS;
}

export function saveTagsToStorage(tags: Tag[]): void {
  try {
    localStorage.setItem(STORAGE_KEYS.TAGS, JSON.stringify(tags));
  } catch (e) {
    console.error('Failed to save tags to localStorage', e);
  }
}

export function loadPreferencesFromStorage(): ReaderPreferences {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PREFS);
    if (raw) return { ...DEFAULT_READER_PREFERENCES, ...JSON.parse(raw) };
  } catch (e) {
    console.error('Failed to load preferences from localStorage', e);
  }
  return DEFAULT_READER_PREFERENCES;
}

export function savePreferencesToStorage(prefs: ReaderPreferences): void {
  try {
    localStorage.setItem(STORAGE_KEYS.PREFS, JSON.stringify(prefs));
  } catch (e) {
    console.error('Failed to save preferences to localStorage', e);
  }
}
