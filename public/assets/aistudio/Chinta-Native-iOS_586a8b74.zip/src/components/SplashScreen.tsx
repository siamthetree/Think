import React, { useState, useEffect } from 'react';

interface SplashScreenProps {
  onFinish?: () => void;
  durationMs?: number;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  onFinish,
  durationMs = 950,
}) => {
  const [phase, setPhase] = useState<'entering' | 'visible' | 'exiting' | 'done'>('entering');
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    // Phase 1: Rapid entrance (100ms)
    const enterTimer = setTimeout(() => {
      setPhase('visible');
    }, 50);

    // Fast fluid progress bar to indicate quick launch
    const progressTimer1 = setTimeout(() => setProgress(55), 250);
    const progressTimer2 = setTimeout(() => setProgress(95), 650);

    // Phase 2: Start smooth exit transition at ~durationMs
    const exitTimer = setTimeout(() => {
      setProgress(100);
      setPhase('exiting');
    }, durationMs);

    // Phase 3: Finish and unmount completely
    const doneTimer = setTimeout(() => {
      setPhase('done');
      if (onFinish) {
        onFinish();
      }
    }, durationMs + 280);

    return () => {
      clearTimeout(enterTimer);
      clearTimeout(progressTimer1);
      clearTimeout(progressTimer2);
      clearTimeout(exitTimer);
      clearTimeout(doneTimer);
    };
  }, [durationMs, onFinish]);

  // Fast-skip on tap so user is never delayed
  const handleFastSkip = () => {
    if (phase !== 'exiting' && phase !== 'done') {
      setProgress(100);
      setPhase('exiting');
      setTimeout(() => {
        setPhase('done');
        if (onFinish) onFinish();
      }, 150);
    }
  };

  if (phase === 'done') return null;

  const isExiting = phase === 'exiting';

  return (
    <div
      onClick={handleFastSkip}
      role="status"
      aria-live="polite"
      aria-label="Opening Chinta"
      className="absolute inset-0 z-50 flex flex-col items-center justify-between p-8 bg-[#090A0C] text-stone-100 select-none cursor-pointer"
      style={{
        opacity: isExiting ? 0 : 1,
        transform: isExiting ? 'scale(1.02)' : 'scale(1)',
        filter: isExiting ? 'blur(4px)' : 'none',
        transition: 'opacity 0.28s cubic-bezier(0.4, 0, 0.2, 1), transform 0.28s cubic-bezier(0.4, 0, 0.2, 1), filter 0.28s ease',
      }}
    >
      {/* Top subtle badge */}
      <div className="w-full flex items-center justify-center pt-8">
        <span className="text-[11px] tracking-widest uppercase font-semibold text-emerald-500/90 font-sans">
          Chinta · চিন্তা
        </span>
      </div>

      {/* Centerpiece: Tagline */}
      <div className="flex flex-col items-center text-center max-w-xs px-2 animate-in fade-in zoom-in-95 duration-200">
        {/* User's Opening Line in Bengali */}
        <h1
          className="font-serif text-2xl sm:text-3xl font-bold tracking-tight text-stone-100 leading-snug mb-3"
          style={{ fontFamily: "'Noto Serif Bengali', 'Lora', Georgia, serif" }}
        >
          চলো চিন্তা করি শেয়ারে।
        </h1>

        <p className="text-xs text-stone-400 font-sans tracking-tight">
          মুক্ত ও নিরপেক্ষ পাঠশালা
        </p>
      </div>

      {/* Bottom: Fast-loading progress indicator */}
      <div className="w-full max-w-[180px] flex flex-col items-center pb-8 gap-2">
        <div className="w-full h-1 bg-stone-900 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400 rounded-full transition-all duration-300 ease-out"
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className="text-[10px] text-stone-500 font-sans">
          নিউজ ফিড প্রস্তুত হচ্ছে...
        </span>
      </div>
    </div>
  );
};
