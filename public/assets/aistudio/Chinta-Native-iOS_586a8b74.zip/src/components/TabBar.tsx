import React from 'react';
import { Newspaper, Bookmark, Rss, Settings } from 'lucide-react';

export type TabType = 'stories' | 'tags' | 'saved' | 'feeds';

interface TabBarProps {
  currentTab: TabType;
  onSelectTab: (tab: TabType) => void;
  unreadCount?: number;
  isVisible?: boolean;
}

export const TabBar: React.FC<TabBarProps> = ({
  currentTab,
  onSelectTab,
  unreadCount = 0,
  isVisible = true,
}) => {
  const tabs = [
    {
      id: 'stories' as TabType,
      label: 'Newsfeed',
      icon: Newspaper,
      badge: unreadCount > 0 ? unreadCount : undefined,
    },
    {
      id: 'saved' as TabType,
      label: 'Saved',
      icon: Bookmark,
    },
    {
      id: 'feeds' as TabType,
      label: 'Feeds',
      icon: Rss,
    },
    {
      id: 'tags' as TabType,
      label: 'Settings',
      icon: Settings,
    },
  ];

  return (
    <nav
      aria-label="Bottom Navigation"
      className={`shrink-0 pt-2 pb-[max(env(safe-area-inset-bottom,0px),14px)] bg-white/95 dark:bg-[#090A0C]/95 backdrop-blur-xl border-t border-stone-200/70 dark:border-stone-800/80 flex items-center justify-around px-2 z-20 select-none shadow-lg transition-all duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] ${
        isVisible
          ? 'translate-y-0 opacity-100 pointer-events-auto'
          : 'translate-y-full opacity-0 pointer-events-none'
      }`}
    >
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = currentTab === tab.id;

        return (
          <button
            key={tab.id}
            onClick={() => onSelectTab(tab.id)}
            aria-label={tab.label}
            className={`flex-1 py-1 flex flex-col items-center justify-center relative transition-colors ${
              isActive
                ? 'text-[#FF6719] dark:text-[#FF6719] font-semibold'
                : 'text-stone-500 dark:text-stone-400 hover:text-stone-800 dark:hover:text-stone-200'
            }`}
          >
            <div className="relative">
              <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.2]' : 'stroke-[1.6]'}`} />
              {tab.badge !== undefined && (
                <span className="absolute -top-1 -right-2.5 min-w-3.5 h-3.5 px-1 bg-[#FF6719] text-white text-[9px] font-bold rounded-full flex items-center justify-center shadow-xs">
                  {tab.badge > 99 ? '99+' : tab.badge}
                </span>
              )}
            </div>
            <span className="text-[10px] tracking-tight mt-0.5 whitespace-nowrap">
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
