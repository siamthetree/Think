import SwiftUI
import SwiftData
import UIKit

public struct MainFeedView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.displayMetrics) private var metrics
    @Query(sort: \FeedItem.publishedDate, order: .reverse) private var articles: [FeedItem]
    @Query(sort: \Feed.title) private var feeds: [Feed]
    
    @State private var activeTab: AppTab = .newsfeed
    @State private var selectedFeedID: UUID? = nil
    @State private var filterScope: FeedFilterScope = .all
    @State private var viewMode: FeedViewLayoutMode = .magazine
    @State private var selectedArticleForReader: FeedItem? = nil
    @State private var isSearchActive = false
    @State private var searchQuery = ""
    @State private var isSourcesSheetOpen = false
    @State private var isBarsVisible = true
    @State private var lastScrollOffset: CGFloat = 0
    @State private var hasBootstrapped = false
    
    public enum AppTab: String, CaseIterable {
        case newsfeed = "Newsfeed"
        case saved = "Saved"
        case newspapers = "Newspapers"
    }
    
    public enum FeedFilterScope: String, CaseIterable {
        case all = "Home"
        case unread = "Unread"
        case starred = "Saved"
    }
    
    public enum FeedViewLayoutMode: String, CaseIterable {
        case magazine = "Magazine"
        case compact = "Compact"
    }
    
    public init() {}
    
    public var body: some View {
        ZStack(alignment: .bottom) {
            Color.liquidBackgroundDark
                .ignoresSafeArea(.all)
            
            // Main ScrollView with 120Hz ProMotion-ready LazyVStack & ScrollTransitions
            ScrollView {
                LazyVStack(spacing: viewMode == .magazine ? 18 : 10) {
                    Color.clear
                        .frame(height: max(metrics.safeAreaInsets.top, 20) + (isSearchActive ? 162 : 116))
                    
                    let displayed = filteredArticles
                    if displayed.isEmpty {
                        emptyStateView
                            .padding(.top, 56)
                    } else {
                        ForEach(displayed) { item in
                            Group {
                                if viewMode == .magazine {
                                    SubstackPostCard(item: item) {
                                        AppleHapticEngine.shared.cardTap()
                                        selectedArticleForReader = item
                                    }
                                } else {
                                    LiquidCompactRow(item: item) {
                                        AppleHapticEngine.shared.cardTap()
                                        selectedArticleForReader = item
                                    }
                                }
                            }
                            .scrollTransition(.animated(.spring(response: 0.34, dampingFraction: 0.84))) { content, phase in
                                content
                                    .opacity(phase.isIdentity ? 1.0 : 0.86)
                                    .scaleEffect(phase.isIdentity ? 1.0 : 0.98)
                            }
                        }
                    }
                }
                .padding(.horizontal, metrics.horizontalGutter)
                .padding(.bottom, metrics.floatingBarHeight + max(metrics.safeAreaInsets.bottom, 24) + 20)
                .background(
                    GeometryReader { geo in
                        Color.clear.preference(
                            key: ScrollOffsetPreferenceKey.self,
                            value: geo.frame(in: .named("feedScrollView")).minY
                        )
                    }
                )
            }
            .coordinateSpace(name: "feedScrollView")
            .onPreferenceChange(ScrollOffsetPreferenceKey.self) { value in
                handleScroll(offset: value)
            }
            .scrollIndicators(.hidden)
            .refreshable {
                AppleHapticEngine.shared.pullThresholdDetent()
                if let feedID = selectedFeedID, let activeFeed = feeds.first(where: { $0.id == feedID }) {
                    await FeedRefreshEngine.shared.pullToRefresh(feed: activeFeed, modelContext: modelContext)
                } else {
                    await FeedRefreshEngine.shared.pullToRefreshAll(modelContext: modelContext)
                }
                AppleHapticEngine.shared.refreshCompleted()
            }
            
            // Top Substack Liquid Glass Header (Auto-Hides on Scroll Down)
            VStack {
                topGlassHeader
                    .offset(y: isBarsVisible ? 0 : -180)
                    .opacity(isBarsVisible ? 1.0 : 0.0)
                    .animation(.spring(response: 0.32, dampingFraction: 0.86), value: isBarsVisible)
                Spacer()
            }
            .ignoresSafeArea(.container, edges: .top)
            
            // Bottom Floating Liquid Glass Dock (Auto-Hides on Scroll Down)
            bottomFloatingDock
                .offset(y: isBarsVisible ? 0 : 120)
                .opacity(isBarsVisible ? 1.0 : 0.0)
                .animation(.spring(response: 0.32, dampingFraction: 0.86), value: isBarsVisible)
        }
        .task {
            guard !hasBootstrapped else { return }
            hasBootstrapped = true
            await FeedRefreshEngine.shared.onAppLaunch(modelContext: modelContext)
        }
        .fullScreenCover(item: $selectedArticleForReader) { article in
            ReaderDetailView(article: article)
        }
        .sheet(isPresented: $isSourcesSheetOpen) {
            SourcesManagerView(selectedFeedID: $selectedFeedID)
        }
    }
    
    // MARK: - Momentum Scroll Direction Handling
    private func handleScroll(offset: CGFloat) {
        let delta = offset - lastScrollOffset
        if offset > -24 {
            if !isBarsVisible { isBarsVisible = true }
            lastScrollOffset = offset
            return
        }
        if delta < -14 && isBarsVisible {
            isBarsVisible = false
        } else if delta > 14 && !isBarsVisible {
            isBarsVisible = true
        }
        lastScrollOffset = offset
    }
    
    // MARK: - Top Substack Liquid Glass Header
    private var topGlassHeader: some View {
        VStack(spacing: 10) {
            HStack(alignment: .center) {
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 4, style: .continuous)
                            .fill(Color.substackOrange)
                            .frame(width: 22, height: 26)
                            .shadow(color: Color.substackOrange.opacity(0.45), radius: 5, y: 2)
                        
                        Text("C")
                            .font(.system(size: 13, weight: .black, design: .serif))
                            .foregroundStyle(.white)
                    }
                    
                    Text(activeTitle)
                        .font(.system(size: metrics.fontSize(base: 22), weight: .bold, design: .serif))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    
                    if selectedFeedID != nil {
                        Button(action: {
                            AppleHapticEngine.shared.selectionTick()
                            withAnimation(.spring(response: 0.3, dampingFraction: 0.82)) {
                                selectedFeedID = nil
                            }
                        }) {
                            Text("All ×")
                                .font(.system(size: 11, weight: .semibold))
                                .foregroundStyle(.white.opacity(0.85))
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(Color.white.opacity(0.14))
                                .clipShape(Capsule())
                        }
                    }
                }
                
                Spacer()
                
                HStack(spacing: 8) {
                    Button(action: {
                        AppleHapticEngine.shared.selectionTick()
                        withAnimation(.spring(response: 0.28, dampingFraction: 0.82)) {
                            viewMode = (viewMode == .magazine) ? .compact : .magazine
                        }
                    }) {
                        Image(systemName: viewMode == .magazine ? "rectangle.grid.1x2.fill" : "list.bullet")
                            .font(.system(size: metrics.iconSize(base: 13), weight: .semibold))
                            .foregroundStyle(Color.substackOrange)
                            .frame(width: metrics.iconSize(base: 34), height: metrics.iconSize(base: 34))
                            .liquidGlass(cornerRadius: 17, opacity: 0.78)
                    }
                    
                    Button(action: {
                        AppleHapticEngine.shared.selectionTick()
                        withAnimation(.spring(response: 0.28, dampingFraction: 0.82)) {
                            isSearchActive.toggle()
                        }
                    }) {
                        Image(systemName: "magnifyingglass")
                            .font(.system(size: metrics.iconSize(base: 13), weight: .semibold))
                            .foregroundStyle(isSearchActive ? Color.substackOrange : .white)
                            .frame(width: metrics.iconSize(base: 34), height: metrics.iconSize(base: 34))
                            .liquidGlass(cornerRadius: 17, opacity: 0.78)
                    }
                    
                    Button(action: {
                        AppleHapticEngine.shared.selectionTick()
                        isSourcesSheetOpen = true
                    }) {
                        Image(systemName: "newspaper.circle")
                            .font(.system(size: metrics.iconSize(base: 15), weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(width: metrics.iconSize(base: 34), height: metrics.iconSize(base: 34))
                            .liquidGlass(cornerRadius: 17, opacity: 0.78)
                    }
                }
            }
            
            // Horizontal Newspaper Chip Scroller + Filter Scopes
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(FeedFilterScope.allCases, id: \.self) { scope in
                        LiquidGlassPillButton(
                            title: scope.rawValue,
                            isSelected: filterScope == scope && selectedFeedID == nil,
                            badgeCount: scope == .unread ? articles.filter { !$0.isRead }.count : 0
                        ) {
                            filterScope = scope
                            if scope == .starred {
                                activeTab = .saved
                            } else {
                                activeTab = .newsfeed
                            }
                        }
                    }
                    
                    Divider()
                        .frame(height: 18)
                        .background(Color.white.opacity(0.2))
                    
                    ForEach(feeds) { feed in
                        LiquidGlassPillButton(
                            title: feed.title,
                            isSelected: selectedFeedID == feed.id,
                            badgeCount: feed.items.filter { !$0.isRead }.count
                        ) {
                            selectedFeedID = (selectedFeedID == feed.id) ? nil : feed.id
                        }
                    }
                }
            }
            
            if isSearchActive {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("Search headlines, newspapers, or topics...", text: $searchQuery)
                        .font(.system(size: metrics.fontSize(base: 13)))
                        .foregroundStyle(.white)
                    if !searchQuery.isEmpty {
                        Button(action: {
                            AppleHapticEngine.shared.selectionTick()
                            searchQuery = ""
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 8)
                .liquidGlass(cornerRadius: 14, opacity: 0.72)
            }
        }
        .padding(.horizontal, metrics.horizontalGutter)
        .padding(.top, max(metrics.safeAreaInsets.top, 14))
        .padding(.bottom, 10)
        .liquidGlass(cornerRadius: 0, opacity: 0.88)
    }
    
    // MARK: - Bottom Floating Liquid Glass Dock
    private var bottomFloatingDock: some View {
        LiquidGlassFloatingBar {
            HStack {
                Button(action: {
                    AppleHapticEngine.shared.selectionTick()
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.82)) {
                        activeTab = .newsfeed
                        filterScope = .all
                        selectedFeedID = nil
                    }
                }) {
                    VStack(spacing: 3) {
                        Image(systemName: "newspaper.fill")
                            .font(.system(size: metrics.iconSize(base: 17), weight: .semibold))
                        Text("Newsfeed")
                            .font(.system(size: metrics.fontSize(base: 10), weight: .semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .foregroundStyle(activeTab == .newsfeed && filterScope != .starred ? Color.substackOrange : Color.white.opacity(0.75))
                }
                
                Button(action: {
                    AppleHapticEngine.shared.selectionTick()
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.82)) {
                        activeTab = .saved
                        filterScope = .starred
                    }
                }) {
                    VStack(spacing: 3) {
                        Image(systemName: filterScope == .starred ? "bookmark.fill" : "bookmark")
                            .font(.system(size: metrics.iconSize(base: 17), weight: .semibold))
                        Text("Saved")
                            .font(.system(size: metrics.fontSize(base: 10), weight: .semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .foregroundStyle(filterScope == .starred ? Color.substackOrange : Color.white.opacity(0.75))
                }
                
                Button(action: {
                    AppleHapticEngine.shared.pullThresholdDetent()
                    Task {
                        await FeedRefreshEngine.shared.pullToRefreshAll(modelContext: modelContext)
                        AppleHapticEngine.shared.refreshCompleted()
                    }
                }) {
                    VStack(spacing: 3) {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .font(.system(size: metrics.iconSize(base: 17), weight: .semibold))
                        Text("Sync")
                            .font(.system(size: metrics.fontSize(base: 10), weight: .medium))
                    }
                    .frame(maxWidth: .infinity)
                    .foregroundStyle(Color.white.opacity(0.75))
                }
                
                Button(action: {
                    AppleHapticEngine.shared.selectionTick()
                    isSourcesSheetOpen = true
                }) {
                    VStack(spacing: 3) {
                        Image(systemName: "globe.asia.australia.fill")
                            .font(.system(size: metrics.iconSize(base: 17), weight: .semibold))
                        Text("Sources")
                            .font(.system(size: metrics.fontSize(base: 10), weight: .medium))
                    }
                    .frame(maxWidth: .infinity)
                    .foregroundStyle(Color.white.opacity(0.75))
                }
            }
        }
    }
    
    private var activeTitle: String {
        if let id = selectedFeedID, let feed = feeds.first(where: { $0.id == id }) {
            return feed.title
        }
        if filterScope == .starred {
            return "Saved Stories"
        }
        return "Chinta News"
    }
    
    private var filteredArticles: [FeedItem] {
        articles.filter { item in
            let matchesFeed = selectedFeedID == nil || item.feed?.id == selectedFeedID
            let matchesScope: Bool
            switch filterScope {
            case .all: matchesScope = true
            case .unread: matchesScope = !item.isRead
            case .starred: matchesScope = item.isStarred
            }
            let matchesSearch = searchQuery.isEmpty ||
                item.title.localizedCaseInsensitiveContains(searchQuery) ||
                (item.summary?.localizedCaseInsensitiveContains(searchQuery) ?? false) ||
                (item.feed?.title.localizedCaseInsensitiveContains(searchQuery) ?? false)
            return matchesFeed && matchesScope && matchesSearch
        }
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 14) {
            Image(systemName: filterScope == .starred ? "bookmark.slash" : "newspaper")
                .font(.system(size: metrics.iconSize(base: 42)))
                .foregroundStyle(.secondary)
            Text(filterScope == .starred ? "No Saved Stories Yet" : "Loading Latest Dispatches...")
                .font(.system(size: metrics.fontSize(base: 17), weight: .semibold, design: .serif))
                .foregroundStyle(.white)
            Text(filterScope == .starred ? "Tap the bookmark icon on any article to keep it for offline reading." : "Pull down to sync Bangladeshi & international newspapers.")
                .font(.system(size: metrics.fontSize(base: 13)))
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .padding(.horizontal, 32)
    }
}

// MARK: - Substack Post Card Layout (Large Featured 16:9 Cover & Social Ribbon)
public struct SubstackPostCard: View {
    let item: FeedItem
    let onTap: () -> Void
    @Environment(\.displayMetrics) private var metrics
    @Environment(\.modelContext) private var modelContext
    
    @State private var isLiked = false
    @State private var likesCount = 28
    @State private var isRestacked = false
    @State private var restacksCount = 12
    
    public var body: some View {
        Button(action: onTap) {
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 8) {
                    ZStack {
                        Circle()
                            .fill(Color(white: 0.18))
                            .frame(width: 26, height: 26)
                        
                        Text(String(item.feed?.title.prefix(1) ?? "C").uppercased())
                            .font(.system(size: 11, weight: .bold))
                            .foregroundStyle(Color.substackOrange)
                    }
                    
                    Text(item.feed?.title ?? "Newspaper")
                        .font(.system(size: metrics.fontSize(base: 12), weight: .semibold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                    
                    Text("·")
                        .foregroundStyle(.secondary)
                    
                    Text(item.publishedDate, style: .relative)
                        .font(.system(size: metrics.fontSize(base: 11)))
                        .foregroundStyle(.secondary)
                    
                    Spacer()
                    
                    if !item.isRead {
                        Circle()
                            .fill(Color.substackOrange)
                            .frame(width: 6, height: 6)
                    }
                }
                .padding(.horizontal, metrics.horizontalGutter)
                .padding(.top, 14)
                .padding(.bottom, 8)
                
                Text(item.title)
                    .font(.system(size: metrics.fontSize(base: 19), weight: .bold, design: .serif))
                    .foregroundStyle(item.isRead ? Color.white.opacity(0.65) : Color.white)
                    .lineLimit(3)
                    .multilineTextAlignment(.leading)
                    .padding(.horizontal, metrics.horizontalGutter)
                    .padding(.bottom, 6)
                
                if let summary = item.summary, !summary.isEmpty {
                    Text(summary)
                        .font(.system(size: metrics.fontSize(base: 13)))
                        .foregroundStyle(Color.white.opacity(0.75))
                        .lineLimit(2)
                        .multilineTextAlignment(.leading)
                        .padding(.horizontal, metrics.horizontalGutter)
                        .padding(.bottom, 10)
                }
                
                if let imageURL = item.imageURL {
                    AsyncImage(url: imageURL) { phase in
                        switch phase {
                        case .success(let image):
                            image
                                .resizable()
                                .aspectRatio(16/9, contentMode: .fill)
                                .frame(maxWidth: .infinity)
                                .clipped()
                                .cornerRadius(12)
                                .padding(.horizontal, metrics.horizontalGutter)
                                .padding(.bottom, 10)
                        default:
                            EmptyView()
                        }
                    }
                }
                
                HStack(spacing: 20) {
                    Button(action: {
                        AppleHapticEngine.shared.toggleSuccess()
                        withAnimation(.spring(response: 0.25, dampingFraction: 0.65)) {
                            isLiked.toggle()
                            likesCount += isLiked ? 1 : -1
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: isLiked ? "heart.fill" : "heart")
                                .font(.system(size: metrics.iconSize(base: 13)))
                                .foregroundStyle(isLiked ? Color.red : Color.white.opacity(0.6))
                                .scaleEffect(isLiked ? 1.15 : 1.0)
                            Text("\(likesCount)")
                                .font(.system(size: metrics.fontSize(base: 11)))
                                .foregroundStyle(isLiked ? Color.red : Color.white.opacity(0.6))
                        }
                    }
                    .buttonStyle(.plain)
                    
                    Button(action: {
                        AppleHapticEngine.shared.toggleSuccess()
                        withAnimation(.spring(response: 0.25, dampingFraction: 0.65)) {
                            isRestacked.toggle()
                            restacksCount += isRestacked ? 1 : -1
                        }
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "arrow.2.squarepath")
                                .font(.system(size: metrics.iconSize(base: 12), weight: .semibold))
                                .foregroundStyle(isRestacked ? Color.emeraldBrand : Color.white.opacity(0.6))
                            Text("\(restacksCount)")
                                .font(.system(size: metrics.fontSize(base: 11)))
                                .foregroundStyle(isRestacked ? Color.emeraldBrand : Color.white.opacity(0.6))
                        }
                    }
                    .buttonStyle(.plain)
                    
                    Spacer()
                    
                    if let link = item.link {
                        ShareLink(item: link) {
                            Image(systemName: "square.and.arrow.up")
                                .font(.system(size: metrics.iconSize(base: 13)))
                                .foregroundStyle(Color.white.opacity(0.6))
                        }
                        .buttonStyle(.plain)
                    }
                    
                    Button(action: {
                        AppleHapticEngine.shared.toggleSuccess()
                        withAnimation(.spring(response: 0.25, dampingFraction: 0.65)) {
                            item.isStarred.toggle()
                            try? modelContext.save()
                        }
                    }) {
                        Image(systemName: item.isStarred ? "bookmark.fill" : "bookmark")
                            .font(.system(size: metrics.iconSize(base: 13)))
                            .foregroundStyle(item.isStarred ? Color.substackOrange : Color.white.opacity(0.6))
                            .scaleEffect(item.isStarred ? 1.15 : 1.0)
                    }
                    .buttonStyle(.plain)
                }
                .padding(.horizontal, metrics.horizontalGutter)
                .padding(.top, 8)
                .padding(.bottom, 12)
            }
            .liquidGlass(cornerRadius: metrics.cardCornerRadius, opacity: 0.84)
        }
        .buttonStyle(.plain)
    }
}

public struct LiquidCompactRow: View {
    let item: FeedItem
    let onTap: () -> Void
    @Environment(\.displayMetrics) private var metrics
    
    public var body: some View {
        Button(action: onTap) {
            HStack(spacing: 12) {
                if !item.isRead {
                    Circle()
                        .fill(Color.substackOrange)
                        .frame(width: 6, height: 6)
                }
                
                VStack(alignment: .leading, spacing: 3) {
                    Text(item.feed?.title ?? "News")
                        .font(.system(size: metrics.fontSize(base: 10), weight: .bold))
                        .foregroundStyle(Color.substackOrange)
                        .textCase(.uppercase)
                    
                    Text(item.title)
                        .font(.system(size: metrics.fontSize(base: 14), weight: .medium, design: .serif))
                        .foregroundStyle(item.isRead ? Color.white.opacity(0.6) : Color.white)
                        .lineLimit(2)
                }
                
                Spacer()
                
                Text(item.publishedDate, style: .relative)
                    .font(.system(size: metrics.fontSize(base: 10)))
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 12)
            .liquidGlass(cornerRadius: 16, opacity: 0.72)
        }
        .buttonStyle(.plain)
    }
}

private struct ScrollOffsetPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}
