import SwiftUI

public struct LiquidGlassModifier: ViewModifier {
    @Environment(\.colorScheme) private var colorScheme
    let cornerRadius: CGFloat
    let interactiveSheen: Bool
    let opacity: CGFloat
    
    public init(cornerRadius: CGFloat = 24, interactiveSheen: Bool = true, opacity: CGFloat = 0.85) {
        self.cornerRadius = cornerRadius
        self.interactiveSheen = interactiveSheen
        self.opacity = opacity
    }
    
    public var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .fill(.ultraThinMaterial)
                .opacity(opacity)
            
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: colorScheme == .dark
                            ? [Color(white: 0.13).opacity(0.48), Color(white: 0.04).opacity(0.74)]
                            : [Color.white.opacity(0.72), Color.white.opacity(0.42)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
            
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .strokeBorder(
                    LinearGradient(
                        stops: [
                            .init(color: Color.white.opacity(colorScheme == .dark ? 0.32 : 0.78), location: 0.0),
                            .init(color: Color.white.opacity(colorScheme == .dark ? 0.08 : 0.25), location: 0.35),
                            .init(color: Color.clear, location: 0.65),
                            .init(color: Color.black.opacity(colorScheme == .dark ? 0.42 : 0.10), location: 1.0)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: 0.8
                )
        }
        .shadow(
            color: colorScheme == .dark ? Color.black.opacity(0.38) : Color.black.opacity(0.08),
            radius: 14,
            x: 0,
            y: 6
        )
    }
}

public extension View {
    func liquidGlass(cornerRadius: CGFloat = 24, interactiveSheen: Bool = true, opacity: CGFloat = 0.85) -> some View {
        self.background(LiquidGlassModifier(cornerRadius: cornerRadius, interactiveSheen: interactiveSheen, opacity: opacity))
    }
}

public struct LiquidGlassFloatingBar<Content: View>: View {
    @Environment(\.displayMetrics) private var metrics
    let content: Content
    
    public init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    public var body: some View {
        HStack(spacing: 0) {
            content
        }
        .padding(.horizontal, 10)
        .frame(height: metrics.floatingBarHeight)
        .liquidGlass(cornerRadius: metrics.floatingBarHeight / 2, opacity: 0.92)
        .padding(.horizontal, metrics.horizontalGutter)
        .padding(.bottom, max(metrics.safeAreaInsets.bottom, 12))
    }
}

public struct LiquidGlassPillButton: View {
    let title: String
    let icon: String?
    let isSelected: Bool
    let badgeCount: Int
    let action: () -> Void
    @Environment(\.displayMetrics) private var metrics
    
    public init(
        title: String,
        icon: String? = nil,
        isSelected: Bool,
        badgeCount: Int = 0,
        action: @escaping () -> Void
    ) {
        self.title = title
        self.icon = icon
        self.isSelected = isSelected
        self.badgeCount = badgeCount
        self.action = action
    }
    
    public var body: some View {
        Button(action: {
            AppleHapticEngine.shared.selectionTick()
            withAnimation(.spring(response: 0.32, dampingFraction: 0.78)) {
                action()
            }
        }) {
            HStack(spacing: 5) {
                if let icon = icon {
                    Image(systemName: icon)
                        .font(.system(size: metrics.iconSize(base: 12), weight: .semibold))
                }
                
                Text(title)
                    .font(.system(size: metrics.fontSize(base: 13), weight: isSelected ? .semibold : .medium))
                    .lineLimit(1)
                
                if badgeCount > 0 {
                    Text("\(badgeCount)")
                        .font(.system(size: metrics.fontSize(base: 10), weight: .bold, design: .rounded))
                        .padding(.horizontal, 5)
                        .padding(.vertical, 1.5)
                        .background(isSelected ? Color.white.opacity(0.25) : Color.substackOrange.opacity(0.20))
                        .foregroundStyle(isSelected ? Color.white : Color.substackOrange)
                        .clipShape(Capsule())
                }
            }
            .padding(.horizontal, metrics.tier == .compact ? 11 : 14)
            .padding(.vertical, 7)
            .background {
                if isSelected {
                    Capsule(style: .continuous)
                        .fill(Color.substackOrange)
                        .shadow(color: Color.substackOrange.opacity(0.4), radius: 8, y: 3)
                } else {
                    Capsule(style: .continuous)
                        .fill(Color.white.opacity(0.07))
                }
            }
            .foregroundStyle(isSelected ? Color.white : Color.white.opacity(0.80))
        }
        .buttonStyle(.plain)
    }
}

public extension Color {
    static let emeraldBrand = Color(red: 0.03, green: 0.58, blue: 0.42)
    static let substackOrange = Color(red: 1.0, green: 0.404, blue: 0.098) // #FF6719
    static let amber = Color(red: 0.96, green: 0.62, blue: 0.04)
    static let liquidBackgroundDark = Color(red: 0.035, green: 0.04, blue: 0.048) // #090A0C
}
