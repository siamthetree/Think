import SwiftUI
import SwiftData

public struct ReaderDetailView: View {
    @Bindable var article: FeedItem
    @Environment(\.dismiss) private var dismiss
    @Environment(\.displayMetrics) private var metrics
    @Environment(\.modelContext) private var modelContext
    
    @State private var fontSizeOffset: CGFloat = 0.0
    @State private var readerTheme: NativeReaderTheme = .oled
    @State private var useSerifFont: Bool = true
    @State private var extractedParagraphs: [String] = []
    @State private var isExtracting: Bool = false
    
    public enum NativeReaderTheme: String, CaseIterable {
        case paper = "Paper"
        case sepia = "Sepia"
        case slate = "Slate"
        case oled = "OLED"
        
        var background: Color {
            switch self {
            case .paper: return Color(red: 0.98, green: 0.97, blue: 0.95)
            case .sepia: return Color(red: 0.96, green: 0.93, blue: 0.86)
            case .slate: return Color(red: 0.08, green: 0.09, blue: 0.11)
            case .oled:  return Color.liquidBackgroundDark
            }
        }
        
        var primaryText: Color {
            switch self {
            case .paper, .sepia: return Color(red: 0.12, green: 0.10, blue: 0.08)
            case .slate, .oled:  return Color(white: 0.92)
            }
        }
        
        var isLight: Bool {
            self == .paper || self == .sepia
        }
    }
    
    public init(article: FeedItem) {
        self.article = article
    }
    
    public var body: some View {
        ZStack(alignment: .bottom) {
            readerTheme.background
                .ignoresSafeArea(.all)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    if let imageURL = article.imageURL {
                        AsyncImage(url: imageURL) { phase in
                            switch phase {
                            case .success(let image):
                                image
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(maxWidth: .infinity, maxHeight: metrics.tier == .compact ? 220 : 280)
                                    .clipped()
                            default:
                                EmptyView()
                            }
                        }
                    } else {
                        Color.clear.frame(height: max(metrics.safeAreaInsets.top, 20) + 44)
                    }
                    
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            if let source = article.feed?.title {
                                Text(source)
                                    .font(.system(size: metrics.fontSize(base: 12), weight: .bold))
                                    .foregroundStyle(Color.substackOrange)
                                    .textCase(.uppercase)
                                    .tracking(0.8)
                            }
                            
                            Spacer()
                            
                            Text(article.publishedDate, style: .date)
                                .font(.system(size: metrics.fontSize(base: 12)))
                                .foregroundStyle(readerTheme.primaryText.opacity(0.6))
                        }
                        
                        Text(article.title)
                            .font(.system(size: metrics.fontSize(base: 25) + fontSizeOffset, weight: .bold, design: useSerifFont ? .serif : .default))
                            .foregroundStyle(readerTheme.primaryText)
                            .lineSpacing(4)
                        
                        if let author = article.author, !author.isEmpty {
                            Text("By \(author)")
                                .font(.system(size: metrics.fontSize(base: 13), weight: .medium))
                                .foregroundStyle(readerTheme.primaryText.opacity(0.65))
                        }
                        
                        Divider()
                            .background(readerTheme.primaryText.opacity(0.15))
                            .padding(.vertical, 4)
                        
                        if isExtracting && bodyParagraphs.count <= 1 {
                            HStack(spacing: 10) {
                                ProgressView()
                                    .tint(Color.substackOrange)
                                Text("Extracting full distraction-free article...")
                                    .font(.system(size: 13))
                                    .foregroundStyle(readerTheme.primaryText.opacity(0.65))
                            }
                            .padding(.vertical, 8)
                        }
                        
                        ForEach(Array(bodyParagraphs.enumerated()), id: \.offset) { _, paragraph in
                            Text(paragraph)
                                .font(.system(size: metrics.fontSize(base: 17) + fontSizeOffset, weight: .regular, design: useSerifFont ? .serif : .default))
                                .foregroundStyle(readerTheme.primaryText.opacity(0.92))
                                .lineSpacing(7)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .padding(.horizontal, metrics.horizontalGutter)
                    .padding(.top, 20)
                    .padding(.bottom, metrics.floatingBarHeight + max(metrics.safeAreaInsets.bottom, 24) + 44)
                }
            }
            .scrollIndicators(.hidden)
            
            topFloatingNav
            bottomReaderDock
        }
        .onAppear {
            article.isRead = true
            try? modelContext.save()
        }
        .task {
            await loadFullArticleIfNeeded()
        }
    }
    
    // MARK: - Native Full-Text Article Extractor
    private func loadFullArticleIfNeeded() async {
        let existingText = FeedParserService.stripHTML(article.contentHTML ?? article.summary ?? "")
        guard existingText.count < 600, let link = article.link else { return }
        
        isExtracting = true
        defer { isExtracting = false }
        
        var request = URLRequest(url: link)
        request.timeoutInterval = 10
        request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1", forHTTPHeaderField: "User-Agent")
        
        if let (data, _) = try? await URLSession.shared.data(for: request),
           let html = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) {
            let extracted = FeedParserService.extractFullArticle(from: html, baseURL: link)
            if !extracted.paragraphs.isEmpty {
                extractedParagraphs = extracted.paragraphs
                article.contentHTML = extracted.paragraphs.map { "<p>\($0)</p>" }.joined(separator: "\n")
                if article.author == nil, let author = extracted.author {
                    article.author = author
                }
                if article.imageURL == nil, let img = extracted.leadImageURL {
                    article.imageURL = img
                }
                try? modelContext.save()
            }
        }
    }
    
    private var bodyParagraphs: [String] {
        if !extractedParagraphs.isEmpty {
            return extractedParagraphs
        }
        let raw = article.contentHTML ?? article.summary ?? "No article text available."
        let parts = raw
            .replacingOccurrences(of: "</p>", with: "\n\n", options: .caseInsensitive)
            .components(separatedBy: "\n\n")
            .map { FeedParserService.stripHTML($0) }
            .filter { !$0.isEmpty }
        return parts.isEmpty ? [FeedParserService.stripHTML(raw)] : parts
    }
    
    // MARK: - Top Floating Glass Nav
    private var topFloatingNav: some View {
        VStack {
            HStack {
                Button(action: {
                    AppleHapticEngine.shared.selectionTick()
                    dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: metrics.iconSize(base: 15), weight: .semibold))
                        .foregroundStyle(readerTheme.primaryText)
                        .frame(width: metrics.iconSize(base: 38), height: metrics.iconSize(base: 38))
                        .liquidGlass(cornerRadius: 19, opacity: 0.85)
                }
                
                Spacer()
                
                Button(action: {
                    AppleHapticEngine.shared.toggleSuccess()
                    withAnimation(.spring(response: 0.25, dampingFraction: 0.7)) {
                        article.isStarred.toggle()
                        try? modelContext.save()
                    }
                }) {
                    Image(systemName: article.isStarred ? "bookmark.fill" : "bookmark")
                        .font(.system(size: metrics.iconSize(base: 15), weight: .semibold))
                        .foregroundStyle(article.isStarred ? Color.substackOrange : readerTheme.primaryText)
                        .frame(width: metrics.iconSize(base: 38), height: metrics.iconSize(base: 38))
                        .liquidGlass(cornerRadius: 19, opacity: 0.85)
                }
            }
            .padding(.horizontal, metrics.horizontalGutter)
            .padding(.top, max(metrics.safeAreaInsets.top, 12))
            
            Spacer()
        }
    }
    
    // MARK: - Bottom Reader Floating Dock
    private var bottomReaderDock: some View {
        LiquidGlassFloatingBar {
            HStack {
                Button(action: {
                    AppleHapticEngine.shared.selectionTick()
                    if fontSizeOffset > -4 { fontSizeOffset -= 2 }
                }) {
                    Image(systemName: "textformat.size.smaller")
                        .font(.system(size: metrics.iconSize(base: 15), weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .foregroundStyle(readerTheme.primaryText)
                }
                
                Button(action: {
                    AppleHapticEngine.shared.selectionTick()
                    if fontSizeOffset < 8 { fontSizeOffset += 2 }
                }) {
                    Image(systemName: "textformat.size.larger")
                        .font(.system(size: metrics.iconSize(base: 15), weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .foregroundStyle(readerTheme.primaryText)
                }
                
                Button(action: {
                    AppleHapticEngine.shared.selectionTick()
                    withAnimation(.spring(response: 0.25, dampingFraction: 0.8)) {
                        useSerifFont.toggle()
                    }
                }) {
                    Text(useSerifFont ? "Serif" : "Sans")
                        .font(.system(size: metrics.fontSize(base: 12), weight: .bold, design: useSerifFont ? .serif : .default))
                        .frame(maxWidth: .infinity)
                        .foregroundStyle(Color.substackOrange)
                }
                
                Button(action: {
                    AppleHapticEngine.shared.selectionTick()
                    withAnimation(.easeInOut(duration: 0.22)) {
                        let all = NativeReaderTheme.allCases
                        if let idx = all.firstIndex(of: readerTheme) {
                            readerTheme = all[(idx + 1) % all.count]
                        }
                    }
                }) {
                    Text(readerTheme.rawValue)
                        .font(.system(size: metrics.fontSize(base: 12), weight: .semibold))
                        .frame(maxWidth: .infinity)
                        .foregroundStyle(readerTheme.primaryText)
                }
                
                if let link = article.link {
                    ShareLink(item: link) {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: metrics.iconSize(base: 15), weight: .semibold))
                            .frame(maxWidth: .infinity)
                            .foregroundStyle(readerTheme.primaryText)
                    }
                }
            }
        }
    }
}
