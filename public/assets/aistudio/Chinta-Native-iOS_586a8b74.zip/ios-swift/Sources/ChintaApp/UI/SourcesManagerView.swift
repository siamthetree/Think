import SwiftUI
import SwiftData

public struct SourcesManagerView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var modelContext
    @Environment(\.displayMetrics) private var metrics
    @Query(sort: \Feed.title) private var feeds: [Feed]
    
    @Binding var selectedFeedID: UUID?
    @State private var isAddFeedPresented = false
    @State private var newFeedTitleString = ""
    @State private var newFeedURLString = ""
    
    public init(selectedFeedID: Binding<UUID?> = .constant(nil)) {
        self._selectedFeedID = selectedFeedID
    }
    
    public var body: some View {
        NavigationStack {
            ZStack {
                Color.liquidBackgroundDark
                    .ignoresSafeArea(.all)
                
                ScrollView {
                    VStack(spacing: 16) {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Tap a Newspaper to Filter Feed")
                                .font(.system(size: metrics.fontSize(base: 12), weight: .bold))
                                .foregroundStyle(Color.substackOrange)
                                .textCase(.uppercase)
                            
                            ForEach(feeds) { feed in
                                HStack {
                                    Button(action: {
                                        AppleHapticEngine.shared.selectionTick()
                                        selectedFeedID = feed.id
                                        dismiss()
                                    }) {
                                        VStack(alignment: .leading, spacing: 4) {
                                            HStack(spacing: 6) {
                                                Text(feed.title)
                                                    .font(.system(size: metrics.fontSize(base: 16), weight: .bold, design: .serif))
                                                    .foregroundStyle(.white)
                                                if selectedFeedID == feed.id {
                                                    Image(systemName: "checkmark.circle.fill")
                                                        .foregroundStyle(Color.substackOrange)
                                                        .font(.system(size: 13))
                                                }
                                            }
                                            
                                            if let desc = feed.feedDescription, !desc.isEmpty {
                                                Text(desc)
                                                    .font(.system(size: metrics.fontSize(base: 12)))
                                                    .foregroundStyle(.secondary)
                                                    .lineLimit(1)
                                            }
                                            
                                            HStack(spacing: 8) {
                                                Text("\(feed.items.count) stories cached")
                                                    .font(.system(size: metrics.fontSize(base: 11), weight: .medium))
                                                    .foregroundStyle(Color.emeraldBrand)
                                                
                                                Text("·")
                                                    .foregroundStyle(.secondary)
                                                
                                                Text(feed.url.host ?? feed.url.absoluteString)
                                                    .font(.system(size: metrics.fontSize(base: 11)))
                                                    .foregroundStyle(.secondary)
                                                    .lineLimit(1)
                                            }
                                        }
                                    }
                                    .buttonStyle(.plain)
                                    
                                    Spacer()
                                    
                                    Button(action: {
                                        AppleHapticEngine.shared.toggleSuccess()
                                        if selectedFeedID == feed.id {
                                            selectedFeedID = nil
                                        }
                                        modelContext.delete(feed)
                                        try? modelContext.save()
                                    }) {
                                        Image(systemName: "trash")
                                            .font(.system(size: metrics.iconSize(base: 14)))
                                            .foregroundStyle(.red.opacity(0.85))
                                            .padding(8)
                                    }
                                    .buttonStyle(.plain)
                                }
                                .padding(14)
                                .liquidGlass(cornerRadius: 16, opacity: 0.78)
                            }
                        }
                        .padding(.horizontal, metrics.horizontalGutter)
                    }
                    .padding(.vertical, 16)
                }
            }
            .navigationTitle("Newspapers & Portals")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button("Done") {
                        AppleHapticEngine.shared.selectionTick()
                        dismiss()
                    }
                    .foregroundStyle(Color.substackOrange)
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: {
                        AppleHapticEngine.shared.selectionTick()
                        isAddFeedPresented = true
                    }) {
                        Image(systemName: "plus.circle.fill")
                            .foregroundStyle(Color.substackOrange)
                    }
                }
            }
            .alert("Add Newspaper or RSS URL", isPresented: $isAddFeedPresented) {
                TextField("Newspaper Name (optional)", text: $newFeedTitleString)
                TextField("https://bdnews24.com or RSS URL", text: $newFeedURLString)
                    .textInputAutocapitalization(.never)
                    .keyboardType(.URL)
                Button("Add & Sync") {
                    var raw = newFeedURLString.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !raw.isEmpty && !raw.lowercased().hasPrefix("http") {
                        raw = "https://" + raw
                    }
                    if let url = URL(string: raw) {
                        let cleanTitle = newFeedTitleString.trimmingCharacters(in: .whitespacesAndNewlines)
                        let hostTitle = url.host?.replacingOccurrences(of: "^www\\.", with: "", options: .regularExpression) ?? "Newspaper"
                        let newFeed = Feed(title: cleanTitle.isEmpty ? hostTitle : cleanTitle, url: url)
                        modelContext.insert(newFeed)
                        try? modelContext.save()
                        selectedFeedID = newFeed.id
                        Task {
                            await FeedRefreshEngine.shared.pullToRefresh(feed: newFeed, modelContext: modelContext)
                        }
                    }
                    newFeedTitleString = ""
                    newFeedURLString = ""
                }
                Button("Cancel", role: .cancel) {
                    newFeedTitleString = ""
                    newFeedURLString = ""
                }
            }
        }
    }
}
