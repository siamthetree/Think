import Foundation
import SwiftData

@MainActor
public final class FeedRefreshEngine {
    public static let shared = FeedRefreshEngine()
    public static let backgroundTaskIdentifier = "com.paperpress.reader.refresh"
    
    private let networkClient: FeedNetworkClient
    private let parserService: FeedParserService
    private let rateLimiter: HostRateLimiter
    
    public private(set) var isRefreshingAll = false
    
    public init() {
        let limiter = HostRateLimiter(maxConcurrent: 4, maxPerHost: 1)
        self.rateLimiter = limiter
        self.networkClient = FeedNetworkClient(rateLimiter: limiter)
        self.parserService = FeedParserService()
    }
    
    // MARK: - Seed Curated Bangladeshi & Global Newspapers + Initial Offline Stories
    public func seedDefaultFeedsIfNeeded(modelContext: ModelContext) {
        let descriptor = FetchDescriptor<Feed>()
        let existingCount = (try? modelContext.fetchCount(descriptor)) ?? 0
        guard existingCount == 0 else { return }
        
        let defaults: [(title: String, url: String, site: String, desc: String)] = [
            ("The Daily Star", "https://www.thedailystar.net/rss.xml", "https://www.thedailystar.net", "Leading English-language daily newspaper in Bangladesh."),
            ("Prothom Alo (English)", "https://en.prothomalo.com/feed", "https://en.prothomalo.com", "National news, politics, economy, and views from Dhaka."),
            ("প্রথম আলো (Prothom Alo)", "https://www.prothomalo.com/feed", "https://www.prothomalo.com", "বাংলাদেশের শীর্ষস্থানীয় বাংলা দৈনিক পত্রিকা।"),
            ("bdnews24.com", "https://bdnews24.com", "https://bdnews24.com", "Bangladesh's first bilingual online newspaper (Direct Portal Reader)."),
            ("The Business Standard", "https://www.tbsnews.net", "https://www.tbsnews.net", "Business, economy, policy, and analysis from Bangladesh."),
            ("The Financial Express BD", "https://thefinancialexpress.com.bd", "https://thefinancialexpress.com.bd", "Financial, economic, trade, and market news from Dhaka."),
            ("Dhaka Tribune", "https://www.dhakatribune.com", "https://www.dhakatribune.com", "National and international coverage from Dhaka."),
            ("BBC News World", "https://feeds.bbci.co.uk/news/world/rss.xml", "https://www.bbc.com/news", "International news, analysis and features from the BBC.")
        ]
        
        var createdFeeds: [Feed] = []
        for entry in defaults {
            if let feedURL = URL(string: entry.url) {
                let feed = Feed(
                    title: entry.title,
                    url: feedURL,
                    siteURL: URL(string: entry.site),
                    feedDescription: entry.desc
                )
                modelContext.insert(feed)
                createdFeeds.append(feed)
            }
        }
        
        // Seed initial high-resolution editorial articles so first launch is immediately rich & readable offline
        if let dailyStar = createdFeeds.first {
            let sample1 = FeedItem(
                deduplicationKey: "seed:ds_renewable_2026",
                guid: "seed_ds_1",
                title: "Why Bangladesh Must Pivot to Distributed Renewable Energy Grids Now",
                link: URL(string: "https://www.thedailystar.net/slow-reads/big-picture/news/why-bangladesh-must-pivot-renewable-energy-now-4184106"),
                summary: "With foreign exchange pressures and volatile LNG imports, transitioning industrial rooftops across Gazipur and Chattogram to solar is an economic imperative.",
                contentHTML: "<p>Over the past decade, Bangladesh's power sector achieved historic milestones in expanding electrification to remote riverine islands and rural hamlets. However, heavy reliance on imported LNG and coal has exposed the national grid to international commodity price shocks and foreign exchange strain.</p><p>Energy economists point out that solar photovoltaic generation costs have fallen by more than 75 percent over the last decade. Industrial rooftops across Gazipur, Narayanganj, and Chattogram represent over 4,000 megawatts of untapped clean generation capacity.</p><p>By streamlining net-metering policies and modernizing transmission substations, Bangladesh can bolster its export competitiveness while meeting long-term decarbonization commitments.</p>",
                author: "Khairul Jahin",
                publishedDate: Date.now.addingTimeInterval(-1500),
                imageURL: URL(string: "https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&w=1200&q=80")
            )
            sample1.feed = dailyStar
            modelContext.insert(sample1)
        }
        
        if createdFeeds.count > 1 {
            let prothomAlo = createdFeeds[1]
            let sample2 = FeedItem(
                deduplicationKey: "seed:pa_canals_2026",
                guid: "seed_pa_1",
                title: "Restoring Dhaka's Lost Canals: Blueprint for Urban Climate Resilience",
                link: URL(string: "https://en.prothomalo.com/environment/restoring-dhakas-lost-canals"),
                summary: "Hydrologists and urban planners unveil an interconnected ecological corridor to curb monsoon waterlogging and revive urban waterways.",
                contentHTML: "<p>Hydrologists and municipal authorities have initiated a comprehensive dredging and ecological restoration program targeting interconnected canals across eastern and northern Dhaka.</p><p>Decades of unplanned encroachment severed natural drainage channels connecting the Turag, Balu, and Buriganga rivers. Restoring these waterways with permeable green embankments will reduce monsoon flooding while creating shaded pedestrian walkways across the capital.</p>",
                author: "Staff Correspondent",
                publishedDate: Date.now.addingTimeInterval(-3600),
                imageURL: URL(string: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=1200&q=80")
            )
            sample2.feed = prothomAlo
            modelContext.insert(sample2)
        }
        
        try? modelContext.save()
    }
    
    // MARK: - App Launch & Foreground Refresh
    public func onAppLaunch(modelContext: ModelContext) async {
        seedDefaultFeedsIfNeeded(modelContext: modelContext)
        await pullToRefreshAll(modelContext: modelContext)
    }
    
    // MARK: - Pull to Refresh (Manual Override)
    public func pullToRefresh(feed: Feed, modelContext: ModelContext) async {
        await refreshSingleFeed(feed: feed, isManualOverride: true, modelContext: modelContext)
    }
    
    public func pullToRefreshAll(modelContext: ModelContext) async {
        guard !isRefreshingAll else { return }
        isRefreshingAll = true
        defer { isRefreshingAll = false }
        
        let descriptor = FetchDescriptor<Feed>()
        guard let feeds = try? modelContext.fetch(descriptor) else { return }
        
        for feed in feeds {
            await refreshSingleFeed(feed: feed, isManualOverride: true, modelContext: modelContext)
        }
    }
    
    // MARK: - Periodic / Due Feeds Refresh
    public func refreshDueFeeds(modelContext: ModelContext) async {
        let now = Date.now
        let descriptor = FetchDescriptor<Feed>(
            predicate: #Predicate<Feed> { feed in
                feed.nextFetchDate <= now && (feed.backoffUntilDate == nil || feed.backoffUntilDate! <= now)
            }
        )
        
        guard let dueFeeds = try? modelContext.fetch(descriptor), !dueFeeds.isEmpty else { return }
        for feed in dueFeeds {
            await refreshSingleFeed(feed: feed, isManualOverride: false, modelContext: modelContext)
        }
    }
    
    // MARK: - Single Feed Refresh Core Engine
    private func refreshSingleFeed(feed: Feed, isManualOverride: Bool, modelContext: ModelContext) async {
        let now = Date.now
        if !isManualOverride, let backoff = feed.backoffUntilDate, backoff > now {
            return
        }
        
        feed.lastFetchDate = now
        
        do {
            let result = try await networkClient.fetchFeed(
                url: feed.url,
                etag: feed.etag,
                lastModified: feed.lastModified
            )
            
            switch result {
            case .notModified(let newEtag, let newLastMod, let cacheTTL):
                handleNotModified(feed: feed, etag: newEtag, lastModified: newLastMod, cacheTTL: cacheTTL)
                
            case .success(let data, let newEtag, let newLastMod, let redirectedURL, let cacheTTL):
                do {
                    try handleSuccess(
                        feed: feed,
                        data: data,
                        etag: newEtag,
                        lastModified: newLastMod,
                        redirectedURL: redirectedURL,
                        cacheTTL: cacheTTL,
                        modelContext: modelContext
                    )
                } catch {
                    try await fallbackGoogleNewsDomainIndex(for: feed, modelContext: modelContext)
                }
                
            case .rateLimited(let retryAfter):
                handleFailure(feed: feed, errorMessage: "HTTP 429 Too Many Requests", retryAfter: retryAfter)
                
            case .serverError(_, _), .clientError(_):
                try await fallbackGoogleNewsDomainIndex(for: feed, modelContext: modelContext)
            }
        } catch {
            try? await fallbackGoogleNewsDomainIndex(for: feed, modelContext: modelContext)
        }
        
        try? modelContext.save()
    }
    
    /// Fallback for Cloudflare-protected Bangladeshi portals (e.g. tbsnews.net, dhakatribune.com)
    private func fallbackGoogleNewsDomainIndex(for feed: Feed, modelContext: ModelContext) async throws {
        guard let host = feed.url.host?.replacingOccurrences(of: "^www\\.", with: "", options: .regularExpression),
              !host.isEmpty else {
            throw URLError(.cannotFindHost)
        }
        let encodedQuery = "site:\(host)".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "site:\(host)"
        guard let fallbackURL = URL(string: "https://news.google.com/rss/search?q=\(encodedQuery)&hl=en-BD&gl=BD&ceid=BD:en") else {
            throw URLError(.badURL)
        }
        let result = try await networkClient.fetchFeed(url: fallbackURL, etag: nil, lastModified: nil)
        if case .success(let data, _, _, _, _) = result {
            try handleSuccess(
                feed: feed,
                data: data,
                etag: nil,
                lastModified: nil,
                redirectedURL: nil,
                cacheTTL: nil,
                modelContext: modelContext
            )
        }
    }
    
    private func handleNotModified(feed: Feed, etag: String?, lastModified: String?, cacheTTL: TimeInterval?) {
        feed.etag = etag ?? feed.etag
        feed.lastModified = lastModified ?? feed.lastModified
        feed.consecutiveErrorCount = 0
        feed.isFailing = false
        feed.backoffUntilDate = nil
        feed.lastErrorMessage = nil
        feed.consecutiveNewItemsCount = 0
        feed.consecutiveEmptyCount += 1
        
        let (interval, nextDate) = FeedAdaptiveScheduler.computeNextInterval(
            feed: feed,
            newItemsCount: 0,
            feedHintTTLMinutes: nil,
            cacheControlTTL: cacheTTL
        )
        feed.currentInterval = interval
        feed.nextFetchDate = nextDate
    }
    
    private func handleSuccess(
        feed: Feed,
        data: Data,
        etag: String?,
        lastModified: String?,
        redirectedURL: URL?,
        cacheTTL: TimeInterval?,
        modelContext: ModelContext
    ) throws {
        if let redirectedURL = redirectedURL, redirectedURL != feed.url {
            feed.url = redirectedURL
        }
        
        feed.etag = etag
        feed.lastModified = lastModified
        feed.consecutiveErrorCount = 0
        feed.isFailing = false
        feed.backoffUntilDate = nil
        feed.lastErrorMessage = nil
        feed.lastSuccessfulFetchDate = Date.now
        
        let payload = try parserService.parse(data: data, originalURL: feed.url)
        if (feed.title == "Untitled Feed" || feed.title.isEmpty), let newTitle = payload.title {
            feed.title = newTitle
        }
        if feed.siteURL == nil { feed.siteURL = payload.siteURL }
        if feed.feedDescription == nil { feed.feedDescription = payload.feedDescription }
        
        let existingKeys = Set(feed.items.map { $0.deduplicationKey })
        var newParsedItems = payload.items.filter { !existingKeys.contains($0.deduplicationKey) }
        
        if !feed.isInitialFetchDone {
            if newParsedItems.count > feed.initialItemLimit {
                newParsedItems = Array(newParsedItems.prefix(feed.initialItemLimit))
            }
            feed.isInitialFetchDone = true
        }
        
        for p in newParsedItems {
            let item = FeedItem(
                deduplicationKey: p.deduplicationKey,
                guid: p.guid,
                title: p.title,
                link: p.link,
                summary: p.summary,
                contentHTML: p.contentHTML,
                author: p.author,
                publishedDate: p.publishedDate,
                imageURL: p.imageURL
            )
            item.feed = feed
            feed.items.append(item)
            modelContext.insert(item)
        }
        
        if !newParsedItems.isEmpty {
            feed.consecutiveNewItemsCount += 1
            feed.consecutiveEmptyCount = 0
        } else {
            feed.consecutiveNewItemsCount = 0
            feed.consecutiveEmptyCount += 1
        }
        
        let (interval, nextDate) = FeedAdaptiveScheduler.computeNextInterval(
            feed: feed,
            newItemsCount: newParsedItems.count,
            feedHintTTLMinutes: payload.hintTTLMinutes,
            cacheControlTTL: cacheTTL
        )
        feed.currentInterval = interval
        feed.nextFetchDate = nextDate
        
        FeedRetentionManager.prune(feed: feed, modelContext: modelContext)
    }
    
    private func handleFailure(feed: Feed, errorMessage: String, retryAfter: TimeInterval?) {
        feed.consecutiveErrorCount += 1
        feed.lastErrorMessage = errorMessage
        if feed.consecutiveErrorCount >= 5 {
            feed.isFailing = true
        }
        let (interval, nextDate) = FeedAdaptiveScheduler.computeBackoffInterval(
            consecutiveErrors: feed.consecutiveErrorCount,
            retryAfter: retryAfter
        )
        feed.backoffUntilDate = nextDate
        feed.nextFetchDate = nextDate
        feed.currentInterval = interval
    }
}
