import Foundation
import UIKit
import CoreHaptics

/// Apple-Grade Native Haptic Feedback Engine
/// Uses CoreHaptics transient/continuous patterns & pre-warmed UIKit feedback generators for zero-latency tactile feel.
@MainActor
public final class AppleHapticEngine {
    public static let shared = AppleHapticEngine()
    
    private var hapticEngine: CHHapticEngine?
    private let selectionGenerator = UISelectionFeedbackGenerator()
    private let impactSoft = UIImpactFeedbackGenerator(style: .soft)
    private let impactLight = UIImpactFeedbackGenerator(style: .light)
    private let impactMedium = UIImpactFeedbackGenerator(style: .medium)
    private let impactRigid = UIImpactFeedbackGenerator(style: .rigid)
    private let notification = UINotificationFeedbackGenerator()
    
    private init() {
        prepareEngine()
        prepareGenerators()
    }
    
    private func prepareGenerators() {
        selectionGenerator.prepare()
        impactSoft.prepare()
        impactLight.prepare()
        impactMedium.prepare()
        impactRigid.prepare()
        notification.prepare()
    }
    
    private func prepareEngine() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        do {
            hapticEngine = try CHHapticEngine()
            hapticEngine?.playsHapticsOnly = true
            hapticEngine?.isAutoShutdownEnabled = true
            try hapticEngine?.start()
            
            hapticEngine?.resetHandler = { [weak self] in
                do {
                    try self?.hapticEngine?.start()
                } catch {
                    // Fallback to UIKit generators automatically
                }
            }
        } catch {
            // Device uses UIKit feedback generators
        }
    }
    
    /// Crisp mechanical detent when pull-to-refresh crosses activation threshold
    public func pullThresholdDetent() {
        if playTransient(intensity: 0.95, sharpness: 0.88) { return }
        impactRigid.prepare()
        impactRigid.impactOccurred(intensity: 1.0)
    }
    
    /// Double soft pulse when feed synchronization finishes
    public func refreshCompleted() {
        if CHHapticEngine.capabilitiesForHardware().supportsHaptics, let engine = hapticEngine {
            do {
                try engine.start()
                let p1 = CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.55),
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.35)
                    ],
                    relativeTime: 0
                )
                let p2 = CHHapticEvent(
                    eventType: .hapticTransient,
                    parameters: [
                        CHHapticEventParameter(parameterID: .hapticIntensity, value: 0.78),
                        CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.62)
                    ],
                    relativeTime: 0.055
                )
                let pattern = try CHHapticPattern(events: [p1, p2], parameters: [])
                let player = try engine.makePlayer(with: pattern)
                try player.start(atTime: CHHapticTimeImmediate)
                return
            } catch {}
        }
        notification.prepare()
        notification.notificationOccurred(.success)
    }
    
    /// Ultra-crisp wheel/tab/chip selection tick
    public func selectionTick() {
        selectionGenerator.prepare()
        selectionGenerator.selectionChanged()
    }
    
    /// Subtle cushioned tap for opening cards or sheets
    public func cardTap() {
        if playTransient(intensity: 0.60, sharpness: 0.45) { return }
        impactSoft.prepare()
        impactSoft.impactOccurred(intensity: 0.75)
    }
    
    /// Tactile pop for Like / Restack / Bookmark actions
    public func toggleSuccess() {
        if playTransient(intensity: 0.82, sharpness: 0.72) { return }
        impactMedium.prepare()
        impactMedium.impactOccurred(intensity: 0.85)
    }
    
    private func playTransient(intensity: Float, sharpness: Float) -> Bool {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics, let engine = hapticEngine else {
            return false
        }
        do {
            try engine.start()
            let event = CHHapticEvent(
                eventType: .hapticTransient,
                parameters: [
                    CHHapticEventParameter(parameterID: .hapticIntensity, value: intensity),
                    CHHapticEventParameter(parameterID: .hapticSharpness, value: sharpness)
                ],
                relativeTime: 0
            )
            let pattern = try CHHapticPattern(events: [event], parameters: [])
            let player = try engine.makePlayer(with: pattern)
            try player.start(atTime: CHHapticTimeImmediate)
            return true
        } catch {
            return false
        }
    }
}
