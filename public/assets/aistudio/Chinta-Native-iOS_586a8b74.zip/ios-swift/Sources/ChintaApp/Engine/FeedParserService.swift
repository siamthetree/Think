import Foundation
import CryptoKit

public struct ParsedFeedItem: Sendable {
    public let deduplicationKey: String
    public let guid: String?
    public let title: String
    public let link: URL?
    public let summary: String?
    public let contentHTML: String?
    public let author: String?
    public let publishedDate: Date
    public let imageURL: URL?
}

public struct ParsedFeedPayload: Sendable {
    public let title: String?
    public let siteURL: URL?
    public let feedDescription: String?
    public let hintTTLMinutes: Int?
    public let items: [ParsedFeedItem]
}

public struct ExtractedArticleContent: Sendable {
    public let title: String?
    public let author: String?
    public let leadImageURL: URL?
    public let paragraphs: [String]
}

public final class FeedParserService: Sendable {
    public init() {}
    
    public func parse(data: Data, originalURL: URL) throws -> ParsedFeedPayload {
        // 1. JSON Feed Detection
        if let jsonObject = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let version = jsonObject["version"] as? String, version.contains("jsonfeed") {
            return try parseJSONFeed(jsonObject: jsonObject, originalURL: originalURL)
        }
        
        // 2. XML Parser (RSS 2.0 / Atom)
        let xmlParser = XMLFeedDelegate(originalURL: originalURL)
        let parser = XMLParser(data: data)
        parser.delegate = xmlParser
        if parser.parse(), !xmlParser.resultPayload.items.isEmpty {
            return xmlParser.resultPayload
        }
        
        // 3. Fallback for malformed XML or Direct HTML News Portals (e.g. bdnews24.com, thefinancialexpress.com.bd, tbsnews.net)
        if let rawText = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) {
            let regexXML = parseMalformedXML(rawText, originalURL: originalURL)
            if !regexXML.items.isEmpty {
                return regexXML
            }
            let htmlPortal = parseHTMLPortal(rawText, originalURL: originalURL)
            if !htmlPortal.items.isEmpty {
                return htmlPortal
            }
        }
        
        throw parser.parserError ?? URLError(.cannotParseResponse)
    }
    
    /// Native Distraction-Free Full Article Extractor (JSON-LD articleBody + <article>/<p> extraction)
    public static func extractFullArticle(from html: String, baseURL: URL) -> ExtractedArticleContent {
        var extractedTitle: String? = nil
        var extractedAuthor: String? = nil
        var extractedImage: URL? = nil
        var paragraphs: [String] = []
        
        // 1. Check JSON-LD for structured articleBody
        let jsonLdPattern = "<script[^>]+type=[\"']application/ld\\+json[\"'][^>]*>([\\s\\S]*?)</script>"
        if let regex = try? NSRegularExpression(pattern: jsonLdPattern, options: [.caseInsensitive]) {
            let matches = regex.matches(in: html, range: NSRange(html.startIndex..., in: html))
            for match in matches {
                if let range = Range(match.range(at: 1), in: html) {
                    let jsonText = String(html[range]).trimmingCharacters(in: .whitespacesAndNewlines)
                    if let jsonData = jsonText.data(using: .utf8),
                       let obj = try? JSONSerialization.jsonObject(with: jsonData) {
                        let nodes: [[String: Any]]
                        if let arr = obj as? [[String: Any]] {
                            nodes = arr
                        } else if let dict = obj as? [String: Any] {
                            if let graph = dict["@graph"] as? [[String: Any]] {
                                nodes = graph
                            } else {
                                nodes = [dict]
                            }
                        } else {
                            nodes = []
                        }
                        for node in nodes {
                            if extractedTitle == nil, let h = node["headline"] as? String {
                                extractedTitle = stripHTML(h)
                            }
                            if extractedAuthor == nil {
                                if let a = node["author"] as? String {
                                    extractedAuthor = stripHTML(a)
                                } else if let aDict = node["author"] as? [String: Any], let name = aDict["name"] as? String {
                                    extractedAuthor = stripHTML(name)
                                } else if let aArr = node["author"] as? [[String: Any]], let name = aArr.first?["name"] as? String {
                                    extractedAuthor = stripHTML(name)
                                }
                            }
                            if let body = node["articleBody"] as? String, body.count > 160 {
                                let split = body
                                    .components(separatedBy: CharacterSet.newlines)
                                    .map { stripHTML($0) }
                                    .filter { $0.count > 30 }
                                if split.count > paragraphs.count {
                                    paragraphs = split
                                }
                            }
                        }
                    }
                }
            }
        }
        
        // 2. Extract <p> blocks if JSON-LD body was not present
        if paragraphs.count < 3 {
            let pPattern = "<p[^>]*>([\\s\\S]*?)</p>"
            if let regex = try? NSRegularExpression(pattern: pPattern, options: [.caseInsensitive]) {
                let matches = regex.matches(in: html, range: NSRange(html.startIndex..., in: html))
                var seen = Set<String>()
                for match in matches {
                    if let range = Range(match.range(at: 1), in: html) {
                        let text = stripHTML(String(html[range]))
                        if text.count >= 40,
                           !text.lowercased().hasPrefix("cookie"),
                           !text.lowercased().hasPrefix("subscribe"),
                           !text.lowercased().hasPrefix("all rights reserved"),
                           !seen.contains(text) {
                            seen.insert(text)
                            paragraphs.append(text)
                        }
                    }
                }
            }
        }
        
        // 3. Extract og:image if available
        let ogImgPattern = "<meta[^>]+property=[\"']og:image[\"'][^>]+content=[\"']([^\"']+)[\"']"
        if let regex = try? NSRegularExpression(pattern: ogImgPattern, options: [.caseInsensitive]),
           let match = regex.firstMatch(in: html, range: NSRange(html.startIndex..., in: html)),
           let range = Range(match.range(at: 1), in: html) {
            extractedImage = URL(string: String(html[range]), relativeTo: baseURL)?.absoluteURL
        }
        
        return ExtractedArticleContent(
            title: extractedTitle,
            author: extractedAuthor,
            leadImageURL: extractedImage,
            paragraphs: paragraphs
        )
    }
    
    public static func stripHTML(_ raw: String) -> String {
        guard !raw.isEmpty else { return "" }
        let withoutTags = raw.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
        return withoutTags
            .replacingOccurrences(of: "&nbsp;", with: " ")
            .replacingOccurrences(of: "&amp;", with: "&")
            .replacingOccurrences(of: "&quot;", with: "\"")
            .replacingOccurrences(of: "&#39;", with: "'")
            .replacingOccurrences(of: "&#039;", with: "'")
            .replacingOccurrences(of: "&apos;", with: "'")
            .replacingOccurrences(of: "&lt;", with: "<")
            .replacingOccurrences(of: "&gt;", with: ">")
            .replacingOccurrences(of: "&ndash;", with: "–")
            .replacingOccurrences(of: "&mdash;", with: "—")
            .replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    private func parseMalformedXML(_ xml: String, originalURL: URL) -> ParsedFeedPayload {
        let itemPattern = "<(?:item|entry)[\\s>]([\\s\\S]*?)</(?:item|entry)>"
        guard let regex = try? NSRegularExpression(pattern: itemPattern, options: [.caseInsensitive]) else {
            return ParsedFeedPayload(title: nil, siteURL: originalURL, feedDescription: nil, hintTTLMinutes: nil, items: [])
        }
        let matches = regex.matches(in: xml, range: NSRange(xml.startIndex..., in: xml))
        var items: [ParsedFeedItem] = []
        
        for (idx, match) in matches.enumerated() {
            guard let range = Range(match.range(at: 1), in: xml) else { continue }
            let block = String(xml[range])
            let rawTitle = extractTag("title", from: block) ?? "Untitled Story"
            let title = Self.stripHTML(rawTitle)
            let linkStr = extractTag("link", from: block) ?? extractAttr("href", inTag: "link", from: block)
            let link = linkStr != nil ? URL(string: linkStr!.trimmingCharacters(in: .whitespacesAndNewlines), relativeTo: originalURL)?.absoluteURL : nil
            let desc = extractTag("description", from: block) ?? extractTag("summary", from: block)
            let content = extractTag("content:encoded", from: block) ?? extractTag("content", from: block) ?? desc
            let author = extractTag("dc:creator", from: block) ?? extractTag("author", from: block)
            let imgStr = extractAttr("url", inTag: "enclosure", from: block) ?? extractAttr("url", inTag: "media:content", from: block) ?? extractFirstImgSrc(from: content ?? "")
            let imageURL = imgStr != nil ? URL(string: imgStr!, relativeTo: originalURL)?.absoluteURL : nil
            
            let pubDate = Date.now.addingTimeInterval(TimeInterval(-idx * 180))
            let dedup = Self.generateDeduplicationKey(guid: link?.absoluteString, link: link?.absoluteString, title: title, date: pubDate)
            items.append(ParsedFeedItem(
                deduplicationKey: dedup,
                guid: link?.absoluteString,
                title: title,
                link: link,
                summary: desc != nil ? Self.stripHTML(desc!) : nil,
                contentHTML: content,
                author: author != nil ? Self.stripHTML(author!) : nil,
                publishedDate: pubDate,
                imageURL: imageURL
            ))
        }
        return ParsedFeedPayload(title: nil, siteURL: originalURL, feedDescription: nil, hintTTLMinutes: nil, items: items)
    }
    
    private func parseHTMLPortal(_ html: String, originalURL: URL) -> ParsedFeedPayload {
        let anchorPattern = "<a\\s+([^>]+)>([\\s\\S]*?)</a>"
        guard let regex = try? NSRegularExpression(pattern: anchorPattern, options: [.caseInsensitive]) else {
            return ParsedFeedPayload(title: nil, siteURL: originalURL, feedDescription: nil, hintTTLMinutes: nil, items: [])
        }
        let baseHost = (originalURL.host ?? "").replacingOccurrences(of: "^www\\.", with: "", options: .regularExpression)
        let matches = regex.matches(in: html, range: NSRange(html.startIndex..., in: html))
        var items: [ParsedFeedItem] = []
        var seenURLs = Set<String>()
        var seenTitles = Set<String>()
        
        for match in matches {
            if items.count >= 25 { break }
            guard let attrRange = Range(match.range(at: 1), in: html),
                  let innerRange = Range(match.range(at: 2), in: html) else { continue }
            let attrs = String(html[attrRange])
            let inner = String(html[innerRange])
            
            guard let href = extractAttrValue("href", from: attrs),
                  !href.hasPrefix("#"),
                  !href.hasPrefix("javascript:"),
                  let fullURL = URL(string: href, relativeTo: originalURL)?.absoluteURL else { continue }
            
            if !baseHost.isEmpty, !(fullURL.host ?? "").contains(baseHost) { continue }
            let path = fullURL.path
            let segments = path.split(separator: "/").map(String.init)
            if path.count < 16 || segments.isEmpty { continue }
            let lastSeg = segments.last ?? ""
            let hyphenCount = lastSeg.filter { $0 == "-" }.count
            let hasDigits = lastSeg.rangeOfCharacter(from: .decimalDigits) != nil
            if !(hasDigits || hyphenCount >= 2 || segments.count >= 3) { continue }
            
            let titleCandidate = Self.stripHTML(inner)
            let wordCount = titleCandidate.split(separator: " ").count
            if titleCandidate.count < 24 || titleCandidate.count > 220 || wordCount < 4 { continue }
            
            let urlKey = fullURL.absoluteString
            let titleKey = titleCandidate.lowercased()
            if seenURLs.contains(urlKey) || seenTitles.contains(titleKey) { continue }
            seenURLs.insert(urlKey)
            seenTitles.insert(titleKey)
            
            let imgStr = extractFirstImgSrc(from: inner)
            let imageURL = imgStr != nil ? URL(string: imgStr!, relativeTo: originalURL)?.absoluteURL : nil
            let pubDate = Date.now.addingTimeInterval(TimeInterval(-items.count * 120))
            let sectionName = segments.first?.replacingOccurrences(of: "-", with: " ").capitalized ?? "News"
            let summary = "\(baseHost) · \(sectionName) — Tap to read full extracted article."
            let dedup = Self.generateDeduplicationKey(guid: urlKey, link: urlKey, title: titleCandidate, date: pubDate)
            
            items.append(ParsedFeedItem(
                deduplicationKey: dedup,
                guid: urlKey,
                title: titleCandidate,
                link: fullURL,
                summary: summary,
                contentHTML: nil,
                author: nil,
                publishedDate: pubDate,
                imageURL: imageURL
            ))
        }
        
        return ParsedFeedPayload(title: nil, siteURL: originalURL, feedDescription: nil, hintTTLMinutes: nil, items: items)
    }
    
    private func extractTag(_ tag: String, from text: String) -> String? {
        let pattern = "<\(tag)[^>]*>([\\s\\S]*?)</\(tag)>"
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              let range = Range(match.range(at: 1), in: text) else { return nil }
        return String(text[range])
            .replacingOccurrences(of: "<![CDATA[", with: "")
            .replacingOccurrences(of: "]]>", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    private func extractAttr(_ attr: String, inTag tag: String, from text: String) -> String? {
        let pattern = "<\(tag)[^>]+\(attr)=[\"']([^\"']+)[\"']"
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              let range = Range(match.range(at: 1), in: text) else { return nil }
        return String(text[range])
    }
    
    private func extractAttrValue(_ attr: String, from attrs: String) -> String? {
        let pattern = "\(attr)=[\"']([^\"']+)[\"']"
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = regex.firstMatch(in: attrs, range: NSRange(attrs.startIndex..., in: attrs)),
              let range = Range(match.range(at: 1), in: attrs) else { return nil }
        return String(attrs[range])
    }
    
    private func extractFirstImgSrc(from html: String) -> String? {
        let pattern = "<img[^>]+(?:src|data-src)=[\"']([^\"']+)[\"']"
        guard let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
              let match = regex.firstMatch(in: html, range: NSRange(html.startIndex..., in: html)),
              let range = Range(match.range(at: 1), in: html) else { return nil }
        let src = String(html[range])
        if src.hasPrefix("data:") || src.hasSuffix(".svg") || src.hasSuffix(".gif") { return nil }
        return src
    }
    
    private func parseJSONFeed(jsonObject: [String: Any], originalURL: URL) throws -> ParsedFeedPayload {
        let title = jsonObject["title"] as? String
        let siteURLStr = jsonObject["home_page_url"] as? String
        let desc = jsonObject["description"] as? String
        
        var parsedItems: [ParsedFeedItem] = []
        let rawItems = jsonObject["items"] as? [[String: Any]] ?? []
        
        let isoFormatter = ISO8601DateFormatter()
        isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        let fallbackISO = ISO8601DateFormatter()
        
        for itemDict in rawItems {
            let id = itemDict["id"] as? String
            let itemTitle = (itemDict["title"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Untitled"
            let urlStr = itemDict["url"] as? String
            let link = urlStr != nil ? URL(string: urlStr!) : nil
            let summary = itemDict["summary"] as? String
            let contentHTML = itemDict["content_html"] as? String ?? itemDict["content_text"] as? String
            let authorName = (itemDict["author"] as? [String: Any])?["name"] as? String
            let imageStr = itemDict["image"] as? String ?? itemDict["banner_image"] as? String
            
            var pubDate = Date.now
            if let dateStr = itemDict["date_published"] as? String {
                pubDate = isoFormatter.date(from: dateStr) ?? fallbackISO.date(from: dateStr) ?? Date.now
            }
            
            let dedupKey = makeDeduplicationKey(guid: id, link: link?.absoluteString, title: itemTitle, date: pubDate)
            
            parsedItems.append(ParsedFeedItem(
                deduplicationKey: dedupKey,
                guid: id,
                title: itemTitle,
                link: link,
                summary: summary,
                contentHTML: contentHTML,
                author: authorName,
                publishedDate: pubDate,
                imageURL: imageStr != nil ? URL(string: imageStr!) : nil
            ))
        }
        
        return ParsedFeedPayload(
            title: title,
            siteURL: siteURLStr != nil ? URL(string: siteURLStr!) : nil,
            feedDescription: desc,
            hintTTLMinutes: nil,
            items: parsedItems
        )
    }
    
    public static func generateDeduplicationKey(guid: String?, link: String?, title: String, date: Date) -> String {
        if let guid = guid?.trimmingCharacters(in: .whitespacesAndNewlines), !guid.isEmpty {
            return "guid:\(guid)"
        }
        if let link = link?.trimmingCharacters(in: .whitespacesAndNewlines), !link.isEmpty {
            return "link:\(link)"
        }
        let rawInput = "\(title.lowercased())|\(Int(date.timeIntervalSince1970))"
        let hash = SHA256.hash(data: Data(rawInput.utf8))
        let hashString = hash.compactMap { String(format: "%02x", $0) }.joined()
        return "hash:\(hashString)"
    }
    
    private func makeDeduplicationKey(guid: String?, link: String?, title: String, date: Date) -> String {
        FeedParserService.generateDeduplicationKey(guid: guid, link: link, title: title, date: date)
    }
}

// MARK: - XML Parser Delegate (RSS 2.0 & Atom)
private final class XMLFeedDelegate: NSObject, XMLParserDelegate {
    private let originalURL: URL
    private var isAtom = false
    private var inItemOrEntry = false
    
    private var currentElement = ""
    private var currentText = ""
    
    private var channelTitle: String?
    private var channelLink: String?
    private var channelDesc: String?
    private var ttlMinutes: Int?
    private var syUpdatePeriod: String?
    private var syUpdateFrequency: Int?
    
    private var itemGuid: String?
    private var itemTitle: String = ""
    private var itemLink: String?
    private var itemSummary: String?
    private var itemContent: String?
    private var itemAuthor: String?
    private var itemDateStr: String?
    private var itemImageURLStr: String?
    
    private var parsedItems: [ParsedFeedItem] = []
    
    init(originalURL: URL) {
        self.originalURL = originalURL
    }
    
    var resultPayload: ParsedFeedPayload {
        var calculatedTTL = ttlMinutes
        if calculatedTTL == nil, let period = syUpdatePeriod?.lowercased() {
            let freq = max(1, syUpdateFrequency ?? 1)
            switch period {
            case "hourly": calculatedTTL = (60 / freq)
            case "daily": calculatedTTL = (1440 / freq)
            case "weekly": calculatedTTL = (10080 / freq)
            default: break
            }
        }
        
        return ParsedFeedPayload(
            title: channelTitle,
            siteURL: channelLink != nil ? URL(string: channelLink!) : nil,
            feedDescription: channelDesc,
            hintTTLMinutes: calculatedTTL,
            items: parsedItems
        )
    }
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        currentElement = elementName.lowercased()
        currentText = ""
        
        if currentElement == "feed" {
            isAtom = true
        }
        
        if currentElement == "item" || currentElement == "entry" {
            inItemOrEntry = true
            itemGuid = nil
            itemTitle = ""
            itemLink = nil
            itemSummary = nil
            itemContent = nil
            itemAuthor = nil
            itemDateStr = nil
            itemImageURLStr = nil
        }
        
        if inItemOrEntry && currentElement == "link" {
            if let href = attributeDict["href"] {
                let rel = attributeDict["rel"] ?? "alternate"
                if rel == "alternate" || itemLink == nil {
                    itemLink = href
                }
            }
        }
        
        if inItemOrEntry && (currentElement == "enclosure" || currentElement == "media:content" || currentElement == "media:thumbnail") {
            if let url = attributeDict["url"] {
                itemImageURLStr = itemImageURLStr ?? url
            }
        }
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        currentText += string
    }
    
    func parser(_ parser: XMLParser, foundCDATA CDATABlock: Data) {
        if let str = String(data: CDATABlock, encoding: .utf8) {
            currentText += str
        }
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        let tag = elementName.lowercased()
        let trimmed = currentText.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if !inItemOrEntry {
            switch tag {
            case "title": channelTitle = channelTitle ?? FeedParserService.stripHTML(trimmed)
            case "link": channelLink = channelLink ?? trimmed
            case "description", "subtitle": channelDesc = channelDesc ?? FeedParserService.stripHTML(trimmed)
            case "ttl": ttlMinutes = Int(trimmed)
            case "sy:updateperiod": syUpdatePeriod = trimmed
            case "sy:updatefrequency": syUpdateFrequency = Int(trimmed)
            default: break
            }
            return
        }
        
        switch tag {
        case "title":
            itemTitle = FeedParserService.stripHTML(trimmed)
        case "guid", "id":
            itemGuid = trimmed
        case "link" where !isAtom:
            if itemLink == nil { itemLink = trimmed }
        case "description", "summary":
            itemSummary = trimmed
        case "content:encoded", "content":
            itemContent = trimmed
        case "author", "dc:creator":
            itemAuthor = FeedParserService.stripHTML(trimmed)
        case "pubdate", "published", "updated", "dc:date":
            if itemDateStr == nil { itemDateStr = trimmed }
        case "item", "entry":
            inItemOrEntry = false
            finalizeCurrentItem()
        default:
            break
        }
    }
    
    private func finalizeCurrentItem() {
        let resolvedTitle = itemTitle.isEmpty ? "Untitled Story" : itemTitle
        let resolvedLink = itemLink != nil ? URL(string: itemLink!, relativeTo: originalURL)?.absoluteURL : nil
        let resolvedDate = parseDate(itemDateStr) ?? Date.now
        let rawHTML = itemContent ?? itemSummary
        let cleanSummary = itemSummary != nil ? FeedParserService.stripHTML(itemSummary!) : nil
        
        if itemImageURLStr == nil, let rawHTML = rawHTML {
            let pattern = "<img[^>]+src=[\"']([^\"']+)[\"']"
            if let regex = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]),
               let match = regex.firstMatch(in: rawHTML, range: NSRange(rawHTML.startIndex..., in: rawHTML)),
               let range = Range(match.range(at: 1), in: rawHTML) {
                itemImageURLStr = String(rawHTML[range])
            }
        }
        
        let dedupKey = FeedParserService.generateDeduplicationKey(
            guid: itemGuid,
            link: resolvedLink?.absoluteString,
            title: resolvedTitle,
            date: resolvedDate
        )
        
        let item = ParsedFeedItem(
            deduplicationKey: dedupKey,
            guid: itemGuid,
            title: resolvedTitle,
            link: resolvedLink,
            summary: cleanSummary,
            contentHTML: rawHTML,
            author: itemAuthor,
            publishedDate: min(resolvedDate, Date.now),
            imageURL: itemImageURLStr != nil ? URL(string: itemImageURLStr!, relativeTo: originalURL)?.absoluteURL : nil
        )
        parsedItems.append(item)
    }
    
    private func parseDate(_ dateStr: String?) -> Date? {
        guard let dateStr = dateStr?.trimmingCharacters(in: .whitespacesAndNewlines), !dateStr.isEmpty else {
            return nil
        }
        
        let rfc822Formatter = DateFormatter()
        rfc822Formatter.locale = Locale(identifier: "en_US_POSIX")
        for fmt in ["EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss z", "dd MMM yyyy HH:mm:ss Z"] {
            rfc822Formatter.dateFormat = fmt
            if let d = rfc822Formatter.date(from: dateStr) { return d }
        }
        
        let isoFormatter = ISO8601DateFormatter()
        if let d = isoFormatter.date(from: dateStr) { return d }
        isoFormatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        return isoFormatter.date(from: dateStr)
    }
}
